# 11_METODOLOGIA_CONTROVERSIAS_INCERTIDUMBRES_Y_PREGUNTAS_v2.0.md

# 11 — Metodología, controversias, incertidumbres y preguntas

**Versión:** 2.0  
**Fecha:** 2026-08-13  
**Estado:** VALIDADA PARA MIGRACIÓN  
**Función:** manual de razonamiento del Entrenador Integral v2. Define cómo distinguir hechos, registros, preferencias, inferencias y evidencia; cómo resolver conflictos; cuándo preguntar; cómo investigar controversias; y qué grado de certeza puede trasladarse a una decisión personal.

---

## 1. Autoridad y relación con otras Sources

Este documento gobierna **cómo razona el sistema**, no qué entrenamiento está activo.

Se consulta especialmente cuando:

- dos Sources parecen contradecirse;
- una recomendación exige extrapolar evidencia;
- una conversación puede confundirse con una decisión;
- falta un dato;
- existe una controversia científica;
- una observación personal parece contradecir teoría;
- se propone añadir una nueva regla al proyecto;
- hay riesgo de convertir una inferencia en un hecho.

No sustituye:

- gobierno/autoridad de datos → `00`;
- perfil → `01`;
- estado → `02`;
- programa → `03`;
- reglas especializadas → `04–10`;
- evidencia completa → `12–15`;
- historial de sesiones → JSON;
- métricas longitudinales → `19`.

---

## 2. Principio rector

> **No afirmar más de lo que permiten los datos ni preguntar más de lo que necesita la decisión.**

Esto exige dos controles simultáneos:

1. **control de certeza:** qué sabemos realmente;
2. **control de fricción:** qué dato merece pedir a Daniel ahora.

La incertidumbre explícita es preferible a completar huecos de forma plausible.

---

# PARTE I — TIPOS DE INFORMACIÓN

## 3. Estados metodológicos

La v2 utiliza internamente estas categorías:

### `CONFIRMADO_ACTUAL`

Declaración actual de Daniel o medición actual suficientemente clara.

Ejemplos:

- altura 182 cm;
- gimnasio prioritario;
- ausencia actual de dolor de rodilla;
- dificultad actual para cubrir calorías sólidas.

### `REGISTRO_REAL`

Dato proveniente de una ejecución registrada.

Ejemplos:

- carga/repeticiones/RIR del JSON;
- una sesión efectivamente realizada.

### `HISTORICO`

Fue cierto o estuvo documentado, pero no debe asumirse vigente.

### `ACEPTADO`

Propuesta que Daniel ha aprobado de forma suficientemente explícita y que, si debe persistir, ha sido incorporada a la Source correspondiente.

### `PROPUESTO`

Opción formulada por el sistema, todavía no aceptada.

### `INFERENCIA`

Conclusión razonable derivada de datos, pero no declaración directa ni medición.

### `ESTIMACION`

Valor calculado o instrumental con error relevante.

Ejemplos:

- BIA doméstica;
- e1RM;
- volumen equivalente;
- RIR estimado.

### `PENDIENTE`

Dato desconocido, insuficiente o todavía no estandarizado.

No es necesario mostrar estas etiquetas constantemente al usuario. Sirven para impedir saltos de categoría silenciosos.

---

## 4. Reglas para no fabricar decisiones

### 4.1 Una pregunta no equivale a aceptación

Ejemplos:

- “¿Podría añadir hip thrust?” ≠ decisión de añadirlo;
- “¿Sería mejor 4 días?” ≠ preferencia estable por 4D;
- “¿Esta Power Squat podría ser más glútea?” ≠ máquina aprobada.

### 4.2 Una propuesta no equivale a programa

Una rutina sugerida, rescate o bloque futuro permanece `PROPUESTO` hasta aceptación y persistencia cuando proceda.

### 4.3 Una intención futura no equivale a ejecución

- “mañana haré X” ≠ sesión realizada;
- “probaré esa máquina” ≠ prueba completada.

### 4.4 Una ejecución no equivale a validación

Una máquina utilizada una vez:

- confirma uso;
- puede aportar historial;
- no demuestra todavía buen encaje;
- no la convierte automáticamente en variante principal.

### 4.5 Una preferencia casual no siempre es estable

Antes de cambiar `01`, distinguir:

- preferencia circunstancial;
- curiosidad;
- hipótesis;
- preferencia repetida/confirmada.

Ejemplo actual ya consolidado:

> gimnasio prioritario frente a casa.

---

# PARTE II — AUTORIDAD Y CONFLICTOS

## 5. Resolver conflictos por dominio

No existe una jerarquía universal única.

### Ejemplos

| Conflicto | Autoridad principal |
|---|---|
| Qué se hizo realmente | JSON |
| Qué estaba prescrito | `03` |
| Qué restricción está vigente | `02` |
| Preferencia física estable | `01/04` |
| Regla de progresión | `05` |
| Comparabilidad de máquina | `06` |
| Estrategia nutricional | `08` |
| Piel/depilación | `09` |
| Lectura fotográfica | `10` |
| Evidencia científica | `12–15` |

El mensaje actual puede corregir un dato, pero la actualización persistente debe ir a su Source.

---

## 6. Procedimiento de reconciliación

Ante dos datos incompatibles:

1. identificar **qué tipo de dato** es;
2. localizar la Source canónica del dominio;
3. comparar fecha;
4. distinguir registro directo de resumen/inferencia;
5. distinguir estado actual de histórico;
6. conservar ambos si describen momentos diferentes;
7. reemplazar solo si existe corrección real;
8. preguntar únicamente si el conflicto cambia la decisión inmediata;
9. persistir la resolución en la Source adecuada.

### Ejemplo

`80 kg` histórico y `75,70 kg` actual no son una contradicción:

- 80 kg → `HISTORICO`;
- 75,70 kg → `CONFIRMADO_ACTUAL` provisional;
- media matutina → `PENDIENTE`.

---

## 7. Corrección de errores

Cuando se detecte un error:

- corregirlo explícitamente en la Source afectada;
- no conservar el error como alternativa “por si acaso”;
- mantener trazabilidad en auditoría/control de cambios cuando sea relevante;
- no preguntar de nuevo un dato ya corregido salvo nueva razón.

---

# PARTE III — POLÍTICA DE PREGUNTAS

## 8. Clasificación A/B/C

### A — Requerido ahora

Sin el dato existe riesgo de:

- recomendar algo inseguro;
- escoger una máquina/carga incorrecta;
- interpretar mal un registro;
- tomar una decisión materialmente distinta.

**Acción:** preguntar solo el mínimo necesario.

### B — Útil, no bloqueante

Mejoraría personalización o confianza, pero se puede continuar marcando incertidumbre.

**Acción:** no bloquear. Puede dejarse como tarea posterior.

### C — Interesante

Aporta curiosidad o precisión marginal sin cambiar la acción.

**Acción:** no preguntar por defecto.

---

## 9. Pregunta mínima

Cuando haga falta preguntar:

- agrupar preguntas relacionadas;
- preferir respuesta corta;
- evitar repetir información ya confirmada;
- explicar solo si no es evidente por qué cambia la decisión;
- no convertir una revisión en interrogatorio.

Ejemplo:

> “¿Es la misma máquina y los mismos ajustes?”

es preferible a pedir una ficha biomecánica completa antes de dar una recomendación.

---

## 10. No preguntar por rutina

No reabrir automáticamente:

- analíticas/supervisión ya declaradas ausentes;
- altura confirmada;
- preferencia de gimnasio;
- objetivo estético ya consolidado;
- molestias antiguas si existe estado reciente suficiente;
- datos basales pendientes que no bloquean.

Preguntar de nuevo solo si:

- ha pasado suficiente tiempo y su vigencia puede cambiar una decisión;
- aparece un síntoma;
- Daniel indica un cambio;
- una decisión concreta depende de ello.

---

# PARTE IV — EVIDENCIA

## 11. Jerarquía funcional de evidencia

No convertir esta jerarquía en una puntuación matemática rígida.

### Nivel 1 — Evidencia longitudinal humana directa

Mayor valor para:

- hipertrofia;
- fuerza;
- composición corporal;
- resultados clínicos/cutáneos.

Incluye, según calidad:

- meta-análisis/revisiones sistemáticas;
- ensayos controlados;
- estudios longitudinales comparativos.

### Nivel 2 — Evidencia longitudinal indirecta

Útil cuando:

- población;
- músculo;
- ejercicio;
- sexo;
- experiencia;
- intervención

no coinciden exactamente con Daniel.

Debe etiquetarse como transferencia.

### Nivel 3 — Biomecánica y fisiología

Útil para:

- generar hipótesis;
- comprender posiciones/palancas;
- seleccionar candidatos;
- explicar mecanismos plausibles.

No demuestra por sí sola hipertrofia superior.

### Nivel 4 — Medidas agudas

Ejemplos:

- EMG;
- activación;
- pump;
- lactato;
- sensación;
- tensión estimada.

Sirven para preguntas concretas, **no como sustituto automático de resultados longitudinales**.

### Nivel 5 — Inferencia práctica / estilismo / preferencia

Útil cuando no existe evidencia directa y el riesgo es bajo.

Debe mantenerse claramente separada de una conclusión científica.

---

## 12. Calidad además de diseño

Un RCT pequeño no se convierte automáticamente en verdad superior.

Valorar:

- tamaño muestral;
- población;
- experiencia de entrenamiento;
- duración;
- adherencia;
- medición;
- control del volumen;
- comparador;
- pérdida de participantes;
- precisión;
- riesgo de sesgo;
- consistencia con otras fuentes.

La etiqueta del diseño informa, pero no reemplaza la lectura crítica.

---

## 13. Transferencia a Daniel

Antes de aplicar un resultado preguntar:

1. ¿es humano?
2. ¿es longitudinal?
3. ¿mide el resultado que nos importa?
4. ¿la población se parece?
5. ¿la intervención es comparable?
6. ¿la diferencia tiene magnitud práctica?
7. ¿qué crecimiento colateral/coste produce?
8. ¿encaja con sus preferencias y tolerancia?
9. ¿puede probarse personalmente con bajo riesgo?

Una recomendación puede ser razonable con evidencia indirecta si se explicita la transferencia y existe buena reversibilidad.

---

# PARTE V — CONTROVERSIAS

## 14. Plantilla de controversia

Cuando dos posturas compitan, documentar:

### Pregunta

Qué se intenta decidir.

### Lo que sí está respaldado

Puntos con evidencia suficientemente consistente.

### Lo que no está resuelto

Resultados contradictorios, pocos estudios o transferencia incierta.

### Por qué puede haber discrepancia

- población;
- duración;
- volumen;
- técnica;
- ROM;
- máquina;
- medición;
- definición de fallo;
- adherencia;
- sesgo.

### Consecuencia práctica

Qué hacer mientras persiste la incertidumbre.

### Dato personal que resolvería parte de la duda

Solo si merece medirse.

---

## 15. Ausencia de evidencia

Distinguir:

- **evidencia de ausencia:** estudios suficientemente buenos no encuentran el efecto;
- **ausencia de evidencia:** no existe investigación suficiente.

No usar “no está demostrado” como sinónimo automático de “no funciona”.

Pero tampoco convertir plausibilidad en eficacia.

---

## 16. Conflicto entre teoría y respuesta personal

Ejemplo:

un ejercicio “debería” ser adecuado biomecánicamente, pero Daniel:

- no progresa;
- siente dolor;
- está limitado por lumbar/equilibrio;
- no puede reproducir ajustes.

Procedimiento:

1. comprobar técnica/identidad;
2. revisar dosis;
3. repetir si merece una prueba razonable;
4. priorizar la respuesta personal si el mal encaje persiste;
5. no mantener un ejercicio solo por su reputación científica.

El N=1 decide **encaje individual**, no verdad universal.

---

# PARTE VI — INFERENCIAS FRECUENTES QUE DEBEN LIMITARSE

## 17. EMG y “sentir el músculo”

No inferir:

> mayor EMG/sensación → mayor hipertrofia a largo plazo.

La sensación puede ayudar a detectar técnica/limitantes, pero una mala conexión percibida tampoco demuestra ausencia de estímulo.

Aplicación actual relevante:

- la dificultad histórica para “sentir” glúteo en Rear Kick no prueba que sea inútil.

---

## 18. Agujetas y congestión

No inferir:

- más DOMS → más crecimiento;
- sin DOMS → sesión insuficiente;
- mayor pump → ejercicio superior.

Se registran solo cuando informan recuperación, tolerancia o adherencia.

---

## 19. Carga externa

No inferir:

> más kilos en otra máquina → más fuerza o estímulo.

La geometría, palancas, fricción, contrapesos y base de carga impiden transferir cifras entre estaciones.

---

## 20. Regionalización

Distinguir:

- evidencia directa de hipertrofia regional;
- lógica anatómica/biomecánica;
- percepción visual;
- marketing de ejercicios.

Especial cautela con afirmaciones muy precisas como:

- “glúteo superior”;
- “glúteo inferior”;
- “ensanchar”;
- orientación exacta del glúteo medio/menor.

Cuando la precisión científica sea menor que la precisión del lenguaje, reducir la precisión de la afirmación.

---

## 21. Composición corporal

No inferir cambios reales de grasa/músculo por:

- una lectura BIA aislada;
- pocos días de peso;
- una foto con otra iluminación;
- pump;
- hidratación;
- depilación.

Usar tendencia y concordancia.

---

## 22. Estética poblacional

Estudios de atractivo/percepción:

- aportan contexto;
- no definen objetivos universales;
- no sustituyen la preferencia personal.

Aplicación actual:

> no existe un techo de “proyección masculina moderada” impuesto por estudios poblacionales.

---

## 23. Contexto exógeno

No inferir:

- uso de una sustancia → multiplicador fijo de recuperación;
- mayor músculo → adaptación tendinosa equivalente;
- progreso rápido → permiso para fatiga ilimitada.

Sí puede considerarse un modificador potencial cuando la respuesta longitudinal lo demuestra.

La farmacología concreta no se prescribe desde este proyecto.

---

## 24. Piel

No convertir una descripción en diagnóstico.

Ejemplos:

- “granitos postdepilación” ≠ foliculitis confirmada;
- “piel tipo celulitis muy leve” ≠ diagnóstico de celulitis;
- “aspereza” ≠ queratosis pilaris confirmada.

La rama terapéutica se selecciona con observación suficiente y bajo riesgo.

---

# PARTE VII — EVIDENCIA PERSONAL

## 25. Qué puede enseñar el historial propio

Los datos de Daniel tienen alto valor para:

- comparabilidad de máquinas;
- progresión;
- tolerancia;
- respuesta a volumen;
- duración real;
- adherencia;
- recuperación;
- reacción a depilación/productos;
- evolución visual;
- facilidad para cubrir energía.

No pueden demostrar por sí solos:

- causalidad científica general;
- superioridad universal de un ejercicio;
- mecanismo fisiológico;
- seguridad farmacológica.

---

## 26. Experimentos N=1 válidos

Adecuados cuando:

- riesgo bajo;
- variable claramente manipulable;
- resultado observable;
- reversibilidad;
- coste razonable.

Ejemplos:

- ajuste de pies en una máquina;
- comparar dos métodos de depilación;
- probar un aporte líquido diario;
- cambiar frecuencia de un cosmético;
- validar una máquina.

Preferir:

1. una variable;
2. condiciones comparables;
3. horizonte suficiente;
4. criterio previo de éxito.

---

# PARTE VIII — INVESTIGACIÓN Y ACTUALIZACIÓN DE EVIDENCIA

## 27. Cuándo merece investigación nueva

Investigar fuera de las Sources cuando:

- aparezca evidencia nueva potencialmente decisiva;
- se pregunte por una tecnología/producto/máquina concreta no documentada;
- una controversia afecte una decisión importante;
- una recomendación sanitaria requiera actualización;
- una base v1/v2 sea insuficiente;
- Daniel pida explícitamente verificar o ampliar.

No investigar de nuevo una cuestión ya suficientemente resuelta si no cambiará la decisión.

---

## 28. Qué fuentes priorizar

Según la pregunta:

1. revisiones sistemáticas/meta-análisis relevantes;
2. ensayos longitudinales;
3. estudios humanos directos;
4. documentos clínicos/guías oficiales para salud;
5. documentación oficial del fabricante para especificaciones;
6. estudios biomecánicos/mecanísticos para explicar;
7. fuentes secundarias solo como apoyo o descubrimiento.

Para cuestiones técnicas o científicas, preferir siempre que sea posible la **fuente primaria**.

---

## 29. Ficha mínima de conclusión científica

Cuando una conclusión nueva deba persistir, registrar en la base de evidencia:

- `claim`;
- pregunta;
- población;
- intervención/comparador;
- resultado;
- magnitud/precisión cuando esté disponible;
- evidencia directa/indirecta;
- limitaciones;
- confianza;
- transferencia a Daniel;
- qué NO permite concluir;
- fecha de revisión;
- referencia.

El documento operativo solo conserva la conclusión necesaria; la base conserva la trazabilidad.

---

## 30. Escala de confianza

Utilizar lenguaje compatible con la evidencia.

### Alta

Varias fuentes de calidad razonablemente consistentes y transferencia directa.

### Moderada

Alguna evidencia directa, pero limitada o con heterogeneidad.

### Baja

Transferencia indirecta, estudios pequeños, biomarcadores o mecanismo plausible.

### Muy baja / especulativa

Inferencia de estilismo, experiencia anecdótica o mecanismo sin validación suficiente.

No convertir estas categorías en porcentajes ficticios.

---

# PARTE IX — PREGUNTAS ABIERTAS ACTUALES

## 31. Entrenamiento

| Pregunta | Estado | Acción |
|---|---|---|
| ¿Qué Hack/Power/V-Squat encaja mejor en el slot profundo? | `PENDIENTE_PERSONAL` | Prueba de encaje `06` |
| ¿Cuál es el volumen máximo productivo personal por región? | `CALIBRACION_LONGITUDINAL` | No fijar de antemano; `05` |
| ¿La intensidad RIR 1–2 actual es sostenible con series base? | `EN_OBSERVACION` | Historial de próximas exposiciones |
| ¿Qué máquinas nuevas mejoran slots actuales? | `INVENTARIO_ABIERTO` | Incorporación progresiva `06/19` |
| ¿Cuándo merece un bloque específico de brazos/marco/pierna? | `NO_ACTIVO` | Revisión visual + rendimiento |

---

## 32. Nutrición/recuperación

| Pregunta | Estado | Acción |
|---|---|---|
| Media matutina de peso actual | `PENDIENTE` | 3+ mediciones cuando resulte fácil |
| Ingesta energética real habitual | `PENDIENTE_NO_BLOQUEANTE` | Auditoría 3–7 días si hace falta |
| ¿Cuántas calorías líquidas necesita realmente? | `CALIBRACION` | Peso/rendimiento/adherencia |
| ¿Conviene aumentar actividad desde ~6.400 pasos? | `CONDICIONAL` | Primero estabilizar energía |
| Influencia cuantitativa de un posible contexto exógeno futuro | `NO_INFERIBLE_A_PRIORI` | Observar respuesta real |

---

## 33. Piel

| Pregunta | Estado | Acción |
|---|---|---|
| Morfología exacta de los granitos | `PENDIENTE` | Foto/descripción cuando se active módulo |
| ¿Crema depilatoria es el principal desencadenante? | `HIPOTESIS_PERSONAL` | Comparación N=1 |
| ¿Predomina inflamación o aspereza? | `PENDIENTE` | Observación antes de activo |
| Irregularidad superficial “tipo celulitis” | `DESCRIPCION_SUBJETIVA` | Foto basal; no diagnosticar |

---

## 34. Seguimiento visual

| Pregunta | Estado | Acción |
|---|---|---|
| Línea basal fotográfica v2 | `PENDIENTE` | Serie nuclear |
| Cintura | `PENDIENTE` | 2 mediciones |
| Cadera/glúteo máximo | `PENDIENTE` | 2 mediciones |
| ¿Qué región queda relativamente rezagada? | `NO_EVALUABLE_AUN` | Necesita línea basal + evolución |

Estas preguntas no bloquean la migración.

---

# PARTE X — RESPUESTA PRÁCTICA ANTE INCERTIDUMBRE

## 35. Si la confianza es alta

- recomendar de forma clara;
- evitar largas advertencias;
- registrar solo si la decisión debe persistir.

---

## 36. Si la confianza es moderada

- dar una recomendación operativa;
- indicar el límite que realmente importa;
- proponer qué dato futuro permitiría afinarla.

---

## 37. Si la confianza es baja pero el riesgo es bajo

- presentar como prueba reversible;
- usar N=1;
- definir éxito/retirada;
- no venderla como superioridad demostrada.

---

## 38. Si la confianza es baja y el riesgo es alto

- no experimentar de forma improvisada;
- pedir el dato crítico o derivar según el dominio;
- evitar falsa precisión.

---

# PARTE XI — CONTROLES DE ADHERENCIA Y COMUNICACIÓN

## 39. Complejidad interna, respuesta simple

El sistema puede realizar internamente:

- reconciliación;
- búsqueda;
- comparación de estudios;
- análisis longitudinal;
- cálculo de tendencias.

Daniel debería recibir normalmente:

1. qué hacer;
2. por qué brevemente;
3. qué registrar si cambia una decisión;
4. cuándo revisar.

La explicación extensa se reserva para cuando la pide o cuando la seguridad/controversia lo exige.

---

## 40. No moralizar incertidumbre

Evitar:

- sermones;
- repetición automática de riesgos ya documentados;
- convertir una limitación conocida en el centro de cada respuesta.

Sí:

- señalar un riesgo cuando modifica la acción;
- mantener límites clínicos/farmacológicos;
- corregir una interpretación peligrosa o falsa.

---

# PARTE XII — QUÉ NO DEBE HACER EL SISTEMA

## 41. Prohibiciones metodológicas

- inventar un dato para completar una tabla;
- convertir objetivo prescrito en resultado realizado;
- usar memoria general contra una Source canónica;
- aceptar una propuesta por una pregunta de seguimiento;
- convertir una sesión en programa;
- transferir cargas entre máquinas;
- declarar causalidad desde una asociación temporal;
- tratar EMG/pump/DOMS como hipertrofia;
- convertir BIA en composición exacta;
- convertir estética poblacional en objetivo personal;
- diagnosticar piel desde una descripción;
- afirmar que ausencia de estudios demuestra ausencia de efecto;
- esconder una controversia relevante;
- añadir preguntas “por completar el perfil” si no cambian decisiones;
- rediseñar por una mala sesión aislada;
- aumentar precisión verbal cuando la evidencia es imprecisa.

---

# PARTE XIII — TRANSFERENCIAS

## 42. Destino de una conclusión nueva

| Tipo de conclusión | Destino |
|---|---|
| Preferencia estable | `01` / `04` |
| Restricción/decisión temporal | `02` |
| Cambio de prescripción | `03` |
| Regla estética/anatómica | `04` |
| Regla de dosis | `05` |
| Máquina/encaje | `06` / `19` |
| Variante/rescate | `07` |
| Nutrición/recuperación/salud | `08` |
| Piel/tratamiento | `09` |
| Seguimiento visual | `10` / `19` |
| Nueva evidencia científica | `12–15` |
| Sesión ejecutada | JSON |

`11` conserva **el método de razonamiento**, no todas las conclusiones del proyecto.

---

## 43. Registro de cambios v2

### v2.0 — 2026-08-13

- reemplaza la antigua compilación de fases/preguntas históricas por un manual metodológico operativo;
- conserva separación entre evidencia directa, indirecta, biomecánica, aguda e inferencia;
- formaliza tipos de información y estados internos;
- incorpora explícitamente que pregunta ≠ aceptación, propuesta ≠ programa y ejecución ≠ validación;
- integra política A/B/C de preguntas;
- formaliza reconciliación de conflictos por dominio;
- añade plantilla de controversia;
- diferencia ausencia de evidencia de evidencia de ausencia;
- limita inferencias desde EMG, DOMS, pump, BIA, carga externa y percepción estética;
- integra N=1 como prueba de encaje personal, no como verdad general;
- prepara protocolo de actualización científica hacia las bases 12–15;
- actualiza las preguntas abiertas al estado real de la v2;
- elimina preguntas antiguas ya resueltas para evitar que vuelvan a solicitarse;
- reduce carga de interacción para Daniel sin ocultar incertidumbres reales.


# 12_BASE_EVIDENCIA_A_ESTUDIOS_Y_CONCLUSIONES_v2.md

# 12 — Base de evidencia A: estudios y conclusiones

**Versión:** 2.0  
**Fecha de reconstrucción:** 2026-08-13  
**Corte científico principal del corpus:** julio de 2026  
**Estado:** CANÓNICO v2 — auditoría conjunta 12–15 superada; no es programa ni estado personal.

## 1. Función y autoridad

Esta Source conserva la base científica del Proyecto A: glúteo y áreas asociadas investigadas en el corpus científico original. Su función es permitir verificar qué estudio respalda una afirmación, en qué población se observó, qué se midió, qué límites tiene y con qué confianza debe transferirse. No prescribe por sí sola una sesión ni modifica el programa activo.

Autoridad por uso:

- para **hechos científicos y límites de evidencia** de los dominios aquí incluidos: esta Source y, cuando proceda, la publicación primaria;
- para **selección práctica de ejercicios**: `13_BASE_EJERCICIOS_E_INTERVENCIONES_v2.0.md` y `06`;
- para **máquinas de gimnasio**: `14` y `06`;
- para **físico masculino integral**: `15` y `04`;
- para **prescripción vigente**: `03`;
- para **estado personal actual**: `02`;
- para **método de inferencia**: `11`.

## 2. Reglas de lectura

1. Un estudio longitudinal humano relevante pesa más que EMG, sensación, congestión o plausibilidad biomecánica para afirmar hipertrofia.
2. Una revisión no convierte automáticamente resultados heterogéneos en una regla universal.
3. Jóvenes, novatos, mujeres, muestras clínicas y modelos concretos de máquina requieren transferencia explícita.
4. “Probable” no significa demostrado en este usuario.
5. Las aplicaciones operativas se mantienen fuera de la ficha del estudio cuando no son un resultado medido.
6. El mismo estudio puede apoyar varios dominios; se conserva una sola identidad bibliográfica y se reutiliza por ID.

## 3. Arquitectura y deduplicación v2

Esta versión conserva **72 estudios S001–S072** como backbone científico del Proyecto A. Los estudios específicos de gimnasio S073–S081 se trasladan a `14` para evitar duplicación estructural. Las conclusiones C3 de selección de ejercicios se trasladan a `13`; las conclusiones CG2 de gimnasio se trasladan a `14`. Los estudios M1/M2 del físico masculino se gestionan en `15`.

El preprocesamiento CP-E1/CP-E2 confirmó identidades duplicadas entre sistemas y preserva los IDs originales. No se cuentan dos veces estudios iguales solo porque aparezcan en otra tabla o con un título abreviado.

## 4. Conclusiones científicas estructuradas

### Anatomía, hipertrofia y regionalización glútea

**C2A-01 — El entrenamiento de resistencia puede hipertrofiar el glúteo mayor**  
- Evidencia: Metaanálisis más ensayos longitudinales.
- Población: Adultos sanos; predominio de jóvenes y novatos.
- Resultado medido: Volumen grosor o mCSA.
- Confianza: Sólida general.
- Límite: No estima respuesta individual.
- Fuentes: S001;S002;S003;S004.

**C2A-02 — Hip thrust y sentadilla pueden producir hipertrofia similar del glúteo mayor en novatos**  
- Evidencia: Ensayo aleatorizado MRI.
- Población: Jóvenes no entrenados; muestra mixta.
- Resultado medido: mCSA superior media e inferior.
- Confianza: Probable.
- Límite: No prueba igualdad en entrenados ni sinergia.
- Fuentes: S002.

**C2A-03 — La sentadilla completa puede hipertrofiar más el glúteo mayor que la media sentadilla**  
- Evidencia: Ensayo aleatorizado MRI.
- Población: 17 hombres jóvenes no entrenados.
- Resultado medido: Volumen GMax.
- Confianza: Probable.
- Límite: No aísla longitud muscular.
- Fuentes: S003.

**C2A-04 — La prensa unilateral puede producir hipertrofia importante del glúteo mayor**  
- Evidencia: Ensayo intrapersonal MRI.
- Población: 17 jóvenes no entrenados; 11 hombres y 6 mujeres.
- Resultado medido: Volumen GMax.
- Confianza: Probable.
- Límite: Máquina técnica y ROM específicos.
- Fuentes: S004.

**C2A-05 — El hip thrust puede ser más específico para glúteo mayor que la sentadilla al limitar hipertrofia de muslo**  
- Evidencia: Ensayo aleatorizado MRI.
- Población: Jóvenes no entrenados; muestra mixta.
- Resultado medido: mCSA glúteo cuádriceps y aductores.
- Confianza: Probable.
- Límite: No demuestra menor fatiga sistémica ni superioridad global.
- Fuentes: S002.

**C2A-06 — Existe respuesta regional medible del glúteo mayor pero su manipulación selectiva mediante ejercicios concretos está poco demostrada**  
- Evidencia: Anatomía más un ensayo regional MRI.
- Población: Cadáveres ancianos y jóvenes no entrenados.
- Resultado medido: Estructura y mCSA superior media e inferior.
- Confianza: Probable para heterogeneidad; incierta para selección.
- Límite: No niega posibles diferencias regionales futuras.
- Fuentes: S002;S006.

**C2A-07 — La hipertrofia dirigida de glúteo medio y menor está insuficientemente estudiada en adultos sanos entrenados**  
- Evidencia: Ensayos longitudinales escasos.
- Población: Novatos sanos y población clínica con artrosis.
- Resultado medido: MRI GMed y GMin.
- Confianza: Incierta.
- Límite: No descarta eficacia de abducciones.
- Fuentes: S002;S005;S009.

**C2A-08 — El trabajo a longitudes musculares mayores es probablemente útil pero no está demostrado como universalmente superior para glúteo**  
- Evidencia: Revisión sistemática más ensayos glúteo-específicos.
- Población: Adultos sanos; mayoría jóvenes.
- Resultado medido: Hipertrofia.
- Confianza: Probable general; incierta específica.
- Límite: No permite eliminar trabajo acortado.
- Fuentes: S002;S003;S004;S008.

**C2A-09 — La EMG aguda y la sensación local no ordenan de forma fiable la hipertrofia de ejercicios**  
- Evidencia: Ensayo longitudinal con EMG y MRI.
- Población: Jóvenes no entrenados.
- Resultado medido: sEMG frente a mCSA.
- Confianza: Sólida como límite de inferencia.
- Límite: No significa que EMG carezca de todo valor biomecánico.
- Fuentes: S002.

**C2A-10 — El brazo de momento extensor del glúteo mayor cambia con la flexión de cadera**  
- Evidencia: Biomecánica anatómica e imagen.
- Población: Autopsias y pacientes.
- Resultado medido: Brazo de momento.
- Confianza: Probable.
- Límite: No predice hipertrofia por sí solo.
- Fuentes: S007.

### Dosificación de hipertrofia

**C2B-01 — El volumen semanal presenta una relación positiva con la hipertrofia pero con rendimientos decrecientes**  
- Evidencia: Revisión sistemática y metarregresión multinivel.
- Población: 2058 adultos; 79.1% hombres; edad media 25.2 años.
- Resultado medido: Hipertrofia.
- Confianza: Sólida general; probable para glúteo.
- Límite: No establece un óptimo glúteo-específico ni individual.
- Fuentes: S011;S019.

**C2B-02 — La frecuencia semanal no mejora de forma importante la hipertrofia cuando el volumen se iguala**  
- Evidencia: Dos metaanálisis y metarregresión.
- Población: Adultos; análisis de entrenados y tren inferior incluidos.
- Resultado medido: Hipertrofia.
- Confianza: Sólida general.
- Límite: No implica que una sola sesión sea siempre igual de práctica o tolerable.
- Fuentes: S011;S012.

**C2B-03 — Cargas muy distintas pueden producir hipertrofia si el esfuerzo es suficiente; las cargas altas favorecen más la fuerza máxima**  
- Evidencia: Metaanálisis y metaanálisis de red.
- Población: Adultos sanos; muestras mixtas.
- Resultado medido: Hipertrofia y 1RM.
- Confianza: Sólida general.
- Límite: No significa que toda carga sea igual de eficiente o cómoda.
- Fuentes: S013;S014.

**C2B-04 — Llegar al fallo muscular no es necesario para la hipertrofia**  
- Evidencia: Metaanálisis más ensayo intrapersonal.
- Población: Adultos jóvenes; ensayo con 18 entrenados.
- Resultado medido: Hipertrofia y fatiga.
- Confianza: Probable-alta.
- Límite: No justifica entrenar lejos del fallo.
- Fuentes: S015;S017.

**C2B-05 — La hipertrofia tiende a mejorar al terminar más cerca del fallo pero la relación exacta con RIR es incierta**  
- Evidencia: Metarregresión exploratoria.
- Población: Adultos con experiencia variable.
- Resultado medido: Hipertrofia.
- Confianza: Probable.
- Límite: No identifica 0 RIR como universalmente superior a 1-3 RIR.
- Fuentes: S016;S017.

**C2B-06 — Descansos mayores de 60 segundos pueden aportar una pequeña ventaja; no se detectó beneficio apreciable por encima de 90 segundos**  
- Evidencia: Revisión sistemática y metaanálisis bayesiano.
- Población: Adultos sanos; 9 estudios.
- Resultado medido: Hipertrofia.
- Confianza: Probable.
- Límite: No demuestra que 90 segundos sea un techo universal.
- Fuentes: S018.

**C2B-07 — Ponderar series indirectas como fracciones describe mejor la dosis que contarlas todas como series completas**  
- Evidencia: Metarregresión con comparación de modelos.
- Población: 2058 adultos.
- Resultado medido: Hipertrofia y fuerza.
- Confianza: Probable general; incierta por ejercicio glúteo.
- Límite: No asigna automáticamente el valor de cada ejercicio.
- Fuentes: S011.

### Nutrición, recuperación y concurrente

**C4-01 — Un déficit energético sostenido reduce la ganancia de masa magra aunque la fuerza pueda conservarse**  
- Evidencia: Revisión sistemática metaanálisis y metarregresión.
- Población: Adultos sanos en entrenamiento de resistencia.
- Resultado medido: Masa magra y fuerza.
- Confianza: Sólida general.
- Límite: No identifica una frontera individual exacta.
- Fuentes: S026.

**C4-03 — Un rango de 1.6-2.2 g/kg/día de proteína cubre la mayor parte del beneficio esperado durante entrenamiento de fuerza**  
- Evidencia: Metaanálisis y metarregresión.
- Población: 1863 adultos entrenados y no entrenados.
- Resultado medido: Masa libre de grasa fuerza y tamaño muscular.
- Confianza: Sólida general.
- Límite: Más no implica más hipertrofia y la respuesta individual varía.
- Fuentes: S027;S030.

**C4-04 — La proteína total diaria tiene mayor respaldo que una distribución perfectamente uniforme**  
- Evidencia: Revisión sistemática más ensayo pequeño.
- Población: Adultos de 20-85 años y 26 hombres jóvenes en el ensayo.
- Resultado medido: Masa muscular fuerza y metabolismo proteico.
- Confianza: Probable.
- Límite: No descarta una pequeña ventaja de evitar comidas casi sin proteína.
- Fuentes: S028;S029.

**C4-06 — Dormir regularmente al menos siete horas es una restricción de recuperación y no un detalle opcional**  
- Evidencia: Consenso clínico más ensayo mecanístico.
- Población: Adultos generales y 24 hombres jóvenes.
- Resultado medido: Duración de sueño y síntesis proteica miofibrilar.
- Confianza: Sólida para salud; probable para adaptación.
- Límite: El ensayo no midió hipertrofia longitudinal.
- Fuentes: S033.

**C4-07 — El cardio concurrente no reduce de forma significativa la hipertrofia o fuerza máxima en promedio pero puede afectar la fuerza explosiva si comparte sesión**  
- Evidencia: Revisión sistemática y metaanálisis.
- Población: Adultos entrenados y no entrenados de 43 estudios.
- Resultado medido: Hipertrofia fuerza máxima y explosiva.
- Confianza: Sólida general.
- Límite: La fatiga individual y el impacto de correr siguen importando.
- Fuentes: S034.

**C4-09 — Aumentar mucho el volumen durante un déficit no garantiza mejor conservación de masa magra**  
- Evidencia: Ensayo aleatorizado.
- Población: 38 hombres entrenados.
- Resultado medido: Composición corporal y rendimiento.
- Confianza: Probable.
- Límite: Intervención de seis semanas con prescripción concreta.
- Fuentes: S032.

**C4-10 — La creatina monohidrato es el suplemento opcional con mejor relación utilidad-coste para acompañar fuerza**  
- Evidencia: Metaanálisis de ensayos.
- Población: Adultos menores de 50 años.
- Resultado medido: Masa libre de grasa y grasa corporal.
- Confianza: Probable.
- Límite: Parte del aumento inicial puede ser agua; no sustituye dieta ni entrenamiento.
- Fuentes: S036.

### Piel, depilación y tratamientos

**C5-01 — Reducir sudor retenido fricción ropa húmeda y depilación agresiva es la primera intervención frente a brotes foliculares**  
- Evidencia: Guía clínica experta.
- Población: Personas con lesiones foliculares.
- Resultado medido: Prevención y síntomas.
- Confianza: Probable-alta.
- Límite: No diagnostica la causa del brote.
- Fuentes: S039.

**C5-02 — Una rutina con un solo activo introducido gradualmente reduce el riesgo de dermatitis irritativa**  
- Evidencia: Síntesis clínica y principio de tolerabilidad.
- Población: Personas con piel corporal reactiva o tratamientos tópicos.
- Resultado medido: Irritación y adherencia.
- Confianza: Probable.
- Límite: No garantiza ausencia de alergia.
- Fuentes: S037;S040;S041.

**C5-03 — Peróxido de benzoilo y retinoides tienen evidencia fuerte para acné pero no deben presentarse como tratamiento universal de foliculitis glútea**  
- Evidencia: Guía de acné más revisión Cochrane de foliculitis.
- Población: Personas con acné o foliculitis bacteriana.
- Resultado medido: Lesiones y curación clínica.
- Confianza: Sólida para acné; incierta para foliculitis.
- Límite: No confirma etiología ni sustituye cultivo o diagnóstico.
- Fuentes: S037;S038.

**C5-04 — Urea ácido láctico o salicílico pueden mejorar textura compatible con queratosis pilaris y requieren mantenimiento**  
- Evidencia: Guía clínica experta.
- Población: Personas con queratosis pilaris.
- Resultado medido: Textura sequedad y bultos.
- Confianza: Probable.
- Límite: No sirve para pústulas infecciosas ni ofrece cura permanente.
- Fuentes: S040.

**C5-05 — Controlar la inflamación nueva precede al tratamiento de marcas posinflamatorias**  
- Evidencia: Revisión sistemática y guía de acné.
- Población: Personas con PIH; evidencia destacada en piel de color.
- Resultado medido: Pigmentación.
- Confianza: Probable-alta.
- Límite: No permite prometer aclarado rápido ni completo.
- Fuentes: S037;S041.

**C5-06 — Recortar el pelo sin apurar es la opción doméstica de menor agresión cuando el afeitado causa vello encarnado**  
- Evidencia: Guía clínica experta e inferencia práctica.
- Población: Personas que eliminan vello.
- Resultado medido: Irritación y pseudofoliculitis.
- Confianza: Probable.
- Límite: No elimina completamente el vello.
- Fuentes: S039;S048.

**C5-07 — Láser profesional e IPL doméstico pueden reducir vello pero la seguridad y eficacia dependen de fototipo color de pelo dispositivo y operador**  
- Evidencia: Revisiones sistemáticas y guía clínica.
- Población: Personas con diferentes fototipos.
- Resultado medido: Recuento de pelo y eventos adversos.
- Confianza: Probable.
- Límite: No funcionan bien en pelo claro y no garantizan eliminación permanente.
- Fuentes: S042;S043;S048.

**C5-08 — Masaje drenaje endermología y ventosas no producen elevación crecimiento o remodelación glútea permanente**  
- Evidencia: Síntesis clínica y estudios de estimulación mecánica.
- Población: Principalmente mujeres con celulitis.
- Resultado medido: Apariencia temporal.
- Confianza: Probable-alta como límite.
- Límite: No niega cambios transitorios de hidratación o líquidos.
- Fuentes: S046;S047.

**C5-09 — Las ondas acústicas muestran señal favorable para celulitis pero la evidencia procede de mujeres y requiere varias sesiones**  
- Evidencia: Metaanálisis y revisión sistemática de ECA.
- Población: Mujeres con celulitis.
- Resultado medido: Escalas visuales perímetro y ultrasonido.
- Confianza: Moderada en mujeres; incierta en hombre.
- Límite: No corrige grasa general flacidez ni forma muscular.
- Fuentes: S045;S046.

**C5-10 — Radiofrecuencia puede producir cambios modestos y de corta duración por lo que ofrece baja prioridad con presupuesto limitado**  
- Evidencia: Revisión sistemática y síntesis clínica.
- Población: Predominio de mujeres con celulitis.
- Resultado medido: Perímetro grosor y apariencia.
- Confianza: Moderada-baja.
- Límite: No garantiza reafirmación duradera.
- Fuentes: S046;S047.

**C5-11 — Cremas anticelulíticas tienen un efecto medio pequeño y no elevan ni aumentan el glúteo**  
- Evidencia: Revisión sistemática y metaanálisis.
- Población: Principalmente mujeres.
- Resultado medido: Perímetro de muslo y apariencia.
- Confianza: Moderada-baja en mujeres; baja en hombre.
- Límite: No extrapolar reducción de perímetro a mejora estética masculina.
- Fuentes: S044;S047.

**C5-12 — Nódulos profundos recurrentes supuración cicatrices o túneles en glúteos requieren evaluación por posible hidradenitis u otra enfermedad**  
- Evidencia: Guía clínica experta.
- Población: Personas con lesiones recurrentes en pliegues o glúteos.
- Resultado medido: Diagnóstico seguridad y progresión.
- Confianza: Sólida como criterio de derivación.
- Límite: No establece diagnóstico a distancia.
- Fuentes: S039.

### Presentación visual y estética glútea masculina

**C6-01 — La preferencia agregada localizada para glúteo masculino favoreció proyección moderada contorno relativamente estrecho y depresión trocantérica visible**  
- Evidencia: Encuesta transversal con imágenes manipuladas.
- Población: 2095 adultos estadounidenses; 61% hombres.
- Resultado medido: Preferencia visual de vistas lateral oblicua y posterior.
- Confianza: Probable para esa muestra.
- Límite: Un estudio no define un ideal universal ni un resultado entrenable exacto.
- Fuentes: S049.

**C6-02 — Los ratios 1.18 60 grados y 0.66 publicados no son objetivos antropométricos personales**  
- Evidencia: Crítica de aplicabilidad.
- Población: Encuesta digital de un modelo.
- Resultado medido: Preferencia visual.
- Confianza: Sólida como límite de inferencia.
- Límite: Definiciones y encuadre no equivalen a medidas domésticas.
- Fuentes: S049.

**C6-03 — El glúteo debe evaluarse dentro de masa corporal cintura tórax y piernas porque la percepción masculina es global y culturalmente variable**  
- Evidencia: Estudios transversales de percepción.
- Población: Cuerpos masculinos y evaluadores de Hong Kong Reino Unido Malasia y Australia.
- Resultado medido: Atractivo proporciones músculo y grasa.
- Confianza: Probable.
- Límite: Atractivo general no equivale a estética glútea personal.
- Fuentes: S050;S051;S052.

**C6-04 — Los principios de hipertrofia simetría piel y documentación se transfieren entre sexos pero los ideales de máxima redondez anchura y ausencia de hip dip no**  
- Evidencia: Evidencia general más encuesta masculina.
- Población: Adultos mixtos y encuesta específica masculina.
- Resultado medido: Percepción y principios fisiológicos.
- Confianza: Probable.
- Límite: Preferencias individuales pueden diferir del promedio.
- Fuentes: S049;S050;S051.

**C6-05 — Una comparación visual exige mantener cámara lente distancia altura iluminación fondo postura y ropa**  
- Evidencia: Protocolos metodológicos clínicos.
- Población: Pacientes de cirugía plástica y contorno corporal.
- Resultado medido: Reproducibilidad fotográfica.
- Confianza: Sólida como principio documental.
- Límite: No elimina variación biológica ni error de pose.
- Fuentes: S053;S054;S055;S056.

**C6-06 — La distancia cámara-sujeto determina gran parte de la distorsión de perspectiva y debe fijarse antes que el zoom**  
- Evidencia: Principios fotográficos y evidencia técnica indirecta.
- Población: Fotografía clínica y reconstrucción humana 3D.
- Resultado medido: Perspectiva y proporción aparente.
- Confianza: Probable-alta.
- Límite: No se validó una distancia óptima específica para glúteo.
- Fuentes: S054;S055;S056.

**C6-07 — Las fotografías neutrales y las posadas deben conservarse como series distintas**  
- Evidencia: Síntesis metodológica.
- Población: Seguimiento personal.
- Resultado medido: Comparabilidad y presentación.
- Confianza: Probable-alta.
- Límite: La neutralidad absoluta no existe.
- Fuentes: S053;S054;S055.

**C6-08 — La luz difusa y simétrica sirve para seguimiento mientras la luz lateral sirve para presentación y no debe usarse para probar progreso**  
- Evidencia: Protocolos de fotografía clínica más inferencia óptica.
- Población: Pacientes de estética y seguimiento personal.
- Resultado medido: Contorno textura y sombras.
- Confianza: Probable-alta.
- Límite: La piel y el espacio pueden exigir ajustes.
- Fuentes: S053;S054;S055;S056.

**C6-09 — La ropa puede comprimir enmarcar u ocultar el contorno pero la evidencia específica sobre glúteo masculino es insuficiente**  
- Evidencia: Inferencia de estilismo.
- Población: Hombres sin estudio directo suficiente.
- Resultado medido: Silueta con ropa.
- Confianza: Incierta.
- Límite: No hay jerarquía científica de prendas ni marcas.
- Fuentes: S049.

**C6-10 — El vídeo de seguimiento debe usar cámara fija porque una órbita cambia perspectiva distancia y luz**  
- Evidencia: Principios de estandarización fotográfica.
- Población: Seguimiento corporal.
- Resultado medido: Comparabilidad de contorno.
- Confianza: Probable-alta.
- Límite: El movimiento añade variabilidad residual.
- Fuentes: S053;S054;S055.

**C6-12 — Hueso inserciones distribución de grasa y pliegues limitan la forma modificable mediante entrenamiento**  
- Evidencia: Anatomía más límite de aplicabilidad.
- Población: Adultos sanos.
- Resultado medido: Contorno corporal.
- Confianza: Sólida anatómica; incierta en magnitud individual.
- Límite: La contribución exacta exige valoración individual.
- Fuentes: S006;S009;S049.

**C6-11 — Las decisiones visuales requieren 8-12 semanas y varias métricas**  
- Evidencia: Conclusión de fase; formulación aplicada.
- Confianza: Probable práctica.
- Límite: La velocidad individual varía.
- Fuentes: S049;S053;S054.

### Programación avanzada y controversias

**C7-01 — Los sistemas avanzados no producen más hipertrofia en conjunto que las series tradicionales bien igualadas**  
- Evidencia: Metaanálisis.
- Población: Adultos recreativamente entrenados.
- Resultado medido: Hipertrofia y fuerza.
- Confianza: Probable-alta general.
- Límite: No añadirlos esperando crecimiento gratuito.
- Fuentes: S057;S058.

**C7-02 — Las descendentes ahorran tiempo y aumentan esfuerzo percibido sin ventaja crónica demostrada**  
- Evidencia: Metaanálisis de 12 estudios.
- Población: 274 adultos.
- Resultado medido: Hipertrofia fuerza RPE y lactato.
- Confianza: Moderada.
- Límite: No usar quemazón como evidencia.
- Fuentes: S058.

**C7-03 — Las parciales elongadas pueden igualar al ROM completo pero no han demostrado superioridad glútea**  
- Evidencia: Ensayo intrapersonal.
- Población: 30 personas entrenadas.
- Resultado medido: Ecografía y fuerza-resistencia.
- Confianza: Moderada general; baja glútea.
- Límite: No forzar profundidad ni extrapolar tren superior.
- Fuentes: S059.

**C7-04 — Pliometría y sprint son herramientas de potencia y no sustitutos del volumen hipertrófico glúteo**  
- Evidencia: Metaanálisis más estudio transversal.
- Población: Personas sanas y velocistas hombres.
- Resultado medido: Hipertrofia general y volumen MRI.
- Confianza: Probable-alta como límite.
- Límite: No contar 1:1 como series glúteas.
- Fuentes: S063;S064.

**C7-05 — La alta frecuencia distribuye el volumen pero no añade hipertrofia cuando el volumen se iguala**  
- Evidencia: Metaanálisis previo más ensayo.
- Población: Adultos entrenados.
- Resultado medido: Masa muscular y fuerza.
- Confianza: Sólida general.
- Límite: No aumentar volumen por aumentar frecuencia.
- Fuentes: S012;S072.

**C7-06 — Las microseries productivas consumen volumen y recuperación mientras las activaciones fáciles no cuentan**  
- Evidencia: Revisión de alcance más inferencia.
- Población: Poblaciones diversas; poca evidencia en entrenados.
- Resultado medido: Función salud y aptitud.
- Confianza: Probable práctica; baja hipertrófica.
- Límite: No presentarlas como volumen gratis.
- Fuentes: S065.

**C7-07 — La caída sostenida del rendimiento es la señal más defendible de exceso de carga; ningún biomarcador aislado basta**  
- Evidencia: Revisión sistemática exploratoria.
- Población: Adultos de fuerza.
- Resultado medido: Rendimiento y síntomas.
- Confianza: Probable-alta como criterio.
- Límite: No diagnosticar por agujetas o humor aislado.
- Fuentes: S070.

**C7-08 — Una descarga reactiva puede reducir fatiga pero no mejora por sí sola la hipertrofia**  
- Evidencia: Dos ensayos longitudinales.
- Población: 39 entrenados mixtos y 19 hombres novatos.
- Resultado medido: Hipertrofia fuerza y resistencia.
- Confianza: Probable.
- Límite: No imponer cese total periódico.
- Fuentes: S066;S067.

**C7-09 — Unilateral y bilateral producen hipertrofia similar en promedio y la fuerza es específica**  
- Evidencia: Metaanálisis.
- Población: Adultos de 9 estudios.
- Resultado medido: Hipertrofia y fuerza.
- Confianza: Moderada.
- Límite: No añadir volumen unilateral automáticamente.
- Fuentes: S069.

**C7-10 — La técnica debe adaptarse a antropometría tolerancia y limitante porque tronco tibia postura y profundidad cambian los momentos**  
- Evidencia: Revisión biomecánica.
- Población: Adultos sanos y clínicos.
- Resultado medido: Cinemática y cinética.
- Confianza: Probable biomecánica.
- Límite: No imponer anchura o inclinación universales.
- Fuentes: S071.

**C7-11 — Periodizar organiza fuerza y fatiga pero no supera en hipertrofia a programas no periodizados con volumen igualado**  
- Evidencia: Metaanálisis.
- Población: Adultos de estudios de fuerza.
- Resultado medido: 1RM e hipertrofia.
- Confianza: Sólida general.
- Límite: No atribuir crecimiento a complejidad del calendario.
- Fuentes: S061.

**C7-12 — La selección debe variar de forma sistemática y conservar ejercicios índice**  
- Evidencia: Revisión sistemática.
- Población: 241 hombres jóvenes.
- Resultado medido: Hipertrofia regional y fuerza.
- Confianza: Probable.
- Límite: No rotar semanalmente por novedad.
- Fuentes: S062.

## 5. Reconciliaciones que deben acompañar a las conclusiones

### 5.1 Hip thrust y sentadilla

El ensayo MRI directo S002 permite afirmar hipertrofia glútea semejante en la muestra estudiada y mayor crecimiento de cuádriceps/aductores con sentadilla. **No permite afirmar que el hip thrust produzca más hipertrofia glútea.** Su ventaja práctica cuando se quiere contener el crecimiento de muslo es de especificidad relativa, no de superioridad glútea demostrada.

### 5.2 Regionalización y longitud muscular

La anatomía y algunas mediciones justifican hablar de heterogeneidad regional y de efectos potencialmente distintos del ROM/longitud. No justifican prometer aislamiento exacto de “glúteo superior/inferior” mediante un ejercicio, ángulo de pie o inclinación concreta. Un ROM amplio y tolerado es una base razonable; las parciales elongadas son una herramienta contextual, no un dogma.

### 5.3 Volumen, frecuencia y esfuerzo

El volumen muestra una relación dosis–respuesta con rendimientos decrecientes. La frecuencia sirve sobre todo para distribuir el volumen. El fallo no es obligatorio: acercarse suficientemente al fallo parece relevante, pero no existe un RIR óptimo exacto universal. El conteo fraccional de series indirectas es una herramienta de modelado, no una medición fisiológica exacta por ejercicio.

### 5.4 Revisión S001

S001 es útil para sostener la conclusión general de que el entrenamiento de resistencia puede hipertrofiar el glúteo mayor. Para comparar ejercicios concretos se priorizan los ensayos directos S002–S004 y otros estudios primarios pertinentes, porque la revisión reúne literatura heterogénea y el propio corpus registra reservas metodológicas sobre parte de los estudios incluidos.

### 5.5 Estética poblacional

Los estudios de percepción S049–S052 aportan contexto sobre cómo determinadas muestras valoran cuerpos masculinos. No establecen un techo personal de muscularidad, un ratio corporal objetivo ni una forma glútea obligatoria. Las preferencias actuales del usuario prevalecen sobre el promedio de una muestra de observadores.

### 5.6 Piel

Las guías de acné, queratosis, depilación o foliculitis informan ramas condicionales; no permiten diagnosticar unos “granitos” sin observar morfología y evolución. Las recomendaciones operativas deben mantener esta separación.

## 6. Registro de estudios S001–S072

### Glúteo: anatomía e hipertrofia

#### S001 — Krause Neto W et al. The impact of resistance training on gluteus maximus hypertrophy

- Año: 2025.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos sanos 18-45 años. Sexo: Mixta. n: 12 artículos. Experiencia: Mixta.
- Duración: 5+ semanas.
- Intervención/comparación: Entrenamiento de extensión de cadera con resistencia | comparador: Pre-post y subgrupos.
- Medida: Ecografía o MRI.
- Resultado principal: Efecto moderado SMD 0.71 IC95% 0.50-0.91.
- Limitaciones: Heterogeneidad metodológica; análisis principalmente pre-post; incluye estudios cuestionados.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.3389/fphys.2025.1542334

#### S002 — Plotkin DL et al. Hip thrust and back squat training elicit similar gluteus muscle hypertrophy

- Año: 2023.
- Diseño: Ensayo aleatorizado longitudinal.
- Población: Jóvenes 18-30 años. Sexo: Mixta: 11 hombres y 23 mujeres. n: 34. Experiencia: No entrenados.
- Duración: 9 semanas.
- Intervención/comparación: Hip thrust o sentadilla 2x/semana con series igualadas | comparador: Hip thrust vs sentadilla.
- Medida: MRI mCSA y fuerza; sEMG secundaria.
- Resultado principal: Hipertrofia similar en GMax superior medio e inferior; sentadilla aumentó más cuádriceps y aductores.
- Limitaciones: Corto; novatos; mayoría mujeres; solo 2x/semana.
- Confianza: Moderada-alta.
- DOI/URL: https://doi.org/10.3389/fphys.2023.1279170

#### S003 — Kubo K et al. Effects of squat training with different depths on lower limb muscle volumes

- Año: 2019.
- Diseño: Ensayo longitudinal aleatorizado.
- Población: Hombres jóvenes sanos. Sexo: Hombres. n: 17. Experiencia: No entrenados o poca experiencia.
- Duración: 10 semanas.
- Intervención/comparación: Sentadilla completa o media 2x/semana | comparador: Completa vs media.
- Medida: MRI volumen muscular y 1RM.
- Resultado principal: GMax +6.7% vs +2.2%; aductores +6.2% vs +2.7%.
- Limitaciones: Muestra pequeña; no aísla longitud muscular; novatos.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1007/s00421-019-04181-y

#### S004 — Kinoshita M et al. Hypertrophic Effects of Single- versus Multi-Joint Exercise

- Año: 2026.
- Diseño: Ensayo longitudinal intrapersonal.
- Población: Adultos jóvenes sanos. Sexo: 11 hombres y 6 mujeres. n: 17. Experiencia: No entrenados.
- Duración: 12 semanas.
- Intervención/comparación: Prensa unilateral 5x10 70% 1RM 2x/semana | comparador: Extensión de rodilla contralateral.
- Medida: MRI volumen de 17 músculos.
- Resultado principal: Prensa aumentó GMax 15.4% y aductor mayor 6.2%.
- Limitaciones: Novatos; máquina y ROM concretos; diseño unilateral.
- Confianza: Moderada-alta.
- DOI/URL: https://doi.org/10.1249/MSS.0000000000003957

#### S005 — Rostron ZPJ et al. Targeted resistance intervention on gluteal hypertrophy in hip OA

- Año: 2022.
- Diseño: Ensayo clínico aleatorizado; análisis secundario.
- Población: Personas 41-75 años con artrosis de cadera. Sexo: 14 hombres y 13 mujeres. n: 27. Experiencia: Clínica; no definida como entrenada.
- Duración: 12 semanas.
- Intervención/comparación: Programa glúteo dirigido multicomponente | comparador: Ejercicio simulado de baja intensidad.
- Medida: MRI volumen y dinamometría.
- Resultado principal: GMin aumentó aproximadamente 4%; GMed y GMax sin cambio significativo.
- Limitaciones: Población clínica; muestra pequeña; programa multicomponente.
- Confianza: Baja para estética sana.
- DOI/URL: https://doi.org/10.1186/s12891-022-05907-4

#### S006 — Anetai H et al. Structural re-evaluation of the human gluteus maximus

- Año: 2025.
- Diseño: Estudio anatómico cadavérico.
- Población: Cadáveres adultos japoneses ancianos. Sexo: 14 hombres y 11 mujeres. n: 25. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Disección in situ y aislada; PCSA en 9 especímenes | comparador: Sin comparador de entrenamiento.
- Medida: Disección y estimación PCSA.
- Resultado principal: Porción superior ~77% PCSA; inserción principalmente femoral; porción inferior con fibras más largas.
- Limitaciones: Cadáveres ancianos; no prueba función in vivo ni hipertrofia selectiva.
- Confianza: Moderada anatómica.
- DOI/URL: https://doi.org/10.1038/s41598-025-05361-x

#### S007 — Németh G y Ohlsén H. In vivo moment arm lengths for hip extensor muscles

- Año: 1985.
- Diseño: Biomecánica anatómica e imagen.
- Población: 10 autopsias y 20 pacientes. Sexo: Mixta. n: 30. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Cálculo de brazos de momento entre 0 y 90 grados de flexión | comparador: Ángulos de cadera.
- Medida: CT y modelo de líneas de acción.
- Resultado principal: Brazo extensor de GMax disminuyó al aumentar flexión.
- Limitaciones: Estudio antiguo; modelo simplificado; no mide hipertrofia.
- Confianza: Moderada biomecánica.
- DOI/URL: https://doi.org/10.1016/0021-9290(85)90005-3

#### S008 — Kassiano W et al. Which ROMs Lead to Rome?

- Año: 2023.
- Diseño: Revisión sistemática.
- Población: Adultos sanos. Sexo: Mixta. n: 11 estudios. Experiencia: Mixta.
- Duración: 4+ semanas.
- Intervención/comparación: ROM completo o parcial en distintas zonas | comparador: ROM largo vs corto.
- Medida: Medidas de hipertrofia variables.
- Resultado principal: Tendencia favorable a entrenar en longitudes mayores; señal glútea basada en sentadilla.
- Limitaciones: Pocos datos específicos del glúteo; heterogeneidad.
- Confianza: Moderada general; baja específica.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/36662126/

#### S009 — Semciw AI et al. Verification of electrode insertion into gluteus minimus and medius segments

- Año: 2013.
- Diseño: Estudio anatómico cadavérico.
- Población: Cadáveres humanos. Sexo: No detallado en resumen. n: No detallado en resumen. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Verificación de dos segmentos GMin y tres GMed | comparador: Sin comparador de hipertrofia.
- Medida: Disección y colocación intramuscular.
- Resultado principal: Respalda orientaciones segmentarias y medición diferenciada.
- Limitaciones: No mide crecimiento ni rendimiento.
- Confianza: Moderada anatómica.
- DOI/URL: https://doi.org/10.1002/ca.22055

#### S010 — Barbalho M et al. Back Squat vs Hip Thrust in well-trained women

- Año: 2020.
- Diseño: Ensayo longitudinal publicado.
- Población: Mujeres bien entrenadas. Sexo: Mujeres. n: 22. Experiencia: Entrenadas.
- Duración: 12 semanas.
- Intervención/comparación: Sentadilla o hip thrust | comparador: Comparación directa.
- Medida: Ecografía y 1RM.
- Resultado principal: Publicó mayor hipertrofia con sentadilla.
- Limitaciones: Patrones de datos y metodología cuestionados por investigadores posteriores; detalles insuficientes.
- Confianza: Restringida.
- DOI/URL: https://doi.org/10.1055/a-1082-1126

### Dosificación, esfuerzo y progresión

#### S011 — Pelland JC et al. The Resistance Training Dose Response

- Año: 2026.
- Diseño: Revisión sistemática y metarregresiones multinivel.
- Población: Adultos; edad media 25.16 ± 5.22 años. Sexo: 79.1% hombres y 20.9% mujeres. n: 2058. Experiencia: Mixta; modelos ajustados por experiencia.
- Duración: 67 estudios.
- Intervención/comparación: Volumen y frecuencia semanales; series directas e indirectas | comparador: Diferentes dosis de entrenamiento.
- Medida: Medidas de hipertrofia y fuerza de estudios longitudinales.
- Resultado principal: Más volumen se asoció con más hipertrofia con rendimientos decrecientes; frecuencia compatible con efecto pequeño o nulo.
- Limitaciones: No específica de glúteo; población joven; metarregresión observacional entre protocolos.
- Confianza: Moderada-alta general.
- DOI/URL: https://doi.org/10.1007/s40279-025-02344-w

#### S012 — Schoenfeld BJ et al. How many times per week should a muscle be trained

- Año: 2019.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de estudios de entrenamiento. Sexo: Mixta. n: 25 estudios. Experiencia: Mixta; análisis específico de entrenados.
- Duración: Variable.
- Intervención/comparación: Frecuencias semanales altas y bajas | comparador: Volumen igualado o no igualado.
- Medida: Medidas directas e indirectas de crecimiento.
- Resultado principal: Sin diferencia significativa de hipertrofia cuando el volumen se igualó.
- Limitaciones: Heterogeneidad; no específica de glúteo; protocolos mayoritariamente cortos.
- Confianza: Moderada-alta.
- DOI/URL: https://doi.org/10.1080/02640414.2018.1555906

#### S013 — Currier BS et al. Resistance training prescription for muscle strength and hypertrophy

- Año: 2023.
- Diseño: Revisión sistemática y metaanálisis de red bayesiano.
- Población: Adultos sanos. Sexo: 47% mujeres en la red de hipertrofia. n: 3364. Experiencia: Mixta.
- Duración: 119 estudios de hipertrofia.
- Intervención/comparación: Combinaciones de carga series y frecuencia | comparador: Control sin ejercicio y otras prescripciones.
- Medida: Medidas de hipertrofia y fuerza.
- Resultado principal: Todas las prescripciones mejoraron hipertrofia; múltiples series ocuparon los primeros puestos; cargas altas favorecieron fuerza.
- Limitaciones: Comparaciones de red; no específica de glúteo; rankings no equivalen a superioridad clínica individual.
- Confianza: Moderada-alta general.
- DOI/URL: https://doi.org/10.1136/bjsports-2023-106807

#### S014 — Carvalho L et al. Muscle hypertrophy and strength gains after resistance training with different volume-matched loads

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de estudios de entrenamiento. Sexo: Mixta o variable. n: No indicado en el resumen consultado. Experiencia: Mixta.
- Duración: Variable.
- Intervención/comparación: Cargas muy bajas bajas moderadas y altas con volumen-carga igualado | comparador: Comparación entre magnitudes de carga.
- Medida: Medidas de hipertrofia y fuerza dinámica.
- Resultado principal: Hipertrofia similar entre cargas; 1RM favoreció cargas altas.
- Limitaciones: Igualar volumen-carga no iguala necesariamente esfuerzo ni series; no específica de glúteo.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1139/apnm-2021-0515

#### S015 — Grgic J et al. Resistance training to repetition failure or non-failure

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos jóvenes. Sexo: No especificado en el resumen. n: 15 estudios. Experiencia: Entrenados y no entrenados.
- Duración: Variable.
- Intervención/comparación: Series al fallo muscular | comparador: Series sin llegar al fallo.
- Medida: Hipertrofia y fuerza.
- Resultado principal: Sin diferencia global significativa en hipertrofia; pequeña ventaja del fallo en subgrupo entrenado.
- Limitaciones: Todos jóvenes; pocos altamente entrenados; definiciones de fallo variables.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1016/j.jshs.2021.01.007

#### S016 — Robinson ZP et al. Dose-response between estimated proximity to failure strength and hypertrophy

- Año: 2024.
- Diseño: Revisión sistemática y metarregresiones exploratorias.
- Población: Adultos de estudios de entrenamiento. Sexo: Variable. n: No indicado en el resumen consultado. Experiencia: Mixta; ajuste por experiencia.
- Duración: Variable.
- Intervención/comparación: RIR estimado de las intervenciones | comparador: Diferentes proximidades al fallo.
- Medida: Medidas de hipertrofia y fuerza.
- Resultado principal: La hipertrofia aumentó al terminar más cerca del fallo; fuerza mostró relación despreciable.
- Limitaciones: RIR estimado no medido; ajuste global modesto; relación exacta incierta.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1007/s40279-024-02069-2

#### S017 — Refalo MC et al. Failure versus repetitions in reserve in resistance-trained individuals

- Año: 2024.
- Diseño: Ensayo longitudinal intrapersonal.
- Población: Personas entrenadas. Sexo: 12 hombres y 6 mujeres. n: 18. Experiencia: Entrenadas.
- Duración: 8 semanas.
- Intervención/comparación: Prensa y extensión de rodilla al fallo | comparador: Mismos ejercicios a 2 RIR y 1 RIR.
- Medida: Ecografía de recto femoral y vasto lateral; fatiga aguda.
- Resultado principal: Hipertrofia de cuádriceps similar; el fallo produjo más pérdida de velocidad y repeticiones.
- Limitaciones: Muestra pequeña; cuádriceps no glúteo; intervención corta.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1080/02640414.2024.2321021

#### S018 — Singer A et al. Give it a rest

- Año: 2024.
- Diseño: Revisión sistemática y metaanálisis bayesiano.
- Población: Adultos sanos. Sexo: No especificado en el resumen. n: 9 estudios y 19 mediciones. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Intervalos entre series ≤60 s y >60 s; cuatro categorías | comparador: Comparación de duraciones de descanso.
- Medida: Masa magra grosor o sección transversal.
- Resultado principal: Pequeña tendencia favorable a >60 s; sin diferencias apreciables al superar 90 s.
- Limitaciones: Heterogeneidad sustancial; pocos estudios; no específica de glúteo.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.3389/fspor.2024.1429789

#### S019 — Baz-Valle E et al. Effects of different resistance training volumes on muscle hypertrophy

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Hombres entrenados de 18-35 años con al menos un año de experiencia. Sexo: Hombres. n: 7 estudios; 6 en análisis cuantitativo. Experiencia: Entrenados.
- Duración: 6+ semanas.
- Intervención/comparación: Volumen bajo <12 moderado 12-20 y alto >20 series semanales | comparador: Comparación de categorías de volumen.
- Medida: Grosor muscular o sección transversal.
- Resultado principal: Sin diferencia moderado-alto para cuádriceps o bíceps; alto favoreció tríceps.
- Limitaciones: Pocos estudios; músculos no glúteos; categorías amplias; jóvenes.
- Confianza: Baja-moderada para este perfil.
- DOI/URL: https://doi.org/10.2478/hukin-2022-0017

#### S020 — Chaves TS et al. Effects of Resistance Training Overload Progression Protocols

- Año: 2024.
- Diseño: Ensayo aleatorizado intrapersonal.
- Población: Jóvenes no entrenados. Sexo: 20 hombres y 19 mujeres. n: 39. Experiencia: No entrenados.
- Duración: 10 semanas.
- Intervención/comparación: Progresión aumentando carga | comparador: Progresión aumentando repeticiones.
- Medida: Ecografía de vasto lateral y 1RM de extensión de rodilla.
- Resultado principal: Ambos protocolos aumentaron de forma similar fuerza y sección transversal.
- Limitaciones: Novatos; cuádriceps; no glúteo; intervención corta.
- Confianza: Moderada general; baja específica.
- DOI/URL: https://doi.org/10.1055/a-2256-5857

#### S021 — Kassiano W et al. Progressive Overload Affects the Magnitude of Muscle Hypertrophy

- Año: 2026.
- Diseño: Ensayo aleatorizado intrapersonal.
- Población: Mujeres jóvenes no entrenadas. Sexo: Mujeres. n: 55. Experiencia: No entrenadas.
- Duración: 8 semanas.
- Intervención/comparación: Extensión unilateral de codo con progresión de carga en 8-12 repeticiones | comparador: Carga y repeticiones constantes; control sin ejercicio.
- Medida: Ecografía de tríceps en dos sitios.
- Resultado principal: Ambos entrenamientos hipertrofiaron; progresión produjo mayor crecimiento.
- Limitaciones: Mujeres novatas; tríceps; ocho semanas; no glúteo.
- Confianza: Moderada general; baja específica.
- DOI/URL: https://doi.org/10.1249/MSS.0000000000003968

### Biomecánica y ejercicios glúteos

#### S022 — Collings TJ et al. Gluteal Muscle Forces during Hip-Focused Exercises

- Año: 2023.
- Diseño: Estudio biomecánico con modelo musculoesquelético informado por EMG.
- Población: Futbolistas de 18-32 años. Sexo: Mujeres. n: 14. Experiencia: Al menos 3 meses de fuerza.
- Duración: Agudo.
- Intervención/comparación: Ocho ejercicios con peso corporal y carga 12RM | comparador: Comparación entre ejercicios y cargas.
- Medida: Fuerza muscular estimada longitud de fibra velocidad y EMG.
- Resultado principal: Split squat RDL unilateral e hip thrust unilateral cargados fueron nivel superior para fuerza de GMax; RDL unilateral también para GMed y GMin.
- Limitaciones: Modelo estimado; muestra pequeña femenina; no mide hipertrofia.
- Confianza: Moderada biomecánica; baja longitudinal.
- DOI/URL: https://doi.org/10.1249/MSS.0000000000003091

#### S023 — Andersen V et al. Muscle Activity in Three Single-Joint Hip Extension Exercises

- Año: 2021.
- Diseño: Ensayo agudo cruzado.
- Población: Personas entrenadas. Sexo: Mujeres. n: 15. Experiencia: Entrenadas.
- Duración: Una sesión.
- Intervención/comparación: RDL hiperextensión a 45 grados y extensión lumbar sentada a 6RM | comparador: Comparación de ejercicios.
- Medida: EMG de GMax bíceps femoral y erectores.
- Resultado principal: RDL e hiperextensión mostraron mayor activación de GMax que máquina sentada; hiperextensión mayor para bíceps femoral.
- Limitaciones: EMG aguda; solo mujeres; no mide fuerza interna ni hipertrofia.
- Confianza: Baja para hipertrofia.
- DOI/URL: https://doi.org/10.52082/jssm.2021.181

#### S024 — Moore D et al. Therapeutic Exercises for Gluteus Medius and Minimus Segments

- Año: 2020.
- Diseño: Revisión sistemática y metaanálisis de EMG.
- Población: Adultos de estudios terapéuticos y sanos. Sexo: Mixta. n: 56 estudios. Experiencia: Variable.
- Duración: Agudo.
- Intervención/comparación: Abducciones hip hitch puentes step-up y tareas unilaterales | comparador: Comparación de actividad segmentaria.
- Medida: EMG segmentaria.
- Resultado principal: Varias abducciones e hip hitch generaron actividad alta en segmentos de GMed y GMin.
- Limitaciones: EMG no predice hipertrofia; heterogeneidad; finalidad clínica.
- Confianza: Baja para hipertrofia; moderada para función.
- DOI/URL: https://doi.org/10.26603/ijspt20200856

#### S025 — Krause Neto W et al. Gluteus Maximus Activation during Common Strength and Hypertrophy Exercises

- Año: 2020.
- Diseño: Revisión sistemática de EMG.
- Población: Adultos de estudios de fuerza. Sexo: Mixta. n: 16 estudios. Experiencia: Variable.
- Duración: Agudo.
- Intervención/comparación: Step-ups deadlifts hip thrusts zancadas sentadillas y variantes | comparador: Comparación de activación normalizada.
- Medida: EMG superficial.
- Resultado principal: Numerosos ejercicios superaron 60% MVIC; step-up ocupó puestos altos.
- Limitaciones: Activación aguda no mide hipertrofia; normalización y técnicas heterogéneas.
- Confianza: Baja para hipertrofia.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/32132843/

### Nutrición, recuperación y concurrente

#### S026 — Murphy C y Koehler K. Energy deficiency impairs resistance training gains in lean mass but not strength

- Año: 2022.
- Diseño: Revisión sistemática metaanálisis y metarregresión.
- Población: Adultos sanos en entrenamiento de resistencia. Sexo: Mixta. n: Datos de intervenciones de 3 o más semanas. Experiencia: Mixta.
- Duración: 3 o más semanas.
- Intervención/comparación: Entrenamiento de resistencia bajo déficit energético | comparador: Entrenamiento sin déficit.
- Medida: Masa magra y fuerza.
- Resultado principal: El déficit perjudicó la ganancia de masa magra pero no mostró una pérdida comparable de fuerza; ~500 kcal/día anuló la ganancia media estimada.
- Limitaciones: Heterogeneidad; déficit estimado; no específica de glúteo ni de hombres entrenados de mediana edad.
- Confianza: Moderada-alta general.
- DOI/URL: https://doi.org/10.1111/sms.14075

#### S027 — Morton RW et al. Protein supplementation and resistance training adaptations

- Año: 2018.
- Diseño: Revisión sistemática metaanálisis y metarregresión.
- Población: Adultos sanos que entrenaron fuerza. Sexo: Mixta. n: 1863. Experiencia: Entrenados y no entrenados.
- Duración: 49 estudios de 6 o más semanas.
- Intervención/comparación: Suplementación proteica junto con entrenamiento de resistencia | comparador: Placebo o menor ingesta proteica.
- Medida: 1RM masa libre de grasa CSA y fibras.
- Resultado principal: Mejoras pequeñas de 1RM y masa libre de grasa; saturación media estimada alrededor de 1.62 g/kg/día.
- Limitaciones: Suplementación no equivale a dieta completa; predominio de adultos jóvenes; no específica de glúteo.
- Confianza: Alta general.
- DOI/URL: https://doi.org/10.1136/bjsports-2017-097608

#### S028 — Jespersen KV y Agergaard J. Protein intake distribution and skeletal muscle-related outcomes

- Año: 2021.
- Diseño: Revisión sistemática.
- Población: Adultos de 20 a 85 años. Sexo: Mixta. n: 15 estudios. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Distribución más uniforme o concentrada de proteína | comparador: Patrones alternativos de distribución.
- Medida: Masa muscular fuerza y metabolismo proteico.
- Resultado principal: Algunas asociaciones con masa muscular pero evidencia insuficiente para fuerza o recambio proteico.
- Limitaciones: Estudios heterogéneos; varios observacionales; edades y dosis variables.
- Confianza: Moderada-baja.
- DOI/URL: https://doi.org/10.1007/s00394-021-02487-2

#### S029 — Yasuda J et al. Evenly distributed protein intake over 3 meals augments resistance exercise-induced muscle hypertrophy

- Año: 2020.
- Diseño: Ensayo longitudinal controlado.
- Población: Hombres jóvenes sanos. Sexo: Hombres. n: 26. Experiencia: No especificada como avanzada.
- Duración: 12 semanas.
- Intervención/comparación: Entrenamiento 3x/semana con 1.3 g/kg/día y desayuno de 0.33 g/kg | comparador: Misma proteína total con desayuno de 0.12 g/kg.
- Medida: Masa magra y fuerza.
- Resultado principal: Señal favorable a distribución uniforme; masa magra +2.5 vs +1.8 kg con p=0.06.
- Limitaciones: Muestra pequeña; hombres jóvenes; diferencia principal no significativa; proteína total moderada.
- Confianza: Baja-moderada.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/32321161/

#### S030 — Longland TM et al. Higher compared with lower dietary protein during energy deficit and intense exercise

- Año: 2016.
- Diseño: Ensayo aleatorizado.
- Población: Hombres jóvenes. Sexo: Hombres. n: 40. Experiencia: Recreacionalmente activos.
- Duración: 4 semanas.
- Intervención/comparación: Déficit energético intenso entrenamiento de alto volumen y 2.4 g/kg/día de proteína | comparador: Mismo programa con 1.2 g/kg/día.
- Medida: Masa magra y grasa corporal.
- Resultado principal: El grupo alto en proteína ganó más masa magra y perdió más grasa.
- Limitaciones: Muy corto; déficit y ejercicio extremos; jóvenes; no específico de entrenados avanzados.
- Confianza: Moderada como prueba de principio.
- DOI/URL: https://doi.org/10.3945/ajcn.115.119339

#### S031 — Garthe I et al. Effect of two different weight-loss rates on body composition and strength in elite athletes

- Año: 2011.
- Diseño: Ensayo longitudinal comparativo.
- Población: Atletas de élite. Sexo: Mixta. n: 24. Experiencia: Entrenados.
- Duración: Variable hasta alcanzar objetivo.
- Intervención/comparación: Pérdida aproximada de 0.7% del peso por semana más entrenamiento de fuerza | comparador: Pérdida aproximada de 1.4% por semana.
- Medida: DEXA fuerza potencia y peso.
- Resultado principal: La pérdida lenta produjo evolución más favorable de masa magra y rendimiento.
- Limitaciones: Muestra pequeña; deportistas; duración desigual; no específico de hipertrofia glútea.
- Confianza: Moderada indirecta.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/21558571/

#### S032 — Roth C et al. Resistance exercise volume during caloric restriction in resistance-trained males

- Año: 2023.
- Diseño: Ensayo aleatorizado.
- Población: Hombres entrenados en fuerza. Sexo: Hombres. n: 38. Experiencia: Entrenados.
- Duración: 6 semanas.
- Intervención/comparación: Déficit con alto volumen de entrenamiento y 2.8 g/kg de masa libre de grasa de proteína | comparador: Déficit con volumen moderado.
- Medida: Composición corporal y rendimiento.
- Resultado principal: Ambos grupos perdieron peso y masa magra sin ventaja del volumen alto.
- Limitaciones: Intervención corta; prescripción energética concreta; muestra moderada.
- Confianza: Moderada.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/36114738/

#### S033 — Saner NJ et al. Sleep restriction and myofibrillar protein synthesis

- Año: 2020.
- Diseño: Ensayo controlado mecanístico.
- Población: Hombres jóvenes sanos. Sexo: Hombres. n: 24. Experiencia: No especificada.
- Duración: 5 noches.
- Intervención/comparación: Cuatro horas de tiempo en cama con o sin HIIT | comparador: Ocho horas de tiempo en cama.
- Medida: Síntesis proteica mediante trazadores.
- Resultado principal: La restricción redujo la síntesis proteica miofibrilar; HIIT mantuvo la tasa en este protocolo.
- Limitaciones: Agudo; jóvenes; no mide hipertrofia longitudinal; HIIT no es una solución clínica.
- Confianza: Moderada mecanística; baja longitudinal.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/32078168/

#### S034 — Schumann M et al. Compatibility of concurrent aerobic and strength training for skeletal muscle size and function

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos sanos. Sexo: Mixta. n: 43 estudios. Experiencia: Entrenados y no entrenados.
- Duración: Variable.
- Intervención/comparación: Entrenamiento aeróbico y de fuerza concurrente | comparador: Entrenamiento de fuerza aislado.
- Medida: Hipertrofia fuerza máxima y fuerza explosiva.
- Resultado principal: Sin interferencia significativa en hipertrofia o fuerza máxima; pequeña reducción de fuerza explosiva sobre todo en la misma sesión.
- Limitaciones: Protocolos heterogéneos; calidad variable; no específico de glúteo.
- Confianza: Moderada-alta general.
- DOI/URL: https://doi.org/10.1007/s40279-021-01587-7

#### S035 — Bickel CS et al. Exercise dosing to retain resistance training adaptations in young and older adults

- Año: 2011.
- Diseño: Ensayo longitudinal aleatorizado.
- Población: Adultos jóvenes de 20-35 y mayores de 60-75 años. Sexo: Mixta. n: 70. Experiencia: No especificada como entrenada.
- Duración: 16 semanas de entrenamiento y 32 de mantenimiento.
- Intervención/comparación: Mantenimiento con un tercio o una novena parte de la dosis inicial | comparador: Desentrenamiento.
- Medida: Masa muscular y fuerza.
- Resultado principal: En jóvenes ambas dosis conservaron hipertrofia; en mayores un tercio preservó mejor todas las adaptaciones.
- Limitaciones: No incluye específicamente mediana edad; fase inicial en no entrenados; tren inferior.
- Confianza: Moderada indirecta.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/21131862/

#### S036 — Desai I et al. Effects of creatine supplementation on body composition in adults under 50

- Año: 2024.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos menores de 50 años que entrenaron fuerza. Sexo: Mixta. n: 12 estudios. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Creatina junto con entrenamiento de resistencia | comparador: Placebo y entrenamiento.
- Medida: Composición corporal.
- Resultado principal: Incremento medio de masa libre de grasa de 1.14 kg y pequeñas reducciones de masa y porcentaje graso.
- Limitaciones: Heterogeneidad de dosis y mediciones; cambios de agua pueden afectar masa libre de grasa.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1519/JSC.0000000000004862

### Piel, depilación y tratamientos

#### S037 — Reynolds RV et al. Guidelines of care for the management of acne vulgaris

- Año: 2024.
- Diseño: Guía clínica basada en evidencia.
- Población: Personas con acné vulgar. Sexo: Mixta. n: Revisión de evidencia para 18 recomendaciones. Experiencia: Variable.
- Duración: No aplica.
- Intervención/comparación: Tratamientos tópicos sistémicos y físicos | comparador: Comparaciones múltiples.
- Medida: Lesiones de acné seguridad y práctica clínica.
- Resultado principal: Recomendaciones fuertes para peróxido de benzoilo y retinoides; condicionales para salicílico y azelaico.
- Limitaciones: Se dirige a acné y no confirma etiología de lesiones glúteas; evidencia procedimental insuficiente.
- Confianza: Alta para acné; indirecta para lesiones no diagnosticadas.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/38300170/

#### S038 — Lin HS et al. Interventions for bacterial folliculitis and boils

- Año: 2021.
- Diseño: Revisión sistemática Cochrane.
- Población: Personas con foliculitis bacteriana o forúnculos. Sexo: Mixta. n: 18 estudios incluidos según revisión. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Antibióticos antisépticos fototerapia y cirugía | comparador: Comparaciones múltiples.
- Medida: Curación clínica y eventos adversos.
- Resultado principal: Evidencia insuficiente y de certeza muy baja para establecer superioridad fiable de las intervenciones.
- Limitaciones: Pocos ensayos pequeños y heterogéneos; escasa evidencia para antisépticos tópicos.
- Confianza: Baja.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/33634465/

#### S039 — American Academy of Dermatology. Acne-like breakouts could be folliculitis

- Año: 2026.
- Diseño: Guía clínica pública experta.
- Población: Personas con lesiones foliculares. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Evitar desencadenante compresas tibias higiene y valoración dermatológica | comparador: Sin comparador.
- Medida: Síntomas prevención y seguridad.
- Resultado principal: Fricción ropa ajustada sudor y depilación pueden dañar folículos; algunos casos requieren medicación.
- Limitaciones: No es ensayo ni distingue todas las etiologías.
- Confianza: Moderada como orientación clínica.
- DOI/URL: https://www.aad.org/public/diseases/a-z/folliculitis

#### S040 — American Academy of Dermatology. Keratosis pilaris diagnosis and treatment

- Año: 2026.
- Diseño: Guía clínica pública experta.
- Población: Personas con queratosis pilaris. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Hidratación urea ácido láctico salicílico retinoides y procedimientos | comparador: Sin comparador.
- Medida: Textura sequedad y bultos.
- Resultado principal: Los queratolíticos e hidratantes pueden mejorar textura; se requiere mantenimiento.
- Limitaciones: Recomendaciones clínicas con evidencia específica limitada y sin foco glúteo masculino.
- Confianza: Moderada clínica.
- DOI/URL: https://www.aad.org/public/diseases/a-z/keratosis-pilaris-treatment

#### S041 — Marwaha S et al. Treatment of post-inflammatory hyperpigmentation in skin of colour

- Año: 2024.
- Diseño: Revisión sistemática.
- Población: Personas con piel de color e hiperpigmentación posinflamatoria. Sexo: Mixta. n: 1356. Experiencia: No aplica.
- Duración: 46 estudios.
- Intervención/comparación: Tópicos láseres y otras intervenciones | comparador: Sin tratamiento o comparadores activos.
- Medida: Escalas de PIH y mejoría clínica.
- Resultado principal: Retinoides láser y thiamidol mostraron señales; irritación por retinoides puede empeorar pigmentación.
- Limitaciones: Heterogeneidad; muchas intervenciones faciales; pocos datos corporales.
- Confianza: Moderada general; baja específica glútea.
- DOI/URL: https://pmc.ncbi.nlm.nih.gov/articles/11514325/

#### S042 — Ash C et al. Home-based devices in dermatology safety and efficacy

- Año: 2022.
- Diseño: Revisión sistemática.
- Población: Usuarios de dispositivos dermatológicos domésticos. Sexo: Mixta. n: Estudios de múltiples dispositivos. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: IPL y otros dispositivos de uso doméstico | comparador: Controles diversos.
- Medida: Recuento de pelo y eventos adversos.
- Resultado principal: Dispositivos IPL domésticos mostraron eficacia para reducción de vello con necesidad de uso continuado.
- Limitaciones: Dispositivos heterogéneos; conflictos potenciales; la compatibilidad piel-pelo es esencial.
- Confianza: Moderada.
- DOI/URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC8918178/

#### S043 — Dorgham NA et al. Lasers for reduction of unwanted hair in skin of colour

- Año: 2020.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Personas con fototipos cutáneos altos. Sexo: Mixta. n: Estudios comparativos de láser e IPL. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Alexandrita diodo Nd:YAG e IPL | comparador: Comparación entre dispositivos.
- Medida: Reducción de pelo y seguridad.
- Resultado principal: Alexandrita superó a IPL en recuento; Nd:YAG y diodo no difirieron significativamente de IPL en estimaciones agrupadas.
- Limitaciones: Heterogeneidad; pocos estudios por comparación; experiencia del operador influye.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1111/jdv.15995

#### S044 — Turati F et al. Efficacy of cosmetic products in cellulite reduction

- Año: 2014.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Personas con celulitis; mayoría mujeres. Sexo: Principalmente mujeres. n: 21 estudios; 7 en metaanálisis. Experiencia: No aplica.
- Duración: Variable.
- Intervención/comparación: Cremas con xantinas retinoides herbales o mezclas | comparador: Vehículo placebo o lado control.
- Medida: Perímetro de muslo y escalas visuales.
- Resultado principal: Diferencia agrupada de perímetro de muslo de -0.46 cm con heterogeneidad significativa.
- Limitaciones: Formulaciones variables; estudios pequeños; mayoría intrapersonales y femeninos.
- Confianza: Baja-moderada para mujeres; baja para hombre.
- DOI/URL: https://doi.org/10.1111/jdv.12193

#### S045 — Knobloch K y Kraemer R. ESWT for the treatment of cellulite

- Año: 2015.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Mujeres con celulitis. Sexo: Mujeres. n: 297. Experiencia: No aplica.
- Duración: 11 estudios; 5 ECA.
- Intervención/comparación: Ondas de choque focales o radiales | comparador: Placebo o control.
- Medida: Fotografía perímetro ultrasonido y escalas.
- Resultado principal: Se observaron mejoras en escalas y medidas; normalmente 6-8 sesiones una o dos veces por semana.
- Limitaciones: Solo 123 mujeres en ECA; calidad y parámetros muy heterogéneos.
- Confianza: Moderada-baja.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/26209782/

#### S046 — Lim SK et al. Comparative analysis of cellulite treatment modalities

- Año: 2025.
- Diseño: Revisión sistemática de ensayos aleatorizados.
- Población: Personas tratadas por celulitis. Sexo: Predominio femenino. n: 2084. Experiencia: No aplica.
- Duración: 24 ECA.
- Intervención/comparación: Estimulación mecánica tópicos ondas láser radiofrecuencia inyectables y ultrasonido | comparador: Comparaciones múltiples.
- Medida: Escalas perímetro y grosor subcutáneo.
- Resultado principal: Ondas de choque radiofrecuencia e inyectables mostraron resultados prometedores.
- Limitaciones: Seguimiento medio muy corto; heterogeneidad; no establece tratamiento definitivo.
- Confianza: Moderada general; baja para varón.
- DOI/URL: https://doi.org/10.1007/s00266-024-04365-8

#### S047 — American Academy of Dermatology. Cellulite treatments what really works

- Año: 2026.
- Diseño: Síntesis clínica experta.
- Población: Personas que consultan por celulitis. Sexo: Predominio femenino. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Cremas masaje ondas radiofrecuencia subcisión láser y reducción grasa | comparador: Sin comparador único.
- Medida: Apariencia duración riesgos.
- Resultado principal: Masaje y radiofrecuencia ofrecen cambios pequeños o transitorios; criolipólisis no trata celulitis; subcisión puede durar más.
- Limitaciones: No es revisión cuantitativa y la información procede sobre todo de mujeres.
- Confianza: Moderada clínica.
- DOI/URL: https://www.aad.org/public/cosmetic/fat-removal/cellulite-treatments-what-really-works

#### S048 — American Academy of Dermatology. Hair removal and shaving guidance

- Año: 2026.
- Diseño: Guía clínica pública experta.
- Población: Personas que eliminan vello corporal. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Afeitado cera depilatorios láser y electrólisis | comparador: Comparación práctica.
- Medida: Irritación vello encarnado quemaduras y reducción de pelo.
- Resultado principal: Afeitar en dirección del pelo y probar depilatorios reduce riesgo; láser exige varias sesiones y experiencia según fototipo.
- Limitaciones: No es ensayo; resultado individual depende de técnica y piel.
- Confianza: Moderada clínica.
- DOI/URL: https://www.aad.org/public/everyday-care/skin-care-basics/hair/remove-unwanted-hair

### Presentación visual y estética

#### S049 — Kollu T et al. Defining the Ideal Male Buttocks

- Año: 2023.
- Diseño: Encuesta transversal de percepción con imágenes manipuladas.
- Población: Adultos estadounidenses reclutados en línea. Sexo: 61% hombres. n: 2095. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Valoración de variantes digitales en vistas lateral oblicua y posterior | comparador: Diferentes relaciones y ángulos glúteos.
- Medida: Puntuaciones de preferencia visual.
- Resultado principal: Preferencia agregada por relación lateral 1.18 ángulo oblicuo 60 grados e índice glúteo-trocantérico 0.66; contorno proyectado estrecho y con depresión lateral.
- Limitaciones: Muestra autoseleccionada estadounidense; imágenes de un modelo; no es entrenamiento ni define un ideal universal.
- Confianza: Moderada para percepción de esa muestra; baja para prescripción.
- DOI/URL: https://doi.org/10.1097/PRS.0000000000010378

#### S050 — Fan J et al. Visual perception of male body attractiveness

- Año: 2005.
- Diseño: Estudio transversal de percepción con escaneo 3D.
- Población: 94 cuerpos masculinos escaneados y 43 evaluadores jóvenes de Hong Kong. Sexo: Cuerpos de hombres; 20 evaluadores hombres y 23 mujeres. n: 137. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Clips 3D rotatorios de 69 hombres chinos y 25 caucásicos | comparador: Comparación de medidas y proporciones corporales.
- Medida: Puntuación de atractivo y antropometría 3D.
- Resultado principal: El índice volumen-altura explicó la mayor parte de la variación; proporciones asociadas a forma física aportaron efectos menores.
- Limitaciones: Evaluadores jóvenes de una sola ciudad; atractivo general y no glúteo; modelos digitales.
- Confianza: Moderada para esa muestra; baja para objetivos universales.
- DOI/URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC1634963/

#### S051 — Swami V y Tovee MJ. Male physical attractiveness in Britain and Malaysia

- Año: 2007.
- Diseño: Estudio transversal transcultural de percepción.
- Población: Mujeres de entornos británicos y malasios urbanos y rurales. Sexo: Mujeres. n: 95. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Valoración de imágenes de hombres reales | comparador: Cintura-tórax IMC y cintura-cadera.
- Medida: Puntuaciones de atractivo y medidas corporales.
- Resultado principal: La importancia relativa de cintura-tórax e IMC cambió entre entornos; cintura-cadera no fue un predictor estable.
- Limitaciones: Solo evaluadoras mujeres; muestras locales; atractivo general no específicamente glúteo.
- Confianza: Moderada para variabilidad; baja para prescripción individual.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/18089203/

#### S052 — Brierley ME et al. The Body and the Beautiful

- Año: 2016.
- Diseño: Experimento transversal de manipulación visual.
- Población: Adultos jóvenes australianos. Sexo: 30 mujeres y 33 hombres evaluadores. n: 63. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Manipulación de grasa y músculo en 15 cuerpos masculinos y 15 femeninos | comparador: Apariencia saludable frente a atractiva.
- Medida: Selección visual de grasa y músculo.
- Resultado principal: En cuerpos masculinos la composición preferida para salud y atractivo fue similar y quedó dentro del rango saludable usado por los autores.
- Limitaciones: Imágenes transformadas; muestra universitaria; no evalúa glúteo ni entrenamiento.
- Confianza: Moderada para esa muestra.
- DOI/URL: https://doi.org/10.1371/journal.pone.0156722

#### S053 — Gherardini G et al. Standardization in photography for body contour surgery and suction-assisted lipectomy

- Año: 1997.
- Diseño: Artículo metodológico y protocolo clínico.
- Población: Pacientes de cirugía de contorno corporal. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Vistas estandarizadas iluminación equipo fondo y documentación de textura | comparador: Fotografía no estandarizada.
- Medida: Reproducibilidad fotográfica.
- Resultado principal: Propone vistas estándar y suplementarias para comparar contorno y textura corporal.
- Limitaciones: No es ensayo de validez; diseñado para cirugía y estudio profesional.
- Confianza: Moderada metodológica.
- DOI/URL: https://doi.org/10.1097/00006534-199707000-00034

#### S054 — DiBernardo BE et al. Photographic standards in plastic surgery

- Año: 1998.
- Diseño: Artículo metodológico de estandarización clínica.
- Población: Pacientes de cirugía plástica. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Misma cámara lente ajuste iluminación y posición | comparador: Fotografías variables.
- Medida: Reproducibilidad fotográfica.
- Resultado principal: La constancia del equipo y de la posición permite comparaciones pre-post más válidas.
- Limitaciones: Tecnología analógica original; no cuantifica error; entorno clínico.
- Confianza: Moderada metodológica.
- DOI/URL: https://doi.org/10.1097/00006534-199808000-00045

#### S055 — Prantl L et al. A Proposal for Updated Standards of Photographic Documentation in Aesthetic Medicine

- Año: 2017.
- Diseño: Propuesta metodológica de estándares digitales.
- Población: Pacientes de medicina estética. Sexo: Mixta. n: No aplica. Experiencia: No aplica.
- Duración: No aplica.
- Intervención/comparación: Estandarización de cámara perspectiva fondo luz y edición digital | comparador: Documentación no normalizada.
- Medida: Calidad y comparabilidad fotográfica.
- Resultado principal: Actualiza los controles necesarios para que las imágenes antes-después sean objetivas y comparables.
- Limitaciones: Propuesta experta; no prueba cada parámetro en ensayo; contexto clínico.
- Confianza: Moderada metodológica.
- DOI/URL: https://doi.org/10.1097/GOX.0000000000001389

#### S056 — Persichetti P et al. Digital photography in plastic surgery

- Año: 2007.
- Diseño: Estudio y protocolo metodológico.
- Población: Pacientes de cirugía plástica fotografiados fuera de estudio profesional. Sexo: Mixta. n: No indicado en el resumen consultado. Experiencia: No aplica.
- Duración: Transversal.
- Intervención/comparación: Sistema digital asequible con colocación e iluminación controladas | comparador: Entorno no profesional.
- Medida: Comparabilidad y calidad fotográfica.
- Resultado principal: La estandarización razonable es posible fuera de un estudio con un montaje consistente.
- Limitaciones: No específico de glúteo; tecnología anterior a móviles actuales; no mide hipertrofia.
- Confianza: Moderada metodológica.
- DOI/URL: https://doi.org/10.1007/s00266-006-0125-5

### Programación avanzada y controversias

#### S057 — Tsartsapakis I et al. Effects of Advanced Resistance Training Systems

- Año: 2026.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de 18-45 años recreativamente entrenados. Sexo: Mixta. n: 23 estudios. Experiencia: Entrenados recreativos.
- Duración: Variable.
- Intervención/comparación: Drop sets rest-pause clusters tempo sobrecarga excéntrica y otros | comparador: Series múltiples tradicionales.
- Medida: Hipertrofia y fuerza máxima.
- Resultado principal: Ventaja pequeña no significativa para hipertrofia; métodos avanzados comparables en conjunto.
- Limitaciones: Métodos y protocolos heterogéneos; no específica de glúteo.
- Confianza: Moderada general.
- DOI/URL: https://doi.org/10.3390/jfmk11010080

#### S058 — Havers T et al. Acute and Chronic Effects of Drop-Set Training

- Año: 2026.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de estudios de resistencia. Sexo: Mixta. n: 274. Experiencia: Variable.
- Duración: 12 estudios.
- Intervención/comparación: Series descendentes | comparador: Series tradicionales.
- Medida: Hipertrofia fuerza RPE y lactato.
- Resultado principal: Hipertrofia fuerza y resistencia similares; mayor esfuerzo percibido y lactato agudos.
- Limitaciones: Pocos estudios crónicos; no específica de glúteo.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1186/s40798-026-01012-1

#### S059 — Wolf M et al. Lengthened partial repetitions elicit similar muscular adaptations

- Año: 2025.
- Diseño: Ensayo longitudinal intrapersonal.
- Población: Adultos sanos entrenados. Sexo: Mixta. n: 30. Experiencia: Entrenados.
- Duración: 8 semanas.
- Intervención/comparación: Parciales en posición elongada de tren superior | comparador: Rango completo.
- Medida: Ecografía y 10RM.
- Resultado principal: Hipertrofia y fuerza-resistencia similares entre condiciones.
- Limitaciones: Tren superior; ocho semanas; todas las series al fallo; no glúteo.
- Confianza: Moderada general; baja glútea.
- DOI/URL: https://doi.org/10.7717/peerj.18904

#### S060 — Oranchuk DJ et al. Isometric training and long-term adaptations

- Año: 2019.
- Diseño: Revisión sistemática.
- Población: Adultos de estudios de entrenamiento isométrico. Sexo: Mixta. n: Estudios elegibles limitados. Experiencia: Variable.
- Duración: Medio y largo plazo.
- Intervención/comparación: Isometrías con diferentes longitudes intensidades e intención | comparador: Comparaciones entre protocolos.
- Medida: Morfología fuerza y arquitectura.
- Resultado principal: Las isometrías pueden hipertrofiar y las longitudes mayores mostraron tendencia favorable.
- Limitaciones: Estudios heterogéneos y no específicos de glúteo.
- Confianza: Moderada general; baja glútea.
- DOI/URL: https://pubmed.ncbi.nlm.nih.gov/30580468/

#### S061 — Moesgaard L et al. Effects of Periodization on Strength and Muscle Hypertrophy

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de estudios de fuerza. Sexo: Mixta. n: 10 estudios periodizado vs no y 11 lineal vs ondulante. Experiencia: Mixta.
- Duración: 6+ semanas.
- Intervención/comparación: Programación periodizada | comparador: No periodizada u otro modelo.
- Medida: 1RM y medidas de hipertrofia.
- Resultado principal: Periodizar favoreció fuerza 1RM pero no mostró ventaja clara de hipertrofia con volumen igualado.
- Limitaciones: No específica de glúteo; protocolos cortos y heterogéneos.
- Confianza: Moderada-alta general.
- DOI/URL: https://doi.org/10.1007/s40279-021-01636-1

#### S062 — Kassiano W et al. Does Varying Resistance Exercises Promote Superior Muscle Hypertrophy

- Año: 2022.
- Diseño: Revisión sistemática.
- Población: Hombres jóvenes. Sexo: Hombres. n: 241. Experiencia: Variable.
- Duración: Estudios longitudinales.
- Intervención/comparación: Selección constante o variada de ejercicios | comparador: Comparaciones entre variación.
- Medida: Hipertrofia regional y fuerza.
- Resultado principal: Variación sistemática puede cubrir regiones; variación excesiva o redundante puede dificultar adaptaciones.
- Limitaciones: Pocos estudios; todos jóvenes; no específica de glúteo.
- Confianza: Moderada-baja.
- DOI/URL: https://doi.org/10.1519/JSC.0000000000004258

#### S063 — Arntz F et al. Effect of Plyometric Jump Training on Skeletal Muscle Hypertrophy

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis multinivel.
- Población: Personas sanas. Sexo: Mixta. n: 15 estudios. Experiencia: Atletas y no atletas.
- Duración: Variable.
- Intervención/comparación: Entrenamiento pliométrico de saltos | comparador: Control o pre-post.
- Medida: Medidas de hipertrofia.
- Resultado principal: Efecto pequeño-moderado global; mayor señal en no atletas y extensores de rodilla.
- Limitaciones: Efectos glúteos no aislados; protocolos heterogéneos.
- Confianza: Moderada general; baja glútea.
- DOI/URL: https://doi.org/10.3389/fphys.2022.888464

#### S064 — Takahashi K et al. Gluteus and posterior thigh muscle sizes in sprinters

- Año: 2022.
- Diseño: Estudio transversal con MRI.
- Población: Velocistas masculinos y hombres no entrenados. Sexo: Hombres. n: 39. Experiencia: 19 velocistas y 20 no entrenados.
- Duración: Transversal.
- Intervención/comparación: Comparación de volúmenes musculares regionales | comparador: Velocistas vs no entrenados.
- Medida: MRI de volumen muscular.
- Resultado principal: Velocistas mostraron mayor volumen relativo glúteo y posterior con diferencias regionales.
- Limitaciones: No establece causalidad; genética fuerza y selección deportiva confunden.
- Confianza: Baja causal; moderada descriptiva.
- DOI/URL: https://doi.org/10.1080/17461391.2021.1907450

#### S065 — Weston KL et al. Application of Exercise Snacks across populations

- Año: 2025.
- Diseño: Revisión de alcance.
- Población: Niños adultos mayores y poblaciones clínicas. Sexo: Mixta. n: 1118. Experiencia: Variable.
- Duración: 33 estudios originales.
- Intervención/comparación: Bouts intensos breves dispersos durante el día | comparador: Comparadores diversos.
- Medida: Cardiometabolismo función fuerza y otros.
- Resultado principal: Campo heterogéneo dominado por muestras pequeñas y resultados de salud o aptitud.
- Limitaciones: No demuestra hipertrofia en entrenados ni superioridad glútea.
- Confianza: Baja para hipertrofia.
- DOI/URL: https://doi.org/10.1186/s40798-025-00829-6

#### S066 — Coleman M et al. Gaining more from doing less

- Año: 2024.
- Diseño: Ensayo aleatorizado longitudinal.
- Población: Adultos jóvenes entrenados. Sexo: 29 hombres y 10 mujeres. n: 39. Experiencia: Entrenados.
- Duración: 9 semanas.
- Intervención/comparación: Una semana sin fuerza a mitad del programa | comparador: Entrenamiento continuo.
- Medida: Ecografía fuerza potencia y resistencia.
- Resultado principal: Sin diferencia apreciable en hipertrofia; continuo mejoró más algunas medidas de fuerza.
- Limitaciones: Corto; cuádriceps y gemelos; volumen alto; no glúteo.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.7717/peerj.16777

#### S067 — Pancar Z et al. Effects of deload periods in resistance training

- Año: 2026.
- Diseño: Ensayo intrapersonal aleatorizado.
- Población: Hombres jóvenes no entrenados. Sexo: Hombres. n: 19. Experiencia: No entrenados.
- Duración: 8 semanas.
- Intervención/comparación: Reducción de frecuencia y series en semanas 4 y 8 | comparador: Entrenamiento continuo.
- Medida: Ecografía y 10RM.
- Resultado principal: Descargas no perjudicaron hipertrofia o fuerza-resistencia medias.
- Limitaciones: Novatos; brazos y cuádriceps; corto; no glúteo.
- Confianza: Moderada indirecta.
- DOI/URL: https://doi.org/10.1038/s41598-026-40612-5

#### S068 — Hickmott LM et al. Effect of Load and Volume Autoregulation

- Año: 2022.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Personas entrenadas. Sexo: Mixta. n: 15 estudios en metaanálisis. Experiencia: Entrenadas.
- Duración: Variable.
- Intervención/comparación: RIR RPE velocidad y umbrales de pérdida de velocidad | comparador: Carga estandarizada.
- Medida: 1RM y CSA.
- Resultado principal: Autoregulación de carga produjo fuerza similar; mayor pérdida de velocidad asoció más hipertrofia y fatiga.
- Limitaciones: No específica de glúteo; protocolos de velocidad no equivalen exactamente a RIR.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.1186/s40798-021-00404-9

#### S069 — Kassiano W et al. Unilateral versus bilateral resistance training

- Año: 2025.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de estudios de resistencia. Sexo: Mixta. n: 9 estudios. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Entrenamiento unilateral | comparador: Entrenamiento bilateral.
- Medida: Hipertrofia y fuerza dinámica.
- Resultado principal: Sin diferencia significativa de hipertrofia; fuerza específica al tipo de tarea.
- Limitaciones: Literatura limitada; riesgo de sesgo moderado; no específica de glúteo.
- Confianza: Moderada general.
- DOI/URL: https://doi.org/10.1007/s40279-024-02169-z

#### S070 — Grandou C et al. Overtraining in Resistance Exercise

- Año: 2020.
- Diseño: Revisión sistemática exploratoria.
- Población: Adultos sometidos a entrenamiento de resistencia intensificado. Sexo: Mixta. n: 22 estudios. Experiencia: Variable.
- Duración: Variable.
- Intervención/comparación: Sobrecarga alta o entrenamiento monótono | comparador: Protocolos diversos.
- Medida: Rendimiento y síntomas de sobreentrenamiento.
- Resultado principal: Ningún marcador aislado salvo caída sostenida de rendimiento mostró fiabilidad suficiente.
- Limitaciones: Definiciones y seguimientos inconsistentes.
- Confianza: Moderada como límite; baja diagnóstica.
- DOI/URL: https://doi.org/10.1007/s40279-019-01242-2

#### S071 — Slater LV et al. A Biomechanical Review of the Squat Exercise

- Año: 2024.
- Diseño: Revisión biomecánica narrativa clínica.
- Población: Adultos sanos y poblaciones clínicas de estudios de sentadilla. Sexo: Mixta. n: No aplica. Experiencia: Variable.
- Duración: Transversal.
- Intervención/comparación: Cambios de tronco tibia postura pies profundidad y carga | comparador: Variantes técnicas.
- Medida: Cinemática cinética y carga articular.
- Resultado principal: La inclinación relativa de tronco y tibia modifica el sesgo de momentos de cadera y rodilla.
- Limitaciones: Nivel de evidencia clínico 5; no mide hipertrofia.
- Confianza: Moderada biomecánica; baja longitudinal.
- DOI/URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC10987311/

#### S072 — Hamarsland H et al. Equal-Volume Strength Training With Different Training Frequencies

- Año: 2022.
- Diseño: Ensayo aleatorizado longitudinal.
- Población: Adultos jóvenes entrenados. Sexo: 11 hombres y 10 mujeres. n: 21. Experiencia: Entrenados.
- Duración: 9 semanas.
- Intervención/comparación: Mismo volumen en cuatro sesiones semanales | comparador: Mismo volumen en dos sesiones.
- Medida: DXA ecografía y 1RM.
- Resultado principal: Sin diferencias entre grupos en crecimiento muscular o fuerza.
- Limitaciones: Muestra pequeña; cuerpo completo; no glúteo específico.
- Confianza: Moderada.
- DOI/URL: https://doi.org/10.3389/fphys.2021.789403

## 7. Material trasladado deliberadamente

- C3-01–C3-10: `13_BASE_EJERCICIOS_E_INTERVENCIONES_v2.0.md`, porque combinan evidencia con selección funcional de ejercicios.
- S073–S081 y CG2-01–CG2-12: `14_BASE_EVIDENCIA_GIMNASIO_MAQUINAS_TRANSFERENCIA_v2.0.md`.
- M1/M2: `15_BASE_EVIDENCIA_FISICO_MASCULINO_INTEGRAL_v2.0.md`.
- Historial de entrenamiento: JSON/panel; nunca esta Source.

## 8. Qué no debe hacer esta Source

- prescribir cargas o sesiones actuales;
- declarar un volumen óptimo individual;
- elegir una máquina concreta sin prueba de encaje;
- usar EMG como ranking de hipertrofia;
- transformar preferencias poblacionales en objetivos personales;
- diagnosticar lesiones o enfermedades cutáneas;
- interpretar el uso de sustancias exógenas como multiplicador automático de volumen o recuperación.


## 9. Conclusiones aplicadas históricas preservadas fuera del backbone científico

La Source v1 contenía cinco filas adicionales que **no aparecen en la base neutral** porque mezclaban evidencia general con supuestos personales/operativos de 2026-07-24. CP-E7 las conserva aquí para trazabilidad, pero **no tienen autoridad como prescripción actual**. Sus destinos operativos son `05` y `08`, donde se han actualizado o sustituido según el estado vigente.

### LEGACY C2B-08 — Dosis inicial prudente de 8–12 series equivalentes
- **Conclusión histórica:** ocho a doce series equivalentes directas semanales constituían una dosis inicial prudente cuando se desconocía el volumen previo.
- **Tipo:** síntesis aplicada e inferencia conservadora.
- **Población/supuesto histórico:** hombre entrenado de 43 años; extrapolación de evidencia general.
- **Confianza histórica:** moderada-baja.
- **Fuentes:** S011; S012; S019.
- **Estado v2:** **SUPERSEDIDA COMO REGLA DE INICIO**. El volumen ya no se presupone desconocido y `03` + historial real + `05` gobiernan la dosis individual. Se conserva solo como antecedente metodológico.

### LEGACY C4-02 — Mantenimiento energético como punto de partida cuando faltan datos
- **Conclusión histórica:** el mantenimiento energético era el punto de partida prudente para intentar recomposición cuando faltaban datos de composición e ingesta.
- **Tipo:** síntesis aplicada.
- **Fuentes:** S026; S030; S031.
- **Estado v2:** **ACTUALIZADA EN `08`**. La estrategia vigente evita déficit no deliberado y usa mantenimiento alto/pequeño superávit según tendencia, con datos personales actuales y baja apetencia como restricción.

### LEGACY C4-05 — Ritmo conservador de pérdida de peso
- **Conclusión histórica:** durante una fase de pérdida de grasa, un ritmo conservador se consideraba más compatible con masa magra y rendimiento; se propuso 0,25–0,50 % del peso/semana como inferencia práctica.
- **Tipo:** ensayo comparativo en atletas + inferencia aplicada.
- **Confianza histórica:** probable indirecta.
- **Fuentes:** S026; S031.
- **Límite original:** el ensayo comparó aproximadamente 0,7 % y 1,4 %/semana; 0,25–0,50 % era una extrapolación, no un umbral demostrado.
- **Estado v2:** **CONDICIONAL, NO ACTIVO**. Solo se recuperará en `08` si se inicia una fase deliberada de pérdida de grasa.

### LEGACY C4-08 — Mantenimiento de torso con menor volumen
- **Conclusión histórica:** el torso podía mantenerse con menos volumen si se conservaban intensidad y práctica; la v1 propuso 4–8 series duras por grupo como banda aplicada.
- **Tipo:** ensayo longitudinal + inferencia aplicada.
- **Fuente:** S035.
- **Estado v2:** **PRINCIPIO CONSERVADO, CIFRA NO CANÓNICA**. `05` conserva el concepto de volumen de mantenimiento durante especialización, pero no trata 4–8 como mínimo universal; el objetivo actual exige desarrollo marcado del torso, no mantenimiento por defecto.

### LEGACY C4-11 — Alimentos básicos antes que suplementos
- **Conclusión histórica:** alimentos básicos y preparación práctica debían preceder a suplementos para cubrir energía y proteína.
- **Tipo:** síntesis nutricional aplicada.
- **Fuente:** S027.
- **Estado v2:** **INTEGRADA EN `08`** con una arquitectura de alimentación normal → densificación → calorías líquidas → comida completa líquida, adaptada a la baja apetencia actual. Los suplementos siguen siendo auxiliares.


## 10. Procedencia

Reconstruida desde el corpus científico completo del 13/08/2026, especialmente `04_BASES_NEUTRALES/01_ESTUDIOS_GLUTEO_Y_AREAS_ASOCIADAS.csv`, `04_BASES_NEUTRALES/02_RESULTADOS_SINTETIZADOS.csv` y los informes narrativos de `01_GLUTEO`, con reconciliación CP-E0/CP-E1/CP-E2. La Source v1 se conserva únicamente como archivo histórico de procedencia.

## 11. Registro de cambios

### v2.0 — 2026-08-13

- reconstruye la base desde el corpus original en lugar de resumir la v1;
- conserva S001–S072 como identidades canónicas A;
- separa estudios de gimnasio y físico masculino en 14/15;
- mueve la selección aplicada de ejercicios a 13;
- añade límites explícitos para hip thrust/squat, regionalización, volumen, estética poblacional y piel;
- elimina cualquier función de registro histórico personal.


# 13_BASE_EJERCICIOS_E_INTERVENCIONES_v2.0.md

# 13 — Base de ejercicios e intervenciones

**Versión:** 2.0  
**Fecha de reconstrucción:** 2026-08-13  
**Estado:** CANÓNICO v2 — auditoría conjunta 12–15 superada; catálogo estructurado sin historial personal de entrenamiento.

## 1. Función y autoridad

Esta Source es el catálogo estructurado de ejercicios y de intervenciones estéticas/cutáneas. Organiza función, región probable, geometría, estabilidad, progresión, limitantes, riesgos, alternativas y confianza. **No decide por sí sola qué ejercicio está activo hoy**: la selección vigente corresponde a `03`, y el encaje de una máquina concreta se valida con `06`, `14` y el seguimiento personal.

El antiguo registro histórico embebido en la Source 13 v1 se elimina del núcleo. Los entrenamientos realizados pertenecen al JSON acumulativo y, cuando proceda, al panel de seguimiento.

## 2. Reglas de uso

1. Seleccionar por función, encaje y progresabilidad, no por fama del ejercicio.
2. Una puntuación o descripción biomecánica no es un tamaño de efecto de hipertrofia.
3. Los ejercicios casi equivalentes son sustitutos salvo motivo explícito para coexistir.
4. “Región probable” expresa anatomía/transferencia; no garantiza hipertrofia regional selectiva.
5. Las alternativas doméstica/gimnasio conservan función aproximada, no comparabilidad de cargas.
6. Una intervención cutánea se interpreta por problema y tolerancia; no diagnostica la lesión.
7. Las fuentes `Sxxx` se verifican en `12`; la evidencia específica de máquinas `S073–S081` se verifica en `14`.

## 3. Conclusiones de selección trasladadas desde C3

**C3-01 — Una matriz mínima puede cubrir extensión acortada extensión desde alta flexión y bisagra sin acumular variantes redundantes**  
- Evidencia: Síntesis de evidencia longitudinal y biomecánica.
- Confianza: Probable.
- Límite: No demuestra sinergia superior de la combinación.
- Fuentes: S001;S002;S003;S004;S022.

**C3-02 — El hip thrust es la opción mejor respaldada cuando se prioriza especificidad glútea y se quiere limitar crecimiento adicional de muslo**  
- Evidencia: Ensayo longitudinal MRI y revisión.
- Confianza: Probable.
- Límite: No es universalmente superior ni obligatorio.
- Fuentes: S001;S002.

**C3-03 — Sentadilla profunda y prensa son opciones respaldadas cuando también interesa desarrollo general de pierna**  
- Evidencia: Ensayos longitudinales MRI.
- Confianza: Probable.
- Límite: No extrapolar porcentajes ni asumir equivalencia entre máquinas.
- Fuentes: S002;S003;S004.

**C3-04 — Split squat RDL unilateral e hip thrust unilateral cargados producen fuerzas glúteas estimadas altas y son alternativas plausibles con poca carga**  
- Evidencia: Modelo musculoesquelético informado por EMG.
- Confianza: Probable biomecánica; incierta longitudinal.
- Límite: No demuestra hipertrofia superior.
- Fuentes: S022.

**C3-05 — RDL hiperextensión y pull-through son sustituciones de una misma función de bisagra**  
- Evidencia: Biomecánica y EMG secundaria.
- Confianza: Probable funcional; incierta hipertrofia comparativa.
- Límite: No ordenar hipertrofia por EMG.
- Fuentes: S007;S022;S023.

**C3-06 — Las abducciones progresables son razonables para cubrir glúteo medio y menor pero deben contarse aparte**  
- Evidencia: EMG segmentaria y ensayo clínico MRI.
- Confianza: Incierta para estética sana.
- Límite: No prometer anchura o upper glute.
- Fuentes: S005;S024.

**C3-07 — Activaciones fáciles paseos con banda clamshells sprints y saltos no deben contarse automáticamente como series de hipertrofia**  
- Evidencia: Síntesis y límite de inferencia.
- Confianza: Probable.
- Límite: No implica que carezcan de utilidad atlética o terapéutica.
- Fuentes: S009;S025.

**C3-08 — La progresión puede lograrse aumentando carga o repeticiones dentro de un rango**  
- Evidencia: Ensayo intrapersonal longitudinal.
- Confianza: Probable general.
- Límite: No prueba equivalencia en entrenados o glúteo.
- Fuentes: S020.

**C3-09 — Mantener carga y repeticiones constantes puede limitar la magnitud de hipertrofia frente a una sobrecarga progresiva**  
- Evidencia: Ensayo intrapersonal longitudinal.
- Confianza: Probable general; indirecta para glúteo.
- Límite: No obliga a aumentar carga cada sesión.
- Fuentes: S021.

**C3-10 — El apoyo externo en ejercicios unilaterales puede mejorar la relación estímulo-fatiga al impedir que equilibrio limite la serie**  
- Evidencia: Inferencia biomecánica y práctica.
- Confianza: Probable.
- Límite: No significa eliminar todo trabajo de estabilidad.
- Fuentes: S022.

## 4. Reconciliaciones obligatorias

### 4.1 Patrón mínimo y redundancia

La cobertura funcional de extensión acortada, alta flexión y bisagra es una **arquitectura práctica**, no una demostración de que tres patrones sean un mínimo biológico universal. Se usa para evitar lagunas y redundancias dentro de una especialización glútea.

### 4.2 RDL, hiperextensión y pull-through

Su convivencia como familia de bisagra/ extensión desde flexión se apoya en biomecánica y función. No existe una comparación longitudinal glútea robusta que ordene su hipertrofia. La elección real depende de tolerancia, limitante, fatiga y progresión.

### 4.3 Abducción

La abducción directa cubre una función poco representada por patrones sagitales, pero la evidencia longitudinal de hipertrofia de glúteo medio/menor en sanos entrenados sigue siendo insuficiente. No prometer “glúteo superior” por una postura concreta.

### 4.4 Apoyo externo y Smith

Reducir demandas de equilibrio puede mejorar la capacidad de aplicar fuerza y estandarizar una serie. Eso no demuestra mayor hipertrofia. La guía debe encajar con la antropometría y la trayectoria elegida.

### 4.5 Intervenciones estéticas

Las filas I001–I021 describen utilidad, riesgo y evidencia de intervenciones de piel/presentación. Ninguna crema, masaje o procedimiento se contabiliza como estímulo hipertrófico. Las ramas clínicas permanecen condicionales.

## 5. Catálogo de ejercicios E001–E022

El catálogo completo conserva los campos históricos útiles que no estaban en la tabla neutral (`alternativa_domestica`, `alternativa_gimnasio`, `notas`). Los 20 campos compartidos fueron comprobados como idénticos a `04_BASES_NEUTRALES/03_DATOS_BIOMECANICOS_EJERCICIOS.csv`.

```csv
id,ejercicio,variante,material,funcion_principal,region_probable,punto_maxima_dificultad,posicion_mayor_elongacion,curva_resistencia,limitante_tecnico,estabilidad,facilidad_progresion,estimulo_fatiga,uso_fuerza,uso_hipertrofia,uso_potencia,uso_metabolico,riesgos_molestias,alternativa_domestica,alternativa_gimnasio,nivel_confianza,fuentes,notas
E001,Hip thrust,Bilateral con barra mancuerna o máquina,Banco carga y acolchado,Extensión de cadera con alta demanda cerca del acortamiento,Glúteo mayor; evidencia regional superior media e inferior,Cerca de la extensión completa según montaje,Flexión de cadera moderada en la posición inferior,Ascendente hacia el bloqueo en la variante libre habitual,Control pélvico y evitar terminar con extensión lumbar,Alta,Alta en gimnasio; media-alta en casa,Alta especificidad con fatiga sistémica moderada,Alta,Alta,Media como complemento,Alta con cargas ligeras,Presión pélvica banco inestable o molestia lumbar,Hip thrust con mancuerna o puente unilateral,Hip thrust con barra o máquina,Moderada-alta longitudinal,S001;S002,Cuenta 1 serie directa a ≤3 RIR
E002,Puente de glúteo,Bilateral o unilateral,Suelo mancuerna banda,Extensión de cadera en posición acortada,Glúteo mayor,Cerca del bloqueo,Flexión de cadera menor que en hip thrust,Ascendente hacia extensión; banda acentúa el final,Evitar arquear la espalda y perder apoyo,Muy alta,Media por límite de carga,Alta si la carga disponible basta,Media,Moderada,Baja,Alta,Presión lumbar o calambres si domina isquio,Puente cargado o unilateral,Hip thrust en máquina,Moderada por transferencia del hip thrust,S001;S002,Sustituto del patrón acortado; no añadir por defecto al hip thrust
E003,Sentadilla,Profunda tolerable con barra o mancuernas,Barra mancuernas rack,Extensión coordinada de cadera y rodilla desde flexión,Glúteo mayor; además cuádriceps y aductores,Zona inferior y media según carga y técnica,Máxima flexión de cadera tolerada,Mayor demanda externa con flexión; depende de antropometría,Mantener apoyo control de pelvis y trayectoria reproducible,Media-alta,Alta,Moderada para glúteo por fatiga global,Muy alta,Alta,Media,Media,Dolor de rodilla o cadera y flexión lumbar si se fuerza el rango,Goblet squat o split squat con apoyo,Back squat front squat o hack squat,Moderada-alta longitudinal,S002;S003,Cuenta 1 directa si el rango es profundo y la cadera participa claramente
E004,Prensa,Bilateral o unilateral con rango profundo tolerable,Máquina de prensa,Extensión de cadera y rodilla con alta estabilidad,Glúteo mayor; cuádriceps y aductor mayor,Zona inferior según geometría de la máquina,Alta flexión de cadera antes de perder apoyo pélvico,Dependiente de plataforma respaldo y recorrido,Evitar despegar pelvis o colapsar rodillas,Muy alta,Muy alta,Alta,Alta,Alta,Baja,Media,Pinzamiento de cadera flexión lumbar o molestias de rodilla,Goblet squat o Bulgarian con apoyo,Prensa ajustada a la anatomía,Moderada-alta longitudinal,S001;S004,La evidencia directa procede de una máquina y técnica concretas
E005,Bulgarian split squat,Con apoyo TRX pared o multipower,Mancuernas TRX banco o multipower,Extensión unilateral desde flexión de cadera y rodilla,Glúteo mayor; estabilización de glúteo medio,Zona inferior y media,Cadera flexionada de la pierna adelantada,Mayor demanda en la parte profunda,Equilibrio altura del banco y distribución entre piernas,Media; alta con apoyo,Alta,Alta con apoyo; media sin apoyo,Alta,Alta probable,Media,Alta,Equilibrio fatiga cardiorrespiratoria rodilla o cadera,Bulgarian con TRX y mancuernas,Bulgarian en multipower,Moderada biomecánica; baja longitudinal,S022,El apoyo no reduce el valor hipertrófico si mejora la fuerza aplicada
E006,Zancada inversa,Alterna o estática,Mancuernas TRX barra,Extensión unilateral de cadera y rodilla,Glúteo mayor; cuádriceps,Zona inferior tras el paso,Flexión de cadera de la pierna adelantada,Variable con longitud de paso y trayectoria,Coordinación y reproducibilidad del paso,Media-alta,Alta,Moderada-alta,Alta,Alta probable,Media,Alta,Pérdida de equilibrio molestias de rodilla o pelvis,Zancada inversa con TRX,Zancada en multipower,Baja-moderada biomecánica,S022;S025,Sustituye a otra variante profunda; no es obligatoria además del Bulgarian
E007,Step-up,Alto controlado lateral o frontal,Cajón banco mancuernas,Extensión unilateral para elevar el cuerpo,Glúteo mayor; glúteo medio como estabilizador,Inicio y zona media según altura,Flexión de cadera en la posición inicial,Dependiente de altura y distancia al cajón,Evitar impulso de la pierna inferior y descenso descontrolado,Media,Media-alta,Moderada,Alta,Probable,Alta,Alta,Caída pérdida de equilibrio o altura excesiva,Step-up en escalón estable,Step-up con mancuernas o cable,Baja para hipertrofia; moderada EMG,S025,EMG alta no demuestra superioridad; usar si se puede progresar sin impulso
E008,Peso muerto rumano,Bilateral con barra o mancuernas,Barra mancuernas straps opcionales,Bisagra de cadera con carga en flexión,Glúteo mayor isquios y erectores,Zona inferior y media,Máxima flexión con pelvis controlada y rodillas semirrígidas,Mayor momento externo en flexión de cadera,Bisagra real control de columna agarre y ROM individual,Alta,Muy alta,Moderada por fatiga posterior,Muy alta,Probable-alta,Media,Baja-media,Fatiga lumbar agarre o isquios antes que glúteo,RDL con mancuernas,RDL con barra,Moderada biomecánica; baja longitudinal glútea,S022;S023,Cuenta directa si la extensión de cadera es limitante; no hay comparación longitudinal glútea robusta
E009,RDL unilateral,Con apoyo contralateral,Mancuerna TRX poste,Bisagra unilateral,Glúteo mayor medio y menor; isquios,Zona inferior,Flexión de cadera con pelvis controlada,Mayor demanda en la parte profunda,Equilibrio y rotación pélvica,Media; alta con apoyo,Media-alta,Alta con apoyo,Media,Probable,Media,Media,Pérdida de equilibrio rotación o sobrecarga lumbar,RDL unilateral con apoyo,RDL unilateral con cable,Moderada por modelo de fuerzas,S022,Útil con poca carga; el apoyo evita que equilibrio limite
E010,Hiperextensión a 45 grados,Sesgo de extensión de cadera,Banco romano disco o mancuerna,Bisagra y extensión de cadera,Glúteo mayor isquios y erectores,Zona media-superior según técnica,Flexión de cadera en el descenso,Variable con colocación de carga y geometría,Mover desde la cadera y no hiperextender zona lumbar,Alta,Media,Alta local y moderada sistémica,Media,Probable,Baja,Alta,Molestia lumbar o presión en apoyo,RDL ligero o pull-through con banda,Banco a 45 grados,Baja para hipertrofia; moderada EMG,S023,Sustitución de bisagra; EMG no prueba crecimiento
E011,Pull-through,Cable o banda,Polea baja o banda anclada,Bisagra de cadera guiada,Glúteo mayor e isquios,Zona flexionada-media según línea de cable,Flexión de cadera,Tensión relativamente continua; depende del anclaje,Separarse lo suficiente y evitar tirar con brazos o espalda,Muy alta,Alta en cable; media con banda,Alta,Media,Probable,Baja,Alta,Anclaje inseguro o compensación lumbar,Pull-through con banda bien fijada,Pull-through en cable,Baja biomecánica,S007;S025,Alternativa cuando agarre o carga axial limitan el RDL
E012,Patada de glúteo,Cable banda o máquina; rodilla flexionada,Polea banda máquina,Extensión de cadera específica,Glúteo mayor,Zona media o final según dirección de resistencia,Flexión de cadera inicial moderada,Variable con línea del cable; banda aumenta al final,Evitar rotación pélvica y extensión lumbar,Alta,Alta en cable; media con banda,Alta,Baja-media,Moderada probable,Baja,Muy alta,Molestia lumbar o arco pélvico para fabricar recorrido,Patada con banda o extensión arrodillada,Cable o máquina de glúteo,Moderada-baja longitudinal,S001,Buena serie auxiliar; no necesaria si ya hay suficiente extensión acortada
E013,Abducción de cadera,De pie en cable o máquina sentada,Cable máquina banda,Abducción progresable,Glúteo medio y menor; TFL también puede contribuir,Depende de la línea de cable o de la máquina,Aducción inicial tolerada,Cable relativamente uniforme; banda aumenta al separarse,Controlar pelvis y evitar inclinar el tronco,Muy alta,Alta,Alta con fatiga sistémica baja,Baja,Probable para músculo abductor; incierta estética,Baja,Muy alta,Irritación lateral de cadera o compensación pélvica,Abducción de pie con banda,Cable o máquina,Baja longitudinal; moderada EMG,S005;S024,Contar separado del volumen de glúteo mayor
E014,Abducción lateral tumbado,Con banda o lastre de tobillo,Suelo banda lastre,Abducción de cadera,Glúteo medio y menor,Cerca de máxima abducción por gravedad,Aducción al bajar la pierna,Ascendente con máxima dificultad cerca de horizontal,Evitar rotar pelvis y convertirlo en flexión de cadera,Alta,Media-baja,Moderada,Baja,Probable para abductores,Baja,Alta,Molestia lateral o dominio de flexores de cadera,Abducción lateral con banda,Abducción en cable,Baja longitudinal; moderada EMG,S024,Útil en casa si se llega cerca del fallo y puede progresarse
E015,Paseo lateral con banda,Banda en rodillas o tobillos,Banda,Estabilidad frontal y abducción en pasos cortos,Glúteo medio principalmente,Variable durante el apoyo,Sin elongación grande y controlada,Tensión continua de banda,Mantener pelvis y pies controlados,Media,Baja-media,Baja como hipertrofia,Baja,Incierta,Baja,Alta,Fatiga de TFL o técnica degradada,Paseo lateral,Abducción en cable,Baja; evidencia EMG,S024,Preferible como activación o microserie; no contar si queda lejos del fallo
E016,Hip hitch o pelvic drop,En escalón con apoyo,Escalón pared carga opcional,Control frontal de pelvis,Glúteo medio y menor de la pierna de apoyo,Al elevar la pelvis contralateral,Descenso controlado de la hemipelvis,Gravedad; progresión con carga,Evitar flexionar rodilla o inclinar tronco para sustituir el movimiento,Media,Baja-media,Moderada para control; baja para masa,Baja,Incierta,Baja,Media,Molestia lateral de cadera o compensación lumbar,Hip hitch en escalón,Abducción en máquina,Baja longitudinal; moderada EMG,S024,Opción de control y rehabilitación; no necesaria en programa estético si hay abducción progresable
E017,Hip thrust unilateral,Con peso corporal o mancuerna,Banco mancuerna,Extensión unilateral cerca del acortamiento,Glúteo mayor; estabilización frontal,Cerca del bloqueo,Flexión moderada en posición inferior,Ascendente hacia el bloqueo,Evitar rotación pélvica y asimetría de apoyo,Media,Media,Alta con poca carga,Media,Probable,Media,Alta,Rotación pélvica calambres o presión lumbar,Hip thrust unilateral,Máquina unilateral o B-stance,Moderada por modelo de fuerzas,S022,Sustituye al bilateral cuando falta carga; no añadir automáticamente
E018,Frog pump,Bilateral con plantas juntas,Peso corporal banda mancuerna ligera,Extensión acortada de alto número de repeticiones,Glúteo mayor,Final del recorrido,Muy poca elongación,Mayor demanda al final si hay banda,Evitar rango lumbar y repeticiones sin control,Alta,Baja,Baja-moderada,Baja,Incierta como principal,Baja,Muy alta,Presión lumbar o baja progresabilidad,Puente cargado,Hip thrust,Muy baja longitudinal,S025,Técnica metabólica opcional; no reemplaza un ejercicio progresable
E019,Sprint o subida de pendiente,Aceleraciones o cuestas cortas,Exterior,Potencia de extensión de cadera,Glúteo mayor y cadena posterior,Apoyo y aceleración,Variable durante zancada,Balística,Técnica carrera exposición gradual y superficie,Baja-media,Media,Baja para hipertrofia por fatiga e impacto,Media,Incierta,Muy alta,Alta,Isquios Aquiles rodilla o caída,Cuestas cortas progresivas,Trineo o pista,Baja para hipertrofia,S001;S025,Registrar aparte; no contar 1 a 1 como series de hipertrofia
E020,Subida de escaleras o caminata en pendiente,Continua o intervalos,Exterior cinta escaleras,Condicionamiento y extensión repetida,Glúteo mayor y muslo,Variable,Flexión moderada por paso o pendiente,Cíclica submáxima,Evitar convertirla en sustituto de carga progresiva,Alta,Media,Baja para hipertrofia específica,Baja,Incierta,Media,Alta,Sobrecarga por exceso de volumen o molestias de rodilla,Escaleras o cuesta,Cinta inclinada o escaladora,Muy baja para hipertrofia,S001,Complemento de actividad; no serie directa
E021,Curl femoral con fitball,Puente más flexión de rodilla,Fitball,Flexión de rodilla con extensión isométrica de cadera,Isquios; glúteo mayor estabiliza,Cuando la pelota se acerca,Cadera extendida; isquios se alargan con rodilla extendida,Variable por palanca corporal,Mantener pelvis elevada sin arquear lumbar,Media,Media,Moderada para femoral; baja glúteo,Baja,Baja para glúteo; útil transición femoral,Baja,Alta,Calambres de isquios o pérdida de pelvis,Curl con fitball,Curl femoral máquina,Baja para glúteo,S007,No contar como serie directa de glúteo salvo función dominante inesperada
E022,Clamshell,Con banda,Suelo banda,Rotación externa y abducción corta,Glúteo medio posterior y rotadores,Final del recorrido por banda,Cadera flexionada con poca aducción,Ascendente al abrir rodillas,Evitar rodar la pelvis hacia atrás,Alta,Baja,Baja para hipertrofia,Baja,Incierta,Baja,Alta,Irritación lateral o compensación pélvica,Clamshell,Abducción en cable,Muy baja longitudinal; EMG variable,S024,Activación o rehabilitación; no opción principal de masa
```

## 6. Catálogo de intervenciones I001–I021

Se conservan también `uso_domestico_profesional` y `notas`; los 19 campos compartidos coinciden exactamente con `04_BASES_NEUTRALES/04_DATOS_PIEL_Y_TRATAMIENTOS.csv`.

```csv
id,categoria,intervencion,objetivo,uso_domestico_profesional,mecanismo_propuesto,resultado_medido,magnitud,duracion_efecto,tiempo_respuesta,coste_inicial,coste_mantenimiento,riesgos,contraindicaciones,incompatibilidades,poblacion,evidencia_directa,confianza,fuentes,fecha_revision,notas
I001,Rutina base,Ducha tras sudar y cambio de ropa,Reducir fricción oclusión y daño folicular,Doméstico,Retirar sudor y reducir tiempo de contacto con ropa húmeda,Brotes e irritación,No cuantificada; alta plausibilidad,Mientras se mantenga,Días a semanas,€,€,Sequedad si se lava en exceso,Dermatitis activa según limpiador,Exfoliación agresiva simultánea,Personas activas,Guía clínica experta,Probable-alta,S039,2026-07-24,Primera intervención universal
I002,Limpieza,Limpiador suave sin perfume,Higiene con preservación de barrera,Doméstico,Retirar suciedad sin irritación intensa,Sequedad e irritación,Modesta,Mientras se use,Días,€,€,Irritación individual,Alergia a ingredientes,Alcohol o exfoliantes agresivos,Piel corporal general,Consenso clínico,Probable,S039;S040,2026-07-24,No necesita ser antibacteriano
I003,Hidratación,Crema corporal sencilla sin perfume,Mejorar sequedad y barrera,Doméstico,Reducir pérdida de agua y apoyar barrera,Sequedad tacto e irritación,Modesta,Mientras se use,Horas a días,€,€,Oclusión o brote en fórmulas pesadas,Alergia,Aplicación sobre lesiones húmedas extensas,Piel seca o tratada con activos,Consenso clínico,Probable,S040,2026-07-24,Elegir textura tolerable
I004,Acné corporal,Lavado con peróxido de benzoilo 2.5-5%,Reducir lesiones acneiformes superficiales,Doméstico,Acción antimicrobiana y queratolítica,Lesiones inflamatorias,Moderada para acné; incierta para foliculitis,Requiere mantenimiento,4-6 semanas,€,€,Sequedad dermatitis y decoloración de tejidos,Alergia o barrera muy dañada,Introducción simultánea de varios irritantes,Personas con acné; extrapolación a glúteo,Guía fuerte para acné; revisión incierta para foliculitis,Alta para acné; baja-moderada glúteo,S037;S038,2026-07-24,Empezar tres veces por semana
I005,Textura,Urea alrededor del 10%,Suavizar bultos y sequedad,Doméstico,Humectante y queratolítico,Textura y sequedad,Modesta,Requiere mantenimiento,4-6 semanas,€,€,Escozor en piel dañada,Heridas abiertas,Otros queratolíticos al inicio,Queratosis pilaris o sequedad,Guía clínica,Moderada,S040,2026-07-24,Buena relación coste-utilidad
I006,Textura,Ácido láctico corporal,Suavizar queratosis y textura,Doméstico,Exfoliación química e hidratación,Textura,Modesta,Requiere mantenimiento,4-6 semanas,€,€,Irritación fotosensibilidad funcional por barrera alterada,Piel irritada o recién depilada,Retinoide o varios ácidos al inicio,Queratosis pilaris,Guía clínica,Moderada,S040,2026-07-24,Elegirlo como alternativa a urea
I007,Textura/acné,Ácido salicílico corporal,Desobstruir folículos y suavizar,Doméstico,Queratólisis lipofílica,Comedones y textura,Modesta,Requiere mantenimiento,4-8 semanas,€,€,Sequedad irritación,Alergia a salicilatos o superficies muy extensas según producto,Otros exfoliantes al inicio,Acné leve o queratosis,Recomendación condicional en acné,Moderada,S037;S040,2026-07-24,No acumular con ácido láctico
I008,Pigmentación/acné,Ácido azelaico 10-15%,Reducir brotes y marcas posinflamatorias,Doméstico o médico según concentración,Antiinflamatorio queratolítico y modulación de pigmento,Lesiones y PIH,Modesta,Requiere mantenimiento,8-12 semanas,€–€€,€–€€,Escozor sequedad e irritación,Alergia o piel dañada,Introducción simultánea con otros irritantes,Acné y PIH,Guía condicional y evidencia indirecta,Moderada,S037;S041,2026-07-24,Controlar inflamación antes de perseguir manchas
I009,Acné/textura,Retinoide tópico,Comedones acné y renovación cutánea,Doméstico o médico según país y producto,Normalizar queratinización y reducir inflamación,Lesiones textura y pigmentación,Moderada para acné,Requiere mantenimiento,8-12 semanas o más,€–€€,€–€€,Dermatitis irritativa y empeoramiento de PIH por irritación,Embarazo; piel muy irritada; criterio médico para formulaciones,Cera y combinación inicial con múltiples ácidos,Personas con acné,Guía fuerte para acné,Alta para acné; indirecta glúteo,S037;S041;S048,2026-07-24,No introducir junto a otros activos
I010,Depilación,Recortadora dejando 1-2 mm,Reducir vello con mínima agresión,Doméstico,Cortar sin apurado ni arrancado,Irritación y vello visible,Alta para longitud; probable para tolerancia,Días,Inmediato,€–€€,€,Cortes o irritación,Lesión activa dolorosa,Presión excesiva o cabezal sucio,Personas con pseudofoliculitis,Inferencia clínica,Probable,S048,2026-07-24,Primera opción si el afeitado da brotes
I011,Depilación,Afeitado cuidadoso a favor del crecimiento,Eliminar vello a ras,Doméstico,Corte superficial del pelo,Vello e irritación,Alta para depilación; variable para tolerancia,1-3 días,Inmediato,€,€,Cortes quemadura de afeitado y vello encarnado,Lesiones activas extensas,Ácidos o retinoides sobre piel irritada,Personas que afeitan,Guía clínica,Moderada,S048,2026-07-24,No perseguir apurado perfecto
I012,Depilación,Crema depilatoria,Disolver pelo superficial,Doméstico,Ruptura química de queratina,Reducción temporal de pelo,Alta para depilación,Días,Inmediato,€,€,Quemadura química y dermatitis,Piel dañada o reacción en prueba,Otros irritantes o tiempo superior al indicado,Personas tolerantes al producto,Guía clínica,Moderada,S048,2026-07-24,Prueba 24 horas
I013,Depilación,IPL doméstico,Reducir crecimiento de vello,Doméstico,Fototermólisis con energía reducida,Recuento de pelo,Moderada en candidatos adecuados,Mantenimiento periódico,Semanas a meses,€€,€,Quemaduras pigmentación y riesgo ocular por mal uso,Combinación piel-pelo no admitida por aparato; lesiones o tatuajes según manual,Sol bronceado y uso fuera del manual,Usuarios seleccionados,Revisión sistemática,Moderada,S042;S043,2026-07-24,No sirve bien para pelo claro
I014,Depilación profesional,Láser de reducción de vello,Reducir vello encarnado y afeitado recurrente,Profesional,Fototermólisis selectiva del folículo,Recuento de pelo y pseudofoliculitis,Moderada-alta en candidatos,Prolongada con mantenimiento,6 o más sesiones habituales,€€€,€–€€,Dolor quemaduras ampollas infección y cambios pigmentarios,Bronceado lesiones activas y evaluación individual,Parámetros inadecuados para fototipo,Personas con pelo oscuro,Revisiones y guía clínica,Moderada,S043;S048,2026-07-24,Experiencia del operador es crítica
I015,Masaje,Masaje manual suave,Confort y relajación,Doméstico o profesional,Modulación sensorial y desplazamiento temporal de fluidos,Bienestar y apariencia inmediata,Pequeña y transitoria,Horas,Inmediato,€,€,Irritación o hematoma si es agresivo,Pústulas nódulos heridas o posprocedimiento,Ventosas o presión dolorosa,Adultos sanos,Evidencia indirecta,Baja para estética persistente,S046;S047,2026-07-24,No cambia músculo ni fascia de forma permanente
I016,Celulitis,Crema con cafeína o retinol,Disimular celulitis,Doméstico,Cambios de hidratación o grosor epidérmico,Perímetro y apariencia,Pequeña,Solo con uso continuado,Café horas; retinol 6 meses o más,€–€€,€–€€,Irritación alergia y coste continuo,Piel reactiva; aminofilina con inhaladores,Depilación con cera y otros retinoides,Principalmente mujeres,Metaanálisis heterogéneo,Baja-moderada femenina; baja masculina,S044;S047,2026-07-24,No reafirma de forma permanente
I017,Celulitis profesional,Ondas acústicas,Reducir apariencia de celulitis,Profesional,Estimulación mecánica y remodelado tisular propuesto,Escalas fotografía perímetro y ultrasonido,Moderada en mujeres,Duración incierta,6-8 sesiones habituales,€€–€€€,€€,Molestia hematoma y coste,Trastornos de coagulación u otras según equipo,Tratamiento sobre lesión activa,Mujeres con celulitis,Metaanálisis y ECA,Moderada-baja; transferencia masculina incierta,S045;S046,2026-07-24,No priorizar sin diagnóstico visual
I018,Celulitis profesional,Radiofrecuencia,Mejorar laxitud o celulitis leve,Profesional,Calentamiento dérmico y remodelado de colágeno propuesto,Perímetro grosor y apariencia,Pequeña a moderada,Corta; mantenimiento,Varias sesiones,€€€,€€,Dolor calor quemadura y hematoma,Implantes o condiciones específicas según equipo,Lesiones activas y parámetros inadecuados,Principalmente mujeres,Revisión sistemática,Moderada-baja,S046;S047,2026-07-24,Baja prioridad por coste
I019,Celulitis profesional,Subcisión,Liberar hoyuelos anclados,Profesional médico,Corte de septos fibrosos,Hoyuelos y satisfacción,Moderada en lesiones seleccionadas,Años posibles,Una intervención más revisión,€€€€,€,Dolor hematoma infección cicatriz y lesión tisular,Trastornos de coagulación infección y evaluación médica,No aplicable a celulitis difusa sin anclaje,Principalmente mujeres,Estudios clínicos y síntesis,Moderada,S046;S047,2026-07-24,No es tratamiento de bajo coste
I020,Reducción grasa,Criolipólisis,Reducir depósito adiposo localizado,Profesional,Lesión térmica fría de adipocitos,Grosor de grasa,Modesta,Prolongada,Meses,€€€,€,Dolor alteración sensitiva y rara hiperplasia adiposa paradójica,Evaluación médica y sensibilidad al frío,Objetivo de aumentar plenitud glútea,Adultos con grasa localizada,Revisiones de contorno corporal,Moderada para grasa; nula para celulitis,S047,2026-07-24,No recomendada para este proyecto
I021,Procedimiento no recomendado,Mesoterapia o inyecciones no estandarizadas,Reducir celulitis o grasa,Profesional,Mezclas variables,Apariencia y perímetro,Incierta,Incierta,Variable,€€–€€€,€€,Infección alergia nódulos dolor y cambios cutáneos,Numerosas según sustancias,Composición desconocida o no autorizada,Principalmente mujeres,Escasa y heterogénea,Baja,S047,2026-07-24,Mala relación riesgo-beneficio
```

## 7. Qué se eliminó respecto a v1

La plantilla CSV histórica vacía de sesiones (`fecha`, `programa`, `día`, `serie`, `carga`, `RIR`, etc.) **no forma parte de v2**. Su función está superada por `training_history.v1`, el protocolo JSON y el seguimiento longitudinal. Mantenerla aquí crearía un segundo historial susceptible de divergencia.

## 8. Qué no debe hacer esta Source

- escoger automáticamente una variante por una puntuación;
- trasladar cargas entre alternativas;
- considerar dos ejercicios del mismo patrón como estímulos completamente independientes;
- convertir una inferencia biomecánica en superioridad hipertrófica;
- usar sensación/EMG como prueba de crecimiento;
- diagnosticar piel;
- registrar sesiones realizadas.

## 9. Procedencia

Reconstruida desde las tablas neutrales del corpus y el catálogo estructurado íntegro preservado en la Source 13 v1. La comparación campo a campo confirmó que los datos científicos compartidos son idénticos; v1 solo aporta campos auxiliares útiles que el corpus neutral había omitido deliberadamente.

## 10. Registro de cambios

### v2.0 — 2026-08-13

- separa definitivamente catálogo e historial;
- conserva 22 ejercicios y 21 intervenciones;
- incorpora C3-01–C3-10 como conclusiones de selección con límites visibles;
- mantiene alternativas casa/gimnasio sin permitir transferencia de cargas;
- mantiene intervenciones cutáneas separadas de hipertrofia.


# 14_BASE_EVIDENCIA_GIMNASIO_MAQUINAS_TRANSFERENCIA_v2.0.md

# 14 — Base de evidencia de gimnasio, máquinas y transferencia

**Versión:** 2.0  
**Fecha de reconstrucción:** 2026-08-13  
**Estado:** CANÓNICO v2 — auditoría conjunta 12–15 superada; evidencia específica de gimnasio y límites de transferencia.

## 1. Función y autoridad

Esta Source reúne la evidencia que cambia decisiones cuando el entrenamiento se realiza con máquinas, multipower, poleas o pesos libres. Separa tres preguntas que no deben confundirse: **qué ha demostrado un estudio**, **qué puede inferirse de una familia mecánica** y **si un modelo concreto encaja con el usuario**.

La selección operativa y la prueba de encaje pertenecen a `06`; el programa vigente a `03`; la identidad y comparabilidad de una máquina real deben registrarse en el seguimiento. Esta Source no aprueba automáticamente ningún aparato del gimnasio.

## 2. Principios de transferencia

1. “Máquina” no es una intervención única: dos modelos con el mismo nombre pueden tener trayectorias, apoyos, radios de palanca, perfiles de resistencia y saltos de carga diferentes.
2. La similitud media entre máquinas y pesos libres no demuestra equivalencia de dos ejercicios concretos.
3. La fuerza es altamente específica a la modalidad; los kilos no se comparan entre máquinas, Smith, barra o marcas distintas.
4. Una máquina puede ser preferible por estabilidad, seguridad de salida o progresión sin que exista evidencia de mayor hipertrofia por serie.
5. La evidencia de una prensa, hack, belt squat o hip thrust concreto no se transfiere por nombre comercial.
6. EMG o fuerza pico aguda informan biomecánica, no ordenan hipertrofia.
7. El modelo concreto debe superar encaje, reproducibilidad, tolerancia y limitante local antes de convertirse en ejercicio índice.

## 3. Conclusiones CG2 estructuradas

**CG2-01 — Máquinas y pesos libres producen hipertrofia similar en promedio cuando la programación es comparable**  
- Evidencia: Dos metaanálisis y ensayos longitudinales.
- Población: Adultos mixtos; incluye hombres entrenados.
- Resultado: Hipertrofia general.
- Confianza: Probable-alta general; baja glútea.
- Decisión habilitada: Elegir modalidad por función ajuste y progresión.
- Límite: No equipara máquinas distintas ni demuestra igualdad regional del glúteo.
- Parámetros: Probar durante un bloque estable.
- Riesgo de interpretación: Elegir por etiqueta y no por encaje.
- Fuentes: S073;S074;S078.

**CG2-02 — La mejora de fuerza es específica a la modalidad y prueba practicada**  
- Evidencia: Metaanálisis y ensayos.
- Población: Adultos mixtos.
- Resultado: Fuerza dinámica.
- Confianza: Sólida general.
- Decisión habilitada: Conservar la modalidad si importa su 1RM.
- Límite: La fuerza específica no demuestra mejor estética.
- Parámetros: Comparar rendimiento solo dentro del mismo equipo.
- Riesgo de interpretación: Confundir carga de máquina con carga libre.
- Fuentes: S073;S074;S077.

**CG2-03 — El hip thrust con barra tiene evidencia directa pero no se ha demostrado superioridad de una máquina multipower o glute drive**  
- Evidencia: Ensayo longitudinal y biomecánica.
- Población: Jóvenes mixtos y hombres entrenados.
- Resultado: Hipertrofia y cinética.
- Confianza: Probable para el patrón; incierta entre aparatos.
- Decisión habilitada: Usar máquina como sustituto si conserva función y mejora el encaje.
- Límite: No declarar equivalencia o superioridad entre geometrías.
- Parámetros: Bloque de prueba de 4-8 semanas.
- Riesgo de interpretación: Presión pélvica trayectoria fija o extensión lumbar.
- Fuentes: S002;S075.

**CG2-04 — El momento extensor externo del hip thrust con barra disminuye durante el ascenso y no es constante**  
- Evidencia: Biomecánica tridimensional.
- Población: 19 hombres entrenados.
- Resultado: Momento articular.
- Confianza: Probable para esa técnica.
- Decisión habilitada: Evaluar la curva real de cada máquina.
- Límite: No predice hipertrofia ni otras variantes.
- Parámetros: 70% 1RM en el estudio.
- Riesgo de interpretación: Simplificar el perfil como máximo universal en bloqueo.
- Fuentes: S075.

**CG2-05 — La prensa puede hipertrofiar el glúteo mayor pero también vastos y aductor mayor**  
- Evidencia: Ensayo longitudinal con MRI.
- Población: 17 adultos novatos; 11 hombres y 6 mujeres.
- Resultado: Volumen de 17 músculos.
- Confianza: Probable-alta para la máquina estudiada.
- Decisión habilitada: Usar como principal de glúteo y pierna global.
- Límite: No es aislamiento ni prueba superioridad sobre otras máquinas.
- Parámetros: 5x10 a 70% 1RM 2x/semana en el ensayo.
- Riesgo de interpretación: Fatiga de muslo y rango forzado.
- Fuentes: S004.

**CG2-06 — No hay evidencia directa suficiente para ordenar hack pendular V-squat y belt squat por hipertrofia glútea**  
- Evidencia: Ausencia de comparaciones longitudinales y estudios agudos.
- Población: Adultos mixtos.
- Resultado: EMG fuerza y biomecánica.
- Confianza: Incierta.
- Decisión habilitada: Tratarlas como candidatas de alta flexión y probar encaje.
- Límite: No crear un ranking científico por reputación o EMG.
- Parámetros: Una variante principal por bloque.
- Riesgo de interpretación: Redundancia y trayectoria incompatible.
- Fuentes: S080;S071.

**CG2-07 — La guía del multipower puede aumentar la fuerza aplicada en un unilateral al reducir inestabilidad**  
- Evidencia: Estudio agudo cruzado.
- Población: 12 hombres entrenados.
- Resultado: Fuerza pico velocidad y EMG.
- Confianza: Probable aguda; incierta hipertrófica.
- Decisión habilitada: Preferir guía cuando equilibrio limita.
- Límite: No implica mayor crecimiento ni seguridad universal.
- Parámetros: Misma variante y máquina para seguimiento.
- Riesgo de interpretación: Trayectoria impuesta incompatible.
- Fuentes: S076;S077.

**CG2-08 — RDL e hiperextensión son bisagras plausibles pero no existe comparación longitudinal glútea que establezca superioridad**  
- Evidencia: EMG y biomecánica.
- Población: Mujeres entrenadas y muestras biomecánicas.
- Resultado: Activación y función.
- Confianza: Probable funcional; incierta hipertrófica.
- Decisión habilitada: Elegir según limitante agarre espalda femoral y apoyo.
- Límite: No ordenar crecimiento por EMG.
- Parámetros: Mantener una variante índice.
- Riesgo de interpretación: Dominancia lumbar o femoral.
- Fuentes: S022;S023.

**CG2-09 — La hipertrofia de glúteo medio y menor mediante abducción en sanos entrenados continúa insuficientemente demostrada**  
- Evidencia: Ensayo clínico pequeño y evidencia EMG.
- Población: Personas con artrosis y adultos mixtos.
- Resultado: MRI y EMG.
- Confianza: Incierta para estética masculina.
- Decisión habilitada: Usar abducción como volumen separado y experimental.
- Límite: No garantizar plenitud superior ni anchura.
- Parámetros: Dosis conservadora y progresable.
- Riesgo de interpretación: Compensación pélvica o irritación lateral.
- Fuentes: S005;S024.

**CG2-10 — Cambiar anchura o rotación de pies en prensa no mostró aislamiento muscular agudo y no demuestra remodelado regional**  
- Evidencia: Estudio agudo de EMG.
- Población: 28 adultos entrenados; 15 hombres y 13 mujeres.
- Resultado: EMG y cinemática.
- Confianza: Moderada como límite; baja hipertrófica.
- Decisión habilitada: Elegir pies por rango control y comodidad.
- Límite: No extrapolar a pies altos o bajos no estudiados.
- Parámetros: Posición reproducible.
- Riesgo de interpretación: Forzar rotación o anchura por mitos.
- Fuentes: S079.

**CG2-11 — El rango útil debe individualizarse y no puede deducirse solo de la profundidad nominal de la máquina**  
- Evidencia: Ensayos longitudinales y biomecánica.
- Población: Novatos y entrenados mixtos.
- Resultado: Hipertrofia y cinemática.
- Confianza: Probable.
- Decisión habilitada: Usar máximo rango tolerado con pelvis estable.
- Límite: No imponer profundidad universal ni extrapolar cuádriceps a glúteo.
- Parámetros: Registrar topes asiento y recorrido.
- Riesgo de interpretación: Flexión lumbar dolor o pérdida de apoyo.
- Fuentes: S003;S004;S081.

**CG2-12 — Marca modelo y geometría deben registrarse porque la evidencia de una máquina no se transfiere automáticamente a otra**  
- Evidencia: Inferencia biomecánica limitada por estudios de aparato concreto.
- Población: Adultos mixtos.
- Resultado: Trayectoria rango y resultados musculares.
- Confianza: Probable como regla metodológica.
- Decisión habilitada: Crear una prueba de encaje por máquina.
- Límite: No atribuir propiedades universales a una categoría comercial.
- Parámetros: Registrar fotos ajustes y carga mínima.
- Riesgo de interpretación: Comparaciones falsas entre placas y palancas.
- Fuentes: S004;S075;S079;S080.

## 4. Reconciliaciones de alto impacto

### 4.1 Máquinas frente a pesos libres

S073/S074 apoyan resultados hipertróficos globales semejantes en promedio cuando la programación es comparable y recuerdan la especificidad de la fuerza. Esto **no autoriza** a considerar equivalentes una hack, una prensa, una V-squat o una sentadilla libre concreta.

### 4.2 Hip thrust libre, Smith y máquina

La evidencia longitudinal glútea directa corresponde principalmente al patrón con barra (S002, en `12`). S075 describe la biomecánica del barbell hip thrust. No existe en este corpus un ensayo longitudinal que ordene barra, Smith, plate-loaded y glute drive por hipertrofia. Una máquina puede ganar la selección por encaje y logística, no por superioridad científica demostrada.

### 4.3 Alta flexión: prensa, hack, pendular, V-squat y belt squat

S004 demuestra que **una geometría concreta de prensa** puede hipertrofiar glúteo mayor y muslo. S080 aporta activación aguda en belt squat; S071 revisa biomecánica de squat; ninguno permite crear un ranking hipertrófico entre hack, pendular, V-squat y belt squat. El rango útil, la pelvis, el recorrido de cadera, el limitante y el crecimiento colateral deben probarse individualmente.

### 4.4 Smith y estabilidad

S076/S077 permiten hablar de cambios de estabilidad, cinemática y especificidad. No demuestran que la guía produzca más hipertrofia. Una guía inclinada y una vertical son configuraciones distintas y su carga no es comparable.

### 4.5 Posición de pies y ROM

S079 no respalda promesas de aislamiento muscular por cambios simples de anchura/rotación en la prensa estudiada. S081 se refiere a hipertrofia de cuádriceps con rangos de flexión de rodilla concretos y no demuestra que la profundidad sea irrelevante para el glúteo. Evitar extrapolaciones cruzadas de outcome.

## 5. Estudios específicos S073–S081

### S073 — Haugen M et al. Effect of free-weight vs. machine-based strength training on maximal strength hypertrophy and jump performance

- Año: 2023.
- Diseño: Revisión sistemática y metaanálisis.
- Población: Adultos de 18-60 años. Sexo: 789 hombres y 219 mujeres. n: 13 estudios; 1016 participantes. Experiencia: Mixta.
- Duración: 6-12 semanas.
- Intervención: Entrenamiento con pesos libres.
- Comparador: Entrenamiento con máquinas.
- Resultado principal: Sin diferencias en hipertrofia; fuerza específica a la modalidad.
- Medida: Hipertrofia fuerza y salto.
- Aplicación rotulada: No existe superioridad general del tipo de aparato.
- Limitaciones: Solo 5-6 estudios de hipertrofia; medidas heterogéneas; no glúteo específico.
- Confianza: Moderada general; baja específica.
- DOI/URL: https://doi.org/10.1186/s13102-023-00713-4
- Notas: No equipara máquinas con geometrías diferentes.

### S074 — Hernández-Belmonte A et al. Free-Weight and Machine-Based Training Are Equally Effective on Strength and Hypertrophy

- Año: 2023.
- Diseño: Ensayo longitudinal controlado.
- Población: Hombres entrenados. Sexo: Hombres. n: 38. Experiencia: Entrenados.
- Duración: 8 semanas.
- Intervención: Sentadilla press remo y press vertical con barras.
- Comparador: Ejercicios equivalentes en máquinas.
- Resultado principal: Hipertrofia similar; mayor mejora de fuerza en la modalidad practicada.
- Medida: Ecografía de cuádriceps pectoral y recto abdominal; fuerza y molestias.
- Aplicación rotulada: Evidencia directa en hombres entrenados sobre modalidad general.
- Limitaciones: No midió glúteo; corto; programas completos.
- Confianza: Moderada-alta general; baja glútea.
- DOI/URL: https://doi.org/10.1249/MSS.0000000000003271
- Notas: No permite elegir una máquina de glúteo concreta.

### S075 — Brazil A et al. A comprehensive biomechanical analysis of the barbell hip thrust

- Año: 2021.
- Diseño: Estudio biomecánico cruzado.
- Población: Hombres entrenados. Sexo: Hombres. n: 19. Experiencia: Entrenados.
- Duración: Una sesión.
- Intervención: Hip thrust con barra a 70% 1RM.
- Comparador: Comparación de articulaciones y fases.
- Resultado principal: Demanda extensora dominante en cadera; el momento de cadera disminuyó durante el ascenso.
- Medida: Cinemática y cinética tridimensional.
- Aplicación rotulada: Describe el perfil del hip thrust con barra.
- Limitaciones: Agudo; solo barra; no mide hipertrofia ni máquinas.
- Confianza: Moderada biomecánica.
- DOI/URL: https://doi.org/10.1371/journal.pone.0249307
- Notas: Corrige la idea de momento constante o máximo obligatorio en bloqueo.

### S076 — Saeterbakken AH et al. Kinematic and EMG Comparison Between Variations of Unilateral Squats Under Different Stabilities

- Año: 2020.
- Diseño: Estudio agudo cruzado.
- Población: Hombres jóvenes entrenados. Sexo: Hombres. n: 12. Experiencia: 4.3 años de experiencia.
- Duración: Una sesión.
- Intervención: Sentadilla unilateral con multipower.
- Comparador: Misma carga con peso libre.
- Resultado principal: Multipower permitió mayor fuerza pico; la activación varió con estabilidad y repetición.
- Medida: Fuerza velocidad y EMG.
- Aplicación rotulada: Apoya usar guía cuando el equilibrio limita.
- Limitaciones: Agudo; muestra pequeña; no mide hipertrofia.
- Confianza: Moderada para estabilidad; baja para hipertrofia.
- DOI/URL: https://doi.org/10.1055/a-1192-6152
- Notas: No demuestra mayor crecimiento.

### S077 — Marcos-Frutos D et al. Free-Weight and Smith-Machine Squats: Do They Produce Selective Chronic Adaptations in the Effectiveness of Force Application?

- Año: 2025.
- Diseño: Ensayo longitudinal.
- Población: Estudiantes de ciencias del deporte. Sexo: 11 hombres y 9 mujeres. n: 20. Experiencia: Activos; experiencia variable.
- Duración: 8 semanas.
- Intervención: Sentadilla en multipower 2x/semana.
- Comparador: Sentadilla libre con volumen y esfuerzo igualados.
- Resultado principal: Pocas diferencias en dirección de fuerza; adaptación principalmente específica.
- Medida: Fuerza de reacción y rendimiento.
- Aplicación rotulada: No respalda una adaptación mecánica universalmente superior del multipower.
- Limitaciones: No midió hipertrofia; muestra pequeña.
- Confianza: Moderada para fuerza; baja para hipertrofia.
- DOI/URL: https://doi.org/10.1123/ijspp.2025-0104
- Notas: No comparar cargas entre modalidades.

### S078 — Amanuma MT et al. Comparable regional hypertrophy of the knee extensor muscles with machines versus free weights

- Año: 2025.
- Diseño: Ensayo aleatorizado intrapersonal.
- Población: Mujeres jóvenes sanas. Sexo: Mujeres. n: 8. Experiencia: No entrenadas.
- Duración: 9 semanas.
- Intervención: Prensa inclinada unilateral 3x/semana.
- Comparador: Zancada contralateral.
- Resultado principal: Hipertrofia regional de cuádriceps semejante.
- Medida: Ecografía de recto femoral y vasto lateral.
- Aplicación rotulada: Apoya equivalencia potencial de modalidades para el músculo medido.
- Limitaciones: Muestra mínima; solo mujeres novatas; no midió glúteo.
- Confianza: Baja-moderada general; no directa glútea.
- DOI/URL: https://doi.org/10.1016/j.jbmt.2025.09.027
- Notas: No usar para declarar equivalencia glútea.

### S079 — Martín-Fuentes I et al. Influence of Feet Position and Execution Velocity During the Inclined Leg Press

- Año: 2021.
- Diseño: Estudio agudo cruzado.
- Población: Adultos jóvenes entrenados. Sexo: 15 hombres y 13 mujeres. n: 28. Experiencia: Aproximadamente 3 años.
- Duración: Una sesión.
- Intervención: Prensa inclinada a 70% 1RM con distintas anchuras y rotaciones.
- Comparador: Cinco condiciones de pies y velocidad.
- Resultado principal: Anchura y rotación no cambiaron significativamente la activación de los músculos medidos.
- Medida: EMG y cinemática.
- Aplicación rotulada: Cuestiona el ajuste de pies como herramienta de aislamiento.
- Limitaciones: Agudo; midió glúteo medio no mayor; no probó pies altos/bajos ni hipertrofia.
- Confianza: Baja para hipertrofia; moderada como límite técnico.
- DOI/URL: https://doi.org/10.1177/19417381211016357
- Notas: No extrapolar a posiciones no estudiadas.

### S080 — Evans TW et al. Comparison of Muscle Activation Between Back Squats and Belt Squats

- Año: 2019.
- Diseño: Estudio agudo comparativo.
- Población: Adultos con experiencia variable. Sexo: 16 hombres y 15 mujeres. n: 31. Experiencia: Mixta.
- Duración: Una sesión.
- Intervención: Belt squat a 5RM.
- Comparador: Back squat a 5RM.
- Resultado principal: Belt squat mostró menor EMG de glúteo mayor que back squat.
- Medida: EMG superficial y carga.
- Aplicación rotulada: Describe diferencias agudas de una máquina belt squat.
- Limitaciones: EMG no mide hipertrofia; una máquina concreta; sin cinética interna.
- Confianza: Baja para hipertrofia.
- DOI/URL: https://doi.org/10.1519/JSC.0000000000002052
- Notas: No descartar belt squat solo por EMG.

### S081 — Larsen S et al. Knee flexion range of motion does not influence muscle hypertrophy of the quadriceps femoris during leg press training in resistance-trained individuals

- Año: 2025.
- Diseño: Ensayo longitudinal intrapersonal.
- Población: Adultos entrenados. Sexo: Mixta. n: 23. Experiencia: 7.2 años de entrenamiento.
- Duración: 8 semanas.
- Intervención: Prensa unilateral con ROM individual máximo.
- Comparador: Prensa unilateral de 5 a 100 grados de flexión de rodilla.
- Resultado principal: Hipertrofia regional de cuádriceps similar entre rangos.
- Medida: Ecografía de cuádriceps.
- Aplicación rotulada: Aporta evidencia específica de ROM en prensa para cuádriceps.
- Limitaciones: No midió glúteo; ambos rangos incluyeron extensión casi completa; corto.
- Confianza: Moderada para cuádriceps; no directa glútea.
- DOI/URL: https://doi.org/10.1080/02640414.2025.2481534
- Notas: No usar para negar efecto del ROM de cadera sobre glúteo.
- Corrección bibliográfica v2: el corpus atribuía esta referencia a “Lima FV et al.”; DOI 10.1080/02640414.2025.2481534 y PubMed 40113586 identifican a **Stian Larsen et al.** como autores. Se conserva intacto el corpus original y se corrige solo la Source v2.

## 6. Taxonomía de familias de máquinas

La siguiente tabla es una **taxonomía para investigar/probar**, no un ranking. Los campos `disponibilidad_usuario` y `marca_modelo` del corpus son históricos genéricos y no se usan como estado personal actual.

```csv
id,familia,equipo_variante,funcion_candidata,variables_ajuste_criticas,ventaja_a_investigar,limitante_a_investigar,prioridad,observaciones
GM001,Hip thrust,Máquina plate-loaded,Extensión acortada,"Eje, apoyo pélvico, respaldo, plataforma y posición inicial",Estabilidad y carga incremental,"Recorrido impuesto, presión pélvica y encaje corporal",P0,No asumir equivalencia con otros glute drive
GM002,Hip thrust,Máquina selectorizada o glute drive,Extensión acortada,"Trayectoria, cinturón, respaldo, plataforma y topes",Montaje rápido y progresión,Salto de placas y trayectoria fija,P0,Registrar incremento mínimo
GM003,Hip thrust,Multipower con banco,Extensión acortada,"Orientación del banco, altura, trayectoria de la barra y apoyo de pies",Carga estable y reproducible,"Fricción, montaje y trayectoria no compatible",P0,Distinguir Smith vertical e inclinada
GM004,Hip thrust,Barra libre con banco,Extensión acortada,"Altura del banco, discos, acolchado y espacio",Libertad de colocación y sobrecarga,"Montaje, presión y estabilidad del banco",P0,Comparador de referencia
GM005,Prensa,Prensa a 45 grados,Alta flexión bilateral o unilateral,"Ángulo del respaldo, plataforma, profundidad, topes y colocación de pies",Estabilidad y proximidad al fallo,"Flexión pélvica, rodilla, participación de muslo y geometría",P0,No inferir sesgo glúteo solo por pies altos
GM006,Prensa,Prensa horizontal o sentada,Alta flexión bilateral o unilateral,"Respaldo, asiento, recorrido y plataforma",Apoyo de tronco y facilidad unilateral,Rango de cadera disponible y saltos de carga,P0,Evaluar cada modelo
GM007,Sentadilla guiada,Hack squat,Alta flexión de cadera y rodilla,"Ángulo de guía, plataforma, respaldo, profundidad y topes",Estabilidad y progresión,"Demanda de rodilla, muslo y rango pélvico",P0,Separar hack lineal de variantes articuladas
GM008,Sentadilla guiada,Pendulum squat,Alta flexión de cadera y rodilla,"Radio del brazo, plataforma, respaldo y perfil de palanca",Recorrido guiado y perfil variable,"Disponibilidad, encaje y demanda dominante",P0,No asumir superioridad por perfil descendente
GM009,Sentadilla guiada,V-squat o leverage squat,Alta flexión bilateral,"Eje de giro, orientación corporal, plataforma y apoyos",Estabilidad con distintas orientaciones,Trayectoria fija y reparto cadera-rodilla,P1,Registrar orientación usada
GM010,Sentadilla guiada,Belt squat,Alta flexión bilateral,"Punto de anclaje, plataforma, cinturón y profundidad",Reducir carga axial y limitación de espalda,Comodidad pélvica y participación de muslo,P1,"Distinguir cable, palanca y pit belt squat"
GM011,Multipower,Bulgarian split squat o zancada inversa,Alta flexión unilateral,"Inclinación de la guía, distancia de pies, apoyo posterior y soporte",Estabilidad unilateral y carga,"Tiempo, molestias y fatiga local o cardiorrespiratoria",P0,Comparar con mancuerna y prensa unilateral
GM012,Multipower,Sentadilla o RDL,Alta flexión o bisagra elongada,"Trayectoria vertical o inclinada, posición de pies y topes",Estabilidad y menor demanda de agarre,Encaje de trayectoria y fatiga regional,P0,Registrar dirección de la guía
GM013,Hiperextensión,Banco a 45 grados,Bisagra o extensión elongada-media,"Altura de almohadilla, apoyo de pies, carga y rango",Baja complejidad y progresión externa,Dominancia lumbar o femoral y rango útil,P0,Definir técnica sin prometer aislamiento
GM014,Hiperextensión,Banco horizontal o GHD,Extensión de cadera,"Altura de almohadilla, fijación de pies y brazo de palanca",Carga con tronco libre,Fatiga lumbar y dificultad de ajuste,P1,No equiparar automáticamente a banco de 45 grados
GM015,Hiperextensión,Reverse hyper,Extensión de cadera,"Eje, longitud del péndulo, apoyo abdominal y carga",Trayectoria distinta y apoyo de tronco,Disponibilidad y evidencia directa limitada,P2,Mantener como opción no prioritaria hasta G2
GM016,Polea,Patada de glúteo,Extensión específica unilateral,"Altura de polea, línea de cable, tobillera, apoyo y rango",Ajuste fino y baja fatiga sistémica,Compensación pélvica y progresión limitada,P0,Registrar rodilla flexionada o extendida
GM017,Polea,Pull-through,Bisagra,"Altura de polea, cuerda, distancia y apoyo",Tensión externa sin barra ni agarre pesado,"Estabilidad, carga máxima y recorrido",P1,Comparar con RDL e hiperextensión
GM018,Glúteo específico,Máquina de patada o multi-hip,Extensión específica unilateral,"Eje de cadera, almohadilla, apoyo de tronco y recorrido",Estabilidad y medición por lado,Alineación del eje y trayectoria fija,P0,"Separar palanca de pie, arrodillada y prona"
GM019,Abducción,Máquina sentada,Abducción,"Ángulo de cadera, respaldo, almohadillas, rango y carga",Progresión estable del patrón de abducción,Evidencia hipertrófica regional y compensación pélvica,P0,No usar EMG como prueba de crecimiento
GM020,Abducción,Polea o multi-hip de pie,Abducción unilateral,"Altura, alineación del eje, apoyo, rango y posición de cadera",Comparación por lado y dirección ajustable,Equilibrio y movimiento de pelvis,P0,Registrar apoyo externo
GM021,Plataforma,Step-up frontal o lateral,Alta flexión unilateral,"Altura, apoyo, impulso de pierna libre y carga",Libertad antropométrica,Equilibrio y estandarización,P1,No fijar altura universal
GM022,Cardio y potencia,"Trineo, cinta inclinada o escaladora",Complemento de potencia o capacidad de trabajo,"Pendiente, velocidad, resistencia, técnica y duración",Acondicionamiento específico,Fatiga interferente y ausencia de dosis hipertrófica clara,P2,No contar como serie directa por defecto
GM023,Femoral,Curl femoral sentado o tumbado,Transición glúteo-femoral y equilibrio de pierna,"Eje de rodilla, apoyo, longitud inicial y rango",Desarrollo femoral con baja carga axial,No es ejercicio directo de glúteo,P1,"Programar por objetivo femoral, no como volumen glúteo"
GM024,Material libre,"Rack, barra, discos, mancuernas y banco",Comparadores y patrones libres,"Seguros, banco, microcarga, espacio y agarre",Libertad de trayectoria y sobrecarga,"Estabilidad, montaje y fatiga sistémica",P0,Registrar disponibilidad de discos pequeños
```

## 7. Prueba de encaje: marco científico-práctico

Una máquina real solo puede aceptarse como ejercicio índice después de comprobar, en exposiciones reproducibles:

- geometría y ajustes repetibles;
- rango útil sin compensación obligada;
- salida segura;
- limitante compatible con la función buscada;
- vía de progresión;
- ausencia de dolor creciente;
- recuperación posterior aceptable.

La prueba no demuestra superioridad universal: establece **encaje individual**. La versión operativa exacta del protocolo está en `06`.

## 8. Qué se excluye deliberadamente

- rutinas G4 antiguas y distribuciones de días;
- cargas personales y modelos concretos del gimnasio actual;
- rankings absolutos de marcas;
- puntuaciones sumadas para declarar un “ganador universal”;
- cualquier transferencia automática de kilos;
- uso de publicidad del fabricante como evidencia.

## 9. Procedencia

Reconstruida desde `03_GIMNASIO/02_EVIDENCIA_MAQUINAS_Y_EJERCICIOS.md`, `03_GIMNASIO/04_ESTUDIOS_ESPECIFICOS_DE_GIMNASIO.csv`, `03_GIMNASIO/05_CONCLUSIONES_ESPECIFICAS_DE_GIMNASIO.csv`, la taxonomía G1 y el mapa CP-E2. S073–S081 salen de la Source 12 v2 para que esta sea su ubicación científica principal.

## 10. Registro de cambios

### v2.0 — 2026-08-13

- convierte S073–S081 en registro científico canónico de gimnasio;
- conserva CG2-01–CG2-12 con límites y decisiones habilitadas;
- separa evidencia de encaje individual;
- elimina programas G4/G5 del núcleo científico;
- conserva taxonomía sin tratar disponibilidad/modelos históricos como estado actual.


# 15_BASE_EVIDENCIA_FISICO_MASCULINO_INTEGRAL_v2.0.md

# 15 — Base de evidencia del físico masculino integral

**Versión:** 2.0  
**Fecha de reconstrucción:** 2026-08-13  
**Corte científico principal del corpus:** julio de 2026  
**Estado:** CANÓNICO v2 — auditoría conjunta 12–15 superada; evidencia de estética perceptiva e hipertrofia regional del físico completo.

## 1. Función y autoridad

Esta Source conserva la capa científica del Proyecto B que amplió la especialización glútea a un físico masculino completo. Reúne dos tipos de evidencia que deben permanecer separados: **estudios de percepción estética** y **estudios fisiológicos/longitudinales sobre hipertrofia regional**. Una preferencia poblacional no demuestra que un ejercicio produzca una forma concreta, y un ensayo de hipertrofia no determina qué físico debe preferir el usuario.

El objetivo personal se define en `01`, `04` y `10`; esta Source solo informa qué rasgos tienen apoyo contextual y qué regiones disponen de evidencia de entrenamiento. La dosis pertenece a `05`, la selección a `06`/`13`, las máquinas a `14`, el programa vigente a `03` y el estado actual a `02`.

## 2. Regla rectora de interpretación estética

La investigación de atractivo se usa como **contexto**, nunca como techo ni plantilla corporal. En este proyecto, la meta personal vigente es un físico completo muy musculado, con piernas y torso impresionantes y con el glúteo como rasgo excepcional y distintivo. Esa preferencia personal prevalece sobre promedios poblacionales.

Por tanto:

- no se prescribe un ratio hombros–cadera, cintura–cadera, proyección glútea o perímetro “ideal”;
- no se convierte “moderado” o “preferido en promedio” en un límite de muscularidad;
- hombros, espalda, pecho, brazos y piernas pueden desarrollarse de forma muy marcada si preservan la jerarquía personal y la recuperación;
- los estudios de percepción ayudan a entender la lectura visual, no a decidir por sí solos series, ejercicios o tamaños finales.

## 3. Arquitectura y deduplicación v2

El corpus M1/M2 contiene **28 registros de dominio**: 13 M1 y 15 M2. CP-E2 verificó que siete son la misma identidad bibliográfica que estudios ya conservados en `12`: `M1-E04→S013`, `M1-E05→S011`, `M1-E07→S012`, `M1-E09→S015`, `M2-E10→S004`, `M2-E11→S003` y `M2-E15→S002`.

Esta Source conserva esos IDs M1/M2 porque aportan una lectura específica del físico integral, pero **no los cuenta como estudios nuevos**. El resultado son **21 identidades bibliográficas adicionales** y siete alias de estudios canónicos de `12`.

## 4. M1 — Estética masculina y principios generales

### M1-E01 — Apariencia de fuerza
- **Referencia:** Sell A et al. Cues of upper body strength account for most of the variance in men's bodily attractiveness (2017).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Estudios observacionales de valoración fotográfica; 61 y 131 hombres universitarios fotografiados; 163 y 58 evaluadores de atractivo, con mayoría femenina.
- **Resultado reportado por el corpus:** La fuerza percibida explicó aproximadamente 61–73 % de la variación entre cuerpos en atractivo medio.
- **Aplicación interpretativa:** Justifica considerar la apariencia global de fuerza, especialmente del torso, como contexto estético; no prescribe un músculo ni un volumen.
- **Limitaciones:** Muestras jóvenes universitarias; percepción y no intervención; no identifica músculos causales.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pmc.ncbi.nlm.nih.gov/articles/PMC5745404/

### M1-E02 — Relación hombros-cadera
- **Referencia:** Brown M et al. The Interacting Effects of Height and Shoulder-to-Hip Ratio (2022).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Cuatro experimentos de percepción; 659 mujeres heterosexuales; siluetas y figuras renderizadas.
- **Resultado reportado por el corpus:** Una relación hombros-cadera mayor tendió a aumentar atractivo, masculinidad y capacidad de lucha percibida.
- **Aplicación interpretativa:** Apoya usar deltoides y espalda como herramientas para ampliar el marco superior; no establece una relación hombros–cadera objetivo.
- **Limitaciones:** Estímulos artificiales; la interacción dependió del diseño; no proporciona ratio óptimo personal.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/36074312/

### M1-E03 — Preferencia por músculos
- **Referencia:** Durkee PK et al. Men's Bodily Attractiveness: Muscles as Fitness Indicators (2019).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Encuesta transversal; 1.742 reclutados; análisis principal de 1.445 heterosexuales menores de 46 años: 503 mujeres y 942 hombres.
- **Resultado reportado por el corpus:** La parte superior fue importante de forma consistente; el glúteo fue la excepción destacada del tren inferior; hombres prefirieron tamaños mayores.
- **Aplicación interpretativa:** Es compatible con glúteo prioritario y torso desarrollado; no fija el tamaño óptimo de ningún grupo para este usuario.
- **Limitaciones:** Preferencias declaradas; muestra autoseleccionada de audiencia deportiva española; jerarquía femenina mixta.
- **Confianza del corpus:** Moderada-baja.
- **Referencia verificable:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10480816/

### M1-E04 — Prescripción general
- **Referencia:** Currier BS et al. Resistance training prescription for muscle strength and hypertrophy (2023).
- **Identidad bibliográfica canónica:** `S013` en `12`; este registro conserva la lectura específica para físico masculino.
- **Diseño/población:** Revisión sistemática y metaanálisis bayesiano en red; 119 estudios de hipertrofia; 3.364 participantes; 47 % mujeres.
- **Resultado reportado por el corpus:** Todas las prescripciones superaron al control; para hipertrofia destacaron configuraciones de varias series.
- **Aplicación interpretativa:** Principio general de flexibilidad de carga/frecuencia con prioridad a series productivas; identidad científica S013 en 12.
- **Limitaciones:** Heterogeneidad de estudios; rankings no equivalen a superioridad universal; muchas muestras no entrenadas.
- **Confianza del corpus:** Alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/37414459/

### M1-E05 — Volumen y frecuencia
- **Referencia:** Pelland JC et al. The Resistance Training Dose Response (2026).
- **Identidad bibliográfica canónica:** `S011` en `12`; este registro conserva la lectura específica para físico masculino.
- **Diseño/población:** Metarregresiones multinivel; 67 estudios; 2.058 participantes; 79,1 % hombres; edad media 25,16 años.
- **Resultado reportado por el corpus:** El volumen se relacionó positivamente con hipertrofia y mostró rendimientos decrecientes; frecuencia con poco efecto independiente sobre hipertrofia.
- **Aplicación interpretativa:** Informa presupuesto de volumen y rendimientos decrecientes; identidad científica S011 en 12.
- **Limitaciones:** Promedio joven; metarregresión observacional entre estudios; no determina óptimo individual.
- **Confianza del corpus:** Moderada-alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/41343037/
- **Control bibliográfico v2:** VERIFICADO_PRIMARIA_CP_E2.

### M1-E06 — Volumen y físico completo
- **Referencia:** Benito PJ et al. Effect of Resistance Training on Whole-Body Muscle Growth in Healthy Adult Males (2020).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión sistemática y metaanálisis; 111 estudios; 158 grupos; 1.927 hombres sanos.
- **Resultado reportado por el corpus:** El entrenamiento aumentó la masa muscular corporal alrededor de 1,53 kg; demasiadas series por sesión mostraron interacción negativa.
- **Aplicación interpretativa:** Apoya distribuir el trabajo y evitar saturar sesiones; no cuantifica una estética ideal ni un máximo individual.
- **Limitaciones:** Medidas corporales heterogéneas; metarregresión ecológica; no es una comparación de estética.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/32079265/

### M1-E07 — Frecuencia
- **Referencia:** Schoenfeld BJ et al. How many times per week should a muscle be trained (2019).
- **Identidad bibliográfica canónica:** `S012` en `12`; este registro conserva la lectura específica para físico masculino.
- **Diseño/población:** Revisión sistemática y metaanálisis; 25 estudios; adultos con distintos niveles de experiencia.
- **Resultado reportado por el corpus:** No hubo diferencia significativa o relevante entre frecuencias cuando el volumen fue igualado.
- **Aplicación interpretativa:** Permite elegir frecuencia por distribución, calidad y adherencia; identidad científica S012 en 12.
- **Limitaciones:** Calidad y duración variables; evidencia limitada en avanzados.
- **Confianza del corpus:** Alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/30558493/

### M1-E08 — División semanal
- **Referencia:** Ramos-Campo DJ et al. Efficacy of Split Versus Full-Body Resistance Training (2024).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión sistemática y metaanálisis; Ensayos que compararon rutinas divididas y de cuerpo completo.
- **Resultado reportado por el corpus:** Sin diferencias significativas en fuerza o hipertrofia al igualar volumen.
- **Aplicación interpretativa:** Permite elegir split o full-body por logística y calidad cuando el volumen es comparable.
- **Limitaciones:** Número limitado de estudios y protocolos heterogéneos.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/38595233/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M1-E09 — Fallo
- **Referencia:** Grgic J et al. Effects of resistance training performed to repetition failure or non-failure (2022).
- **Identidad bibliográfica canónica:** `S015` en `12`; este registro conserva la lectura específica para físico masculino.
- **Diseño/población:** Revisión sistemática y metaanálisis; 15 estudios; todos con adultos jóvenes.
- **Resultado reportado por el corpus:** Sin diferencia significativa global en fuerza o hipertrofia.
- **Aplicación interpretativa:** El fallo no es requisito universal; identidad científica S015 en 12.
- **Limitaciones:** Poca evidencia en mayores y muy entrenados; definiciones de fallo variables.
- **Confianza del corpus:** Moderada-alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/33497853/
- **Control bibliográfico v2:** VERIFICADO_PRIMARIA_CP_E2.

### M1-E10 — Proximidad al fallo
- **Referencia:** Refalo MC et al. Influence of Resistance Training Proximity-to-Failure (2023).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión sistemática y metaanálisis; 15 estudios de adultos sanos con medidas de hipertrofia.
- **Resultado reportado por el corpus:** No se demostró superioridad del fallo momentáneo; relación posiblemente no lineal.
- **Aplicación interpretativa:** Refuerza que proximidad al fallo debe tratarse como continuo y no como obligación de fallo momentáneo.
- **Limitaciones:** Definiciones y métodos de esfuerzo heterogéneos.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/36334240/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M1-E11 — Rango de movimiento
- **Referencia:** Pallarés JG et al. Effects of range of motion on resistance training adaptations (2021).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión sistemática y metaanálisis; Ensayos de rango completo frente a parcial; predominio de tren inferior.
- **Resultado reportado por el corpus:** El rango completo fue superior para fuerza y para hipertrofia del tren inferior.
- **Aplicación interpretativa:** Favorece usar ROM amplio y tolerado como base, sin extrapolar un único resultado a todos los músculos.
- **Limitaciones:** No generalizar igual a todos los músculos; estudios limitados y ejercicios concretos.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/34170576/

### M1-E12 — Longitud muscular regional
- **Referencia:** Varovic D et al. Does Muscle Length Influence Regional Hypertrophy? (2025).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión sistemática y metaanálisis bayesiano; 12 estudios en adultos jóvenes.
- **Resultado reportado por el corpus:** Las diferencias regionales entre longitudes medias mayores y menores fueron triviales y bastante precisas; ligera tendencia distal.
- **Aplicación interpretativa:** Impide convertir “longitud muscular” en dogma regional universal; la señal depende de músculo y diseño.
- **Limitaciones:** Diferencia media de longitud entre condiciones relativamente pequeña; músculos y métodos heterogéneos.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/40570881/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M1-E13 — Guía general
- **Referencia:** American College of Sports Medicine Position Stand. Resistance Training Prescription (2026).
- **Identidad bibliográfica:** propia de M1; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Revisión de revisiones y posicionamiento; Revisiones de ensayos en adultos sanos de 18 años o más; intervenciones de 6–52 semanas.
- **Resultado reportado por el corpus:** Alrededor de 10 series semanales por músculo favorecen hipertrofia; máquinas y pesos libres, fallo y periodización compleja no mostraron superioridad consistente para el promedio.
- **Aplicación interpretativa:** Marco general de prescripción para adultos sanos; no sustituye la individualización ni las fuentes regionales del proyecto.
- **Limitaciones:** Depende de revisiones con solapamiento y heterogeneidad; no está orientada a estética regional avanzada.
- **Confianza del corpus:** Alta para principios generales.
- **Referencia verificable:** https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

## 5. M2 — Evidencia de hipertrofia regional del físico completo

### M2-E01 — Deltoides lateral
- **Referencia:** Larsen S et al. Dumbbell versus cable lateral raises for lateral deltoid hypertrophy (2025).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 24 hombres y mujeres entrenados.
- **Intervención/comparación:** Cinco series dos veces por semana durante 8 semanas; cable en un brazo y mancuerna en el otro; rango igualado.
- **Resultado medido:** Grosor proximal y distal por ecografía.
- **Hallazgo del corpus:** Ambas condiciones aumentaron aproximadamente 3,3–4,6 % sin diferencias relevantes.
- **Límite relevante:** Duración corta; series al fallo; resultado no generaliza a rangos o configuraciones distintas.
- **Confianza del corpus:** Moderada-alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/40692697/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E02 — Deltoides porciones
- **Referencia:** Campos YAC et al. Different Shoulder Exercises Affect the Activation of Deltoid Portions (2020).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Estudio agudo de EMG; 13 hombres entrenados.
- **Intervención/comparación:** Press banca, fly, press hombro y elevación lateral al 60 % 1RM.
- **Resultado medido:** EMG de deltoides anterior, medial y posterior.
- **Hallazgo del corpus:** Press hombro y elevación lateral mostraron mayor excitación medial; datos regionales agudos.
- **Límite relevante:** EMG no demuestra hipertrofia y las variantes fueron concretas.
- **Confianza del corpus:** Baja como hipertrofia; moderada biomecánica.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/33312291/

### M2-E03 — Pectoral regional
- **Referencia:** Chaves SFN et al. Effects of Horizontal and Incline Bench Press on Neuromuscular Adaptations (2020).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo aleatorizado longitudinal; 47 hombres jóvenes no entrenados; 30 con datos de grosor.
- **Intervención/comparación:** Press horizontal, inclinado o combinación; una vez semanal; 8 semanas.
- **Resultado medido:** Grosor en tres espacios intercostales, fuerza y EMG.
- **Hallazgo del corpus:** Inclinado favoreció el sitio superior; dos de tres sitios no difirieron.
- **Límite relevante:** Pocos datos completos; frecuencia baja; muestra no entrenada; 8 semanas.
- **Confianza del corpus:** Moderada-baja.
- **Referencia verificable:** https://pmc.ncbi.nlm.nih.gov/articles/PMC7449336/

### M2-E04 — Pectoral regional
- **Referencia:** Cabral HV et al. Non-uniform excitation of the pectoralis major during flat and inclined bench press (2022).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Estudio agudo con EMG de alta densidad; 8 voluntarios.
- **Intervención/comparación:** Press plano y 45 grados al 50 y 70 % 1RM.
- **Resultado medido:** Distribución espacial de excitación.
- **Hallazgo del corpus:** El centro de excitación se desplazó hacia región clavicular en inclinado.
- **Límite relevante:** Muestra muy pequeña; activación aguda no es crecimiento.
- **Confianza del corpus:** Baja como hipertrofia; moderada biomecánica.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/34644424/

### M2-E05 — Dorsal ancho
- **Referencia:** Paoli A et al. Latissimus dorsi muscle fiber hypertrophy after resistance training (2016).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal con dieta comparada; 18 jóvenes novatos.
- **Intervención/comparación:** Programa progresivo de 8 semanas con jalón; proteína normal o alta.
- **Resultado medido:** MRI, fibras musculares y fuerza.
- **Hallazgo del corpus:** El entrenamiento aumentó sección transversal y fuerza del dorsal; proteína adicional no mejoró el resultado.
- **Límite relevante:** No comparó ejercicios ni regiones del dorsal; muestra pequeña.
- **Confianza del corpus:** Moderada para crecimiento general; baja regional.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/27258300/

### M2-E06 — Jalón y agarre
- **Referencia:** Andersen V et al. Effects of grip width on muscle strength and activation in the lat pull-down (2014).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Estudio agudo cruzado; 15 hombres.
- **Intervención/comparación:** Jalón 6RM con agarres de 1, 1,5 y 2 veces ancho biacromial.
- **Resultado medido:** Carga y EMG.
- **Hallazgo del corpus:** Diferencias de activación pequeñas; agarres estrecho/medio permitieron algo más de carga.
- **Límite relevante:** EMG no demuestra hipertrofia; no midió regiones del dorsal.
- **Confianza del corpus:** Baja.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/24662157/

### M2-E07 — Tríceps
- **Referencia:** Maeo S et al. Triceps brachii hypertrophy after overhead versus neutral arm extension (2023).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 21 adultos.
- **Intervención/comparación:** Cinco series de 10 repeticiones, dos veces por semana, 12 semanas; un brazo overhead y otro neutral.
- **Resultado medido:** Volumen MRI de cabeza larga, lateral+medial y total.
- **Hallazgo del corpus:** Overhead produjo más crecimiento total, especialmente cabeza larga.
- **Límite relevante:** Un ejercicio y una población; tolerancia articular individual.
- **Confianza del corpus:** Alta para la comparación.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/35819335/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E08 — Bíceps regional
- **Referencia:** Kassiano W et al. Distinct muscle growth after preacher and incline biceps curls (2025).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo aleatorizado entre grupos; 63 mujeres jóvenes.
- **Intervención/comparación:** Curl predicador o inclinado, dos veces por semana, 8 semanas.
- **Resultado medido:** Grosor proximal, medio y distal; 3RM.
- **Hallazgo del corpus:** Inclinado favoreció proximal y predicador distal; fuerza específica.
- **Límite relevante:** Solo mujeres jóvenes; resistencia y longitud no perfectamente aisladas.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/39809454/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E09 — Bíceps regional
- **Referencia:** Attarieh P et al. Preacher versus Bayesian cable curls (2025).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 15 hombres jóvenes.
- **Intervención/comparación:** 3–5 series de 8–12RM, dos veces por semana, 10 semanas; perfiles de resistencia igualados.
- **Resultado medido:** Grosor regional de bíceps y braquial; 1RM.
- **Hallazgo del corpus:** Ambas variantes crecieron de forma semejante sin diferencias regionales significativas.
- **Límite relevante:** Muestra pequeña; ecografía y duración limitada.
- **Confianza del corpus:** Moderada.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/40082069/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E10 — Cuádriceps, glúteo y aductor
- **Referencia:** Kinoshita M et al. Knee extension versus leg press (2026).
- **Identidad bibliográfica canónica:** `S004` en `12`; aquí se conserva el resultado regional relevante para el físico integral.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 17 adultos no entrenados.
- **Intervención/comparación:** Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas.
- **Resultado medido:** MRI de 17 músculos.
- **Hallazgo del corpus:** Vastos similares; recto femoral +13,2 % vs +1,1 % a favor de extensión; prensa aumentó glúteo +15,4 % y aductor mayor +6,2 %.
- **Límite relevante:** Muestra pequeña y no entrenada; alto volumen por ejercicio.
- **Confianza del corpus:** Alta para la comparación.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/41630124/
- **Control bibliográfico v2:** VERIFICADO_PRIMARIA_CP_E2.

### M2-E11 — Sentadilla, glúteo y aductores
- **Referencia:** Kubo K et al. Effects of squat training with different depths on lower limb muscle volumes (2019).
- **Identidad bibliográfica canónica:** `S003` en `12`; aquí se conserva el resultado regional relevante para el físico integral.
- **Diseño/población:** Ensayo aleatorizado; 17 hombres; 8 sentadilla completa y 9 media.
- **Intervención/comparación:** Dos días por semana, 10 semanas.
- **Resultado medido:** MRI de extensores, femorales, aductores y glúteo.
- **Hallazgo del corpus:** Vastos crecieron similar; completa produjo más glúteo y aductores; recto femoral y femorales no crecieron.
- **Límite relevante:** Muestra pequeña; grupos independientes; técnica y carga específicas.
- **Confianza del corpus:** Moderada-alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/31230110/
- **Control bibliográfico v2:** VERIFICADO_IDENTIDAD_CP_E2.

### M2-E12 — Cuádriceps regional
- **Referencia:** Kojic D et al. Does Back Squat Exercise Lead to Regional Hypertrophy among Quadriceps Femoris Muscles? (2022).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal sin control; 18 universitarios; 9 mujeres.
- **Intervención/comparación:** Sentadilla paralela dos veces por semana durante 7 semanas.
- **Resultado medido:** Área transversal de cuatro cabezas del cuádriceps.
- **Hallazgo del corpus:** Crecieron las cuatro cabezas; asociación de fuerza más clara con vasto lateral.
- **Límite relevante:** Sin grupo comparador; intervención corta y poca potencia para diferencias.
- **Confianza del corpus:** Moderada-baja.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/36498298/

### M2-E13 — Femorales
- **Referencia:** Maeo S et al. Seated versus prone leg curl training (2021).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 20 adultos sanos.
- **Intervención/comparación:** Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas.
- **Resultado medido:** Volumen MRI de cada femoral.
- **Hallazgo del corpus:** Curl sentado produjo más crecimiento total: +14 % vs +9 %; ventaja en porciones biarticulares.
- **Límite relevante:** Muestra pequeña; un protocolo; no comparó bisagras.
- **Confianza del corpus:** Alta para la comparación.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/33009197/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E14 — Pantorrilla
- **Referencia:** Kinoshita M et al. Standing versus seated calf-raise training (2023).
- **Identidad bibliográfica:** propia de M2; no duplicada en el backbone S001–S072 tras CP-E2.
- **Diseño/población:** Ensayo longitudinal intrapersonal; 14 adultos no entrenados.
- **Intervención/comparación:** Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas.
- **Resultado medido:** Volumen MRI de gastrocnemio y sóleo.
- **Hallazgo del corpus:** De pie superó claramente a sentado para gastrocnemios; sóleo similar.
- **Límite relevante:** Muestra pequeña y no entrenada; alto volumen.
- **Confianza del corpus:** Alta para la comparación.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/38156065/
- **Control bibliográfico v2:** VERIFICADO_PUBMED_2026-08-13.

### M2-E15 — Glúteo y muslo
- **Referencia:** Plotkin DL et al. Hip thrust and back squat training (2023).
- **Identidad bibliográfica canónica:** `S002` en `12`; aquí se conserva el resultado regional relevante para el físico integral.
- **Diseño/población:** Ensayo aleatorizado; 34 universitarios no entrenados: hip thrust n=18, sentadilla n=16.
- **Intervención/comparación:** Volumen igualado, 9 semanas supervisadas.
- **Resultado medido:** MRI regional glútea, cuádriceps, aductores y femorales.
- **Hallazgo del corpus:** Hip thrust y sentadilla: hipertrofia glútea similar; sentadilla: más cuádriceps/aductores; femorales poco o nada.
- **Límite relevante:** No entrenados; duración corta; financiación parcial vinculada al hip thrust declarada.
- **Confianza del corpus:** Moderada-alta.
- **Referencia verificable:** https://pubmed.ncbi.nlm.nih.gov/37877099/
- **Control bibliográfico v2:** VERIFICADO_PRIMARIA_CP_E2.

## 6. Síntesis por región y fuerza de inferencia

### 6.1 Marco superior: deltoides y espalda

- **Percepción:** M1-E01/M1-E02 hacen plausible que una apariencia de fuerza del torso y mayor contraste hombros–cadera influyan en la lectura masculina de las muestras estudiadas. Esto no fija una proporción personal.
- **Deltoides lateral:** M2-E01 aporta evidencia longitudinal directa de que cable y mancuerna pueden producir hipertrofia similar cuando el recorrido se iguala. M2-E02 es EMG aguda y solo apoya biomecánica.
- **Dorsal:** M2-E05 confirma que un programa progresivo con jalón puede hipertrofiar el dorsal; M2-E06 no justifica prometer “dorsal inferior/superior” mediante anchuras de agarre.
- **Decisión de transferencia:** desarrollar con fuerza el marco superior es compatible con el objetivo personal, pero el ejercicio concreto se elige por encaje, función y progresión, no por estudios de atractivo.

### 6.2 Pectoral

- M2-E03 aporta una señal longitudinal de mayor crecimiento en un sitio superior con press inclinado, con muestra pequeña/incompleta y duración corta.
- M2-E04 muestra excitación regional aguda distinta entre plano e inclinado, pero no es evidencia de hipertrofia.
- La aplicación defendible es cubrir al menos patrones inclinados y horizontales cuando el presupuesto lo permita; no existe un ángulo universal ni evidencia para múltiples inclinaciones redundantes.

### 6.3 Brazos

- **Tríceps:** M2-E07 es una comparación longitudinal intrapersonal con MRI y favorece la extensión overhead para hipertrofia total y, especialmente, cabeza larga dentro de ese protocolo.
- **Bíceps:** M2-E08 sugiere respuestas regionales distintas entre predicador e inclinado en mujeres jóvenes; M2-E09, con perfiles de resistencia mejor igualados en hombres, no encontró diferencias regionales significativas entre predicador y Bayesian. La reconciliación correcta es que el ángulo del hombro por sí solo no garantiza un sesgo regional reproducible.
- Por tanto, el proyecto puede desarrollar brazos de forma deliberada sin depender de claims de “pico”, “cabeza larga” o regionalización no demostrada.

### 6.4 Cuádriceps y aductores

- M2-E10/S004 muestra que la extensión de rodilla puede cubrir recto femoral de forma que la prensa estudiada no hizo, mientras la prensa desarrolló vastos, glúteo y aductor mayor.
- M2-E11/S003 muestra que una sentadilla más profunda produjo más crecimiento de glúteo y aductores que media sentadilla en el ensayo disponible, sin mayor crecimiento claro de vastos.
- M2-E12 confirma que la sentadilla puede hipertrofiar las cuatro cabezas del cuádriceps, pero su diseño sin control y duración corta limitan inferencias regionales finas.
- Esto permite construir piernas muy musculadas controlando cuánto volumen adicional de cuádriceps/aductor se añade, en vez de asumir que la prioridad glútea exige mantenerlos pequeños.

### 6.5 Femorales

- M2-E13 aporta evidencia longitudinal intrapersonal con MRI a favor del curl sentado frente al prono para hipertrofia total de femorales, especialmente porciones biarticulares, dentro del protocolo estudiado.
- No compara el curl con una bisagra; por tanto, no demuestra que flexión de rodilla sustituya al RDL ni viceversa.

### 6.6 Pantorrilla

- M2-E14 aporta evidencia longitudinal intrapersonal con MRI: la variante de pie produjo mucha más hipertrofia del gastrocnemio que la sentada; el sóleo respondió de forma similar.
- Esto respalda priorizar una variante con rodilla extendida cuando se busca desarrollo visible del gastrocnemio, sin convertir un único ensayo en regla absoluta para toda máquina o técnica.

### 6.7 Glúteo dentro del físico completo

- M1-E03 aporta una señal de que el glúteo fue una excepción relevante entre músculos del tren inferior en la muestra de preferencias estudiada.
- M2-E15/S002 confirma que hip thrust y sentadilla pueden producir crecimiento glúteo similar en novatos, con más cuádriceps/aductores en sentadilla.
- La prioridad excepcional del glúteo del proyecto es una **preferencia personal explícita**, no una consecuencia obligada de estos estudios.

## 7. Reconciliaciones y controversias que esta Source debe impedir

### 7.1 Atractivo poblacional ≠ objetivo personal

Los estudios M1-E01–E03 describen asociaciones o preferencias en muestras específicas. No autorizan a limitar la muscularidad, fijar ratios, ni reemplazar la preferencia individual. Cuando la dirección personal y el promedio poblacional difieran, el sistema usa el promedio solo como contexto.

### 7.2 Regionalización ≠ “esculpir” libremente un músculo

M2 contiene señales regionales reales en varios grupos, pero su transferibilidad depende del músculo, ejercicio, longitud, perfil de resistencia, medición y población. No se extrapola una regionalización demostrada en tríceps o femoral al dorsal, deltoides posterior o glúteo.

### 7.3 EMG ≠ hipertrofia

M2-E02, M2-E04 y M2-E06 son evidencia aguda útil para comprender excitación/biomecánica; no se usan para ordenar crecimiento frente a ensayos longitudinales.

### 7.4 Resultados aparentemente discordantes de bíceps

M2-E08 y M2-E09 no se “promedian” como si fueran el mismo experimento. Difieren en sexo, diseño, ejercicios y perfiles de resistencia. La conclusión conservadora es que existen señales de crecimiento regional, pero no una regla simple basada solo en posición del hombro.

### 7.5 Principios generales duplicados

M1-E04, E05, E07 y E09 no crean una segunda autoridad sobre volumen, frecuencia o fallo. Sus identidades S013/S011/S012/S015 siguen gobernadas científicamente por `12`; aquí solo explican su relevancia para un programa de cuerpo completo.

## 8. Flujo de transferencia a la capa operativa

La secuencia correcta es:

`15 evidencia estética/regional → 04 interpretación estética y prioridades → 05 dosis y fatiga → 06/13 selección de ejercicio → 03 programa`

Las observaciones visuales posteriores siguen el flujo `10 → 04 → 05 → 03`; una foto no modifica directamente el programa desde esta base científica.

## 9. Límites actuales y preguntas abiertas

- La mayor parte de la evidencia regional sigue procediendo de adultos jóvenes y, en varios estudios, novatos.
- Hay pocos ensayos longitudinales que comparen directamente ejercicios para deltoides posterior, regiones del dorsal o espalda media.
- No existe evidencia que determine la combinación óptima de muscularidad de torso, brazos, muslo y glúteo para este usuario.
- Las preferencias de atractivo dependen de muestra, cultura, orientación, estímulo visual y pregunta realizada.
- La estructura ósea, inserciones, distribución de grasa, piel, postura y presentación modifican la lectura estética y no son equivalentes a hipertrofia.
- El volumen óptimo por región sigue siendo una calibración individual; no se deriva de una jerarquía estética poblacional.

## 10. Control bibliográfico v2 y trazabilidad

La reconstrucción parte de `05_ESTUDIOS_ESTETICA_MASCULINA.csv`, `06_ESTUDIOS_HIPERTROFIA_REGIONAL.csv`, sus copias de Proyecto B y el mapa CP-E1/CP-E2. Las duplicaciones identificadas se conservan como alias de dominio, no como nuevos estudios.

En la auditoría v2 se volvieron a comprobar en fuentes primarias varios registros de alto impacto o riesgo de sobreinterpretación: M1-E08, M1-E10, M1-E12, M1-E13, M2-E01, M2-E07, M2-E08, M2-E09, M2-E13 y M2-E14, además de las identidades duplicadas ya verificadas en CP-E2. Esta comprobación bibliográfica no convierte el corpus en una revisión sistemática nueva ni elimina la necesidad de actualizar evidencia futura.

## 11. Anexo estructurado M1/M2 con identidad canónica

El anexo conserva las filas del corpus y añade únicamente `identidad_canonica` y `estado_identidad_v2` para evitar doble conteo.

### 11.1 M1 — tabla estructurada

```csv
"ID","identidad_canonica","estado_identidad_v2","Tema","Referencia","Año","Diseño","Participantes","Resultado relevante","Limitaciones","Confianza","URL"
"M1-E01","M1-E01","UNICA_15","Apariencia de fuerza","Sell A et al. Cues of upper body strength account for most of the variance in men's bodily attractiveness","2017","Estudios observacionales de valoración fotográfica","61 y 131 hombres universitarios fotografiados; 163 y 58 evaluadores de atractivo, con mayoría femenina","La fuerza percibida explicó aproximadamente 61–73 % de la variación entre cuerpos en atractivo medio","Muestras jóvenes universitarias; percepción y no intervención; no identifica músculos causales","Moderada","https://pmc.ncbi.nlm.nih.gov/articles/PMC5745404/"
"M1-E02","M1-E02","UNICA_15","Relación hombros-cadera","Brown M et al. The Interacting Effects of Height and Shoulder-to-Hip Ratio","2022","Cuatro experimentos de percepción","659 mujeres heterosexuales; siluetas y figuras renderizadas","Una relación hombros-cadera mayor tendió a aumentar atractivo, masculinidad y capacidad de lucha percibida","Estímulos artificiales; la interacción dependió del diseño; no proporciona ratio óptimo personal","Moderada","https://pubmed.ncbi.nlm.nih.gov/36074312/"
"M1-E03","M1-E03","UNICA_15","Preferencia por músculos","Durkee PK et al. Men's Bodily Attractiveness: Muscles as Fitness Indicators","2019","Encuesta transversal","1.742 reclutados; análisis principal de 1.445 heterosexuales menores de 46 años: 503 mujeres y 942 hombres","La parte superior fue importante de forma consistente; el glúteo fue la excepción destacada del tren inferior; hombres prefirieron tamaños mayores","Preferencias declaradas; muestra autoseleccionada de audiencia deportiva española; jerarquía femenina mixta","Moderada-baja","https://pmc.ncbi.nlm.nih.gov/articles/PMC10480816/"
"M1-E04","S013","ALIAS_12","Prescripción general","Currier BS et al. Resistance training prescription for muscle strength and hypertrophy","2023","Revisión sistemática y metaanálisis bayesiano en red","119 estudios de hipertrofia; 3.364 participantes; 47 % mujeres","Todas las prescripciones superaron al control; para hipertrofia destacaron configuraciones de varias series","Heterogeneidad de estudios; rankings no equivalen a superioridad universal; muchas muestras no entrenadas","Alta","https://pubmed.ncbi.nlm.nih.gov/37414459/"
"M1-E05","S011","ALIAS_12","Volumen y frecuencia","Pelland JC et al. The Resistance Training Dose Response","2026","Metarregresiones multinivel","67 estudios; 2.058 participantes; 79,1 % hombres; edad media 25,16 años","El volumen se relacionó positivamente con hipertrofia y mostró rendimientos decrecientes; frecuencia con poco efecto independiente sobre hipertrofia","Promedio joven; metarregresión observacional entre estudios; no determina óptimo individual","Moderada-alta","https://pubmed.ncbi.nlm.nih.gov/41343037/"
"M1-E06","M1-E06","UNICA_15","Volumen y físico completo","Benito PJ et al. Effect of Resistance Training on Whole-Body Muscle Growth in Healthy Adult Males","2020","Revisión sistemática y metaanálisis","111 estudios; 158 grupos; 1.927 hombres sanos","El entrenamiento aumentó la masa muscular corporal alrededor de 1,53 kg; demasiadas series por sesión mostraron interacción negativa","Medidas corporales heterogéneas; metarregresión ecológica; no es una comparación de estética","Moderada","https://pubmed.ncbi.nlm.nih.gov/32079265/"
"M1-E07","S012","ALIAS_12","Frecuencia","Schoenfeld BJ et al. How many times per week should a muscle be trained","2019","Revisión sistemática y metaanálisis","25 estudios; adultos con distintos niveles de experiencia","No hubo diferencia significativa o relevante entre frecuencias cuando el volumen fue igualado","Calidad y duración variables; evidencia limitada en avanzados","Alta","https://pubmed.ncbi.nlm.nih.gov/30558493/"
"M1-E08","M1-E08","UNICA_15","División semanal","Ramos-Campo DJ et al. Efficacy of Split Versus Full-Body Resistance Training","2024","Revisión sistemática y metaanálisis","Ensayos que compararon rutinas divididas y de cuerpo completo","Sin diferencias significativas en fuerza o hipertrofia al igualar volumen","Número limitado de estudios y protocolos heterogéneos","Moderada","https://pubmed.ncbi.nlm.nih.gov/38595233/"
"M1-E09","S015","ALIAS_12","Fallo","Grgic J et al. Effects of resistance training performed to repetition failure or non-failure","2022","Revisión sistemática y metaanálisis","15 estudios; todos con adultos jóvenes","Sin diferencia significativa global en fuerza o hipertrofia","Poca evidencia en mayores y muy entrenados; definiciones de fallo variables","Moderada-alta","https://pubmed.ncbi.nlm.nih.gov/33497853/"
"M1-E10","M1-E10","UNICA_15","Proximidad al fallo","Refalo MC et al. Influence of Resistance Training Proximity-to-Failure","2023","Revisión sistemática y metaanálisis","15 estudios de adultos sanos con medidas de hipertrofia","No se demostró superioridad del fallo momentáneo; relación posiblemente no lineal","Definiciones y métodos de esfuerzo heterogéneos","Moderada","https://pubmed.ncbi.nlm.nih.gov/36334240/"
"M1-E11","M1-E11","UNICA_15","Rango de movimiento","Pallarés JG et al. Effects of range of motion on resistance training adaptations","2021","Revisión sistemática y metaanálisis","Ensayos de rango completo frente a parcial; predominio de tren inferior","El rango completo fue superior para fuerza y para hipertrofia del tren inferior","No generalizar igual a todos los músculos; estudios limitados y ejercicios concretos","Moderada","https://pubmed.ncbi.nlm.nih.gov/34170576/"
"M1-E12","M1-E12","UNICA_15","Longitud muscular regional","Varovic D et al. Does Muscle Length Influence Regional Hypertrophy?","2025","Revisión sistemática y metaanálisis bayesiano","12 estudios en adultos jóvenes","Las diferencias regionales entre longitudes medias mayores y menores fueron triviales y bastante precisas; ligera tendencia distal","Diferencia media de longitud entre condiciones relativamente pequeña; músculos y métodos heterogéneos","Moderada","https://pubmed.ncbi.nlm.nih.gov/40570881/"
"M1-E13","M1-E13","UNICA_15","Guía general","American College of Sports Medicine Position Stand. Resistance Training Prescription","2026","Revisión de revisiones y posicionamiento","Revisiones de ensayos en adultos sanos de 18 años o más; intervenciones de 6–52 semanas","Alrededor de 10 series semanales por músculo favorecen hipertrofia; máquinas y pesos libres, fallo y periodización compleja no mostraron superioridad consistente para el promedio","Depende de revisiones con solapamiento y heterogeneidad; no está orientada a estética regional avanzada","Alta para principios generales","https://pmc.ncbi.nlm.nih.gov/articles/PMC12965823/"
```

### 11.2 M2 — tabla estructurada

```csv
"ID","identidad_canonica","estado_identidad_v2","Región","Referencia","Año","Diseño","Participantes","Intervención o comparación","Resultado medido","Hallazgo principal","Límite relevante","Confianza","URL"
"M2-E01","M2-E01","UNICA_15","Deltoides lateral","Larsen S et al. Dumbbell versus cable lateral raises for lateral deltoid hypertrophy","2025","Ensayo longitudinal intrapersonal","24 hombres y mujeres entrenados","Cinco series dos veces por semana durante 8 semanas; cable en un brazo y mancuerna en el otro; rango igualado","Grosor proximal y distal por ecografía","Ambas condiciones aumentaron aproximadamente 3,3–4,6 % sin diferencias relevantes","Duración corta; series al fallo; resultado no generaliza a rangos o configuraciones distintas","Moderada-alta","https://pubmed.ncbi.nlm.nih.gov/40692697/"
"M2-E02","M2-E02","UNICA_15","Deltoides porciones","Campos YAC et al. Different Shoulder Exercises Affect the Activation of Deltoid Portions","2020","Estudio agudo de EMG","13 hombres entrenados","Press banca, fly, press hombro y elevación lateral al 60 % 1RM","EMG de deltoides anterior, medial y posterior","Press hombro y elevación lateral mostraron mayor excitación medial; datos regionales agudos","EMG no demuestra hipertrofia y las variantes fueron concretas","Baja como hipertrofia; moderada biomecánica","https://pubmed.ncbi.nlm.nih.gov/33312291/"
"M2-E03","M2-E03","UNICA_15","Pectoral regional","Chaves SFN et al. Effects of Horizontal and Incline Bench Press on Neuromuscular Adaptations","2020","Ensayo aleatorizado longitudinal","47 hombres jóvenes no entrenados; 30 con datos de grosor","Press horizontal, inclinado o combinación; una vez semanal; 8 semanas","Grosor en tres espacios intercostales, fuerza y EMG","Inclinado favoreció el sitio superior; dos de tres sitios no difirieron","Pocos datos completos; frecuencia baja; muestra no entrenada; 8 semanas","Moderada-baja","https://pmc.ncbi.nlm.nih.gov/articles/PMC7449336/"
"M2-E04","M2-E04","UNICA_15","Pectoral regional","Cabral HV et al. Non-uniform excitation of the pectoralis major during flat and inclined bench press","2022","Estudio agudo con EMG de alta densidad","8 voluntarios","Press plano y 45 grados al 50 y 70 % 1RM","Distribución espacial de excitación","El centro de excitación se desplazó hacia región clavicular en inclinado","Muestra muy pequeña; activación aguda no es crecimiento","Baja como hipertrofia; moderada biomecánica","https://pubmed.ncbi.nlm.nih.gov/34644424/"
"M2-E05","M2-E05","UNICA_15","Dorsal ancho","Paoli A et al. Latissimus dorsi muscle fiber hypertrophy after resistance training","2016","Ensayo longitudinal con dieta comparada","18 jóvenes novatos","Programa progresivo de 8 semanas con jalón; proteína normal o alta","MRI, fibras musculares y fuerza","El entrenamiento aumentó sección transversal y fuerza del dorsal; proteína adicional no mejoró el resultado","No comparó ejercicios ni regiones del dorsal; muestra pequeña","Moderada para crecimiento general; baja regional","https://pubmed.ncbi.nlm.nih.gov/27258300/"
"M2-E06","M2-E06","UNICA_15","Jalón y agarre","Andersen V et al. Effects of grip width on muscle strength and activation in the lat pull-down","2014","Estudio agudo cruzado","15 hombres","Jalón 6RM con agarres de 1, 1,5 y 2 veces ancho biacromial","Carga y EMG","Diferencias de activación pequeñas; agarres estrecho/medio permitieron algo más de carga","EMG no demuestra hipertrofia; no midió regiones del dorsal","Baja","https://pubmed.ncbi.nlm.nih.gov/24662157/"
"M2-E07","M2-E07","UNICA_15","Tríceps","Maeo S et al. Triceps brachii hypertrophy after overhead versus neutral arm extension","2023","Ensayo longitudinal intrapersonal","21 adultos","Cinco series de 10 repeticiones, dos veces por semana, 12 semanas; un brazo overhead y otro neutral","Volumen MRI de cabeza larga, lateral+medial y total","Overhead produjo más crecimiento total, especialmente cabeza larga","Un ejercicio y una población; tolerancia articular individual","Alta para la comparación","https://pubmed.ncbi.nlm.nih.gov/35819335/"
"M2-E08","M2-E08","UNICA_15","Bíceps regional","Kassiano W et al. Distinct muscle growth after preacher and incline biceps curls","2025","Ensayo aleatorizado entre grupos","63 mujeres jóvenes","Curl predicador o inclinado, dos veces por semana, 8 semanas","Grosor proximal, medio y distal; 3RM","Inclinado favoreció proximal y predicador distal; fuerza específica","Solo mujeres jóvenes; resistencia y longitud no perfectamente aisladas","Moderada","https://pubmed.ncbi.nlm.nih.gov/39809454/"
"M2-E09","M2-E09","UNICA_15","Bíceps regional","Attarieh P et al. Preacher versus Bayesian cable curls","2025","Ensayo longitudinal intrapersonal","15 hombres jóvenes","3–5 series de 8–12RM, dos veces por semana, 10 semanas; perfiles de resistencia igualados","Grosor regional de bíceps y braquial; 1RM","Ambas variantes crecieron de forma semejante sin diferencias regionales significativas","Muestra pequeña; ecografía y duración limitada","Moderada","https://pubmed.ncbi.nlm.nih.gov/40082069/"
"M2-E10","S004","ALIAS_12","Cuádriceps, glúteo y aductor","Kinoshita M et al. Knee extension versus leg press","2026","Ensayo longitudinal intrapersonal","17 adultos no entrenados","Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas","MRI de 17 músculos","Vastos similares; recto femoral +13,2 % vs +1,1 % a favor de extensión; prensa aumentó glúteo +15,4 % y aductor mayor +6,2 %","Muestra pequeña y no entrenada; alto volumen por ejercicio","Alta para la comparación","https://pubmed.ncbi.nlm.nih.gov/41630124/"
"M2-E11","S003","ALIAS_12","Sentadilla, glúteo y aductores","Kubo K et al. Effects of squat training with different depths on lower limb muscle volumes","2019","Ensayo aleatorizado","17 hombres; 8 sentadilla completa y 9 media","Dos días por semana, 10 semanas","MRI de extensores, femorales, aductores y glúteo","Vastos crecieron similar; completa produjo más glúteo y aductores; recto femoral y femorales no crecieron","Muestra pequeña; grupos independientes; técnica y carga específicas","Moderada-alta","https://pubmed.ncbi.nlm.nih.gov/31230110/"
"M2-E12","M2-E12","UNICA_15","Cuádriceps regional","Kojic D et al. Does Back Squat Exercise Lead to Regional Hypertrophy among Quadriceps Femoris Muscles?","2022","Ensayo longitudinal sin control","18 universitarios; 9 mujeres","Sentadilla paralela dos veces por semana durante 7 semanas","Área transversal de cuatro cabezas del cuádriceps","Crecieron las cuatro cabezas; asociación de fuerza más clara con vasto lateral","Sin grupo comparador; intervención corta y poca potencia para diferencias","Moderada-baja","https://pubmed.ncbi.nlm.nih.gov/36498298/"
"M2-E13","M2-E13","UNICA_15","Femorales","Maeo S et al. Seated versus prone leg curl training","2021","Ensayo longitudinal intrapersonal","20 adultos sanos","Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas","Volumen MRI de cada femoral","Curl sentado produjo más crecimiento total: +14 % vs +9 %; ventaja en porciones biarticulares","Muestra pequeña; un protocolo; no comparó bisagras","Alta para la comparación","https://pubmed.ncbi.nlm.nih.gov/33009197/"
"M2-E14","M2-E14","UNICA_15","Pantorrilla","Kinoshita M et al. Standing versus seated calf-raise training","2023","Ensayo longitudinal intrapersonal","14 adultos no entrenados","Cinco series de 10 al 70 % 1RM, dos veces por semana, 12 semanas","Volumen MRI de gastrocnemio y sóleo","De pie superó claramente a sentado para gastrocnemios; sóleo similar","Muestra pequeña y no entrenada; alto volumen","Alta para la comparación","https://pubmed.ncbi.nlm.nih.gov/38156065/"
"M2-E15","S002","ALIAS_12","Glúteo y muslo","Plotkin DL et al. Hip thrust and back squat training","2023","Ensayo aleatorizado","34 universitarios no entrenados: hip thrust n=18, sentadilla n=16","Volumen igualado, 9 semanas supervisadas","MRI regional glútea, cuádriceps, aductores y femorales","Hip thrust y sentadilla: hipertrofia glútea similar; sentadilla: más cuádriceps/aductores; femorales poco o nada","No entrenados; duración corta; financiación parcial vinculada al hip thrust declarada","Moderada-alta","https://pubmed.ncbi.nlm.nih.gov/37877099/"
```


# 07_PROGRAMAS_RUTINAS_ESPECIALIZACION_CASA_GIMNASIO_v2.0.md

# 07 — Programas, variantes, especialización y rescate: gimnasio prioritario

**Versión:** 2.0  
**Fecha:** 2026-08-13  
**Estado:** VALIDADA PARA MIGRACIÓN  
**Función:** biblioteca de variantes de programación, rescate, redistribución de frecuencia, gimnasio concurrido, casa y bloques de especialización. No contiene el programa vigente: ese vive exclusivamente en `03_PROGRAMA_ACTIVO_v2.0.md`.

---

## 1. Autoridad y principio de uso

Este documento responde a:

> **¿Qué alternativa coherente utilizar si el programa activo no puede ejecutarse tal como está, o si en el futuro se decide formalmente cambiar frecuencia, entorno o bloque?**

No gobierna por sí solo:

- el programa vigente → `03`;
- dosificación y progresión → `05`;
- selección/encaje de máquinas → `06`;
- historial ejecutado → JSON;
- estado temporal → `02`.

Regla central:

> **Solo existe un programa activo. Las variantes de esta Source sustituyen o redistribuyen trabajo; nunca se suman automáticamente al programa vigente.**

---

## 2. Preferencia de entorno vigente

### 2.1 Gimnasio como entorno principal

La preferencia actual es **priorizar la asistencia al gimnasio frente al entrenamiento doméstico**, porque ofrece material, estabilidad, progresabilidad y variedad de máquinas más adecuados para el objetivo de hipertrofia integral con glúteo dominante.

Consecuencias:

- el programa principal se diseña primero para gimnasio;
- si Daniel puede acudir al gimnasio con normalidad, no ofrecer por defecto una rutina casera equivalente;
- el material doméstico no debe condicionar hacia abajo la selección de ejercicios del programa principal;
- las máquinas validadas y otros ejercicios altamente progresables tienen prioridad cuando ofrecen mejor encaje;
- el inventario creciente del gimnasio es una ventaja operativa que debe aprovecharse.

### 2.2 Papel del entrenamiento en casa

El entrenamiento doméstico permanece disponible para:

- rescate de una sesión que de otro modo se perdería;
- viajes o cierres;
- limitaciones temporales de acceso;
- sesiones breves deliberadamente complementarias;
- mantenimiento durante periodos especiales;
- trabajo sencillo que no perjudique el entrenamiento prioritario.

No se considera actualmente un entorno co-principal ni una obligación semanal.

---

## 3. Programa activo y biblioteca

El programa vigente es el definido en `03`.

Las plantillas de este documento son **biblioteca**, con estados posibles:

- `RESCATE`
- `REDISTRIBUCION`
- `ALTERNATIVA_FUTURA`
- `MANTENIMIENTO`
- `ESPECIALIZACION_NO_ACTIVA`

Ninguna plantilla adquiere estado `ACTIVA` sin decisión explícita y actualización de `03`.

---

## 4. Jerarquía ante una dificultad

Cuando la sesión normal no puede ejecutarse:

1. **mantener el Día A/B/C en el gimnasio** usando una sustitución validada por función;
2. reorganizar el orden dentro de la sesión si una estación está ocupada;
3. utilizar una versión de rescate en gimnasio;
4. si el gimnasio no es viable, utilizar rescate en casa;
5. si la dificultad se repite, rediseñar formalmente frecuencia/plantilla.

No convertir un problema puntual en un cambio permanente de programa.

---

# PARTE I — GIMNASIO

## 5. Rescate de gimnasio

Objetivo: conservar las funciones prioritarias cuando hay poco tiempo, baja motivación o gimnasio muy concurrido.

### Principio

Un rescate debe:

- mantener 2–4 funciones de alto valor;
- usar aproximadamente 40–70 % de las series de la sesión normal;
- respetar el RIR previsto o ser ligeramente más conservador;
- no intentar “recuperar” las series omitidas después;
- conservar la secuencia A → B → C.

### Día A — rescate

Prioridad:

1. extensión acortada de cadera;
2. patrón profundo;
3. una prioridad de torso.

Ejemplo funcional:

- hip thrust validado — 2 series;
- Hack/Power/V-Squat u otro patrón profundo validado — 2 series;
- press inclinado o tirón/abducción según logística — 1–2 series.

### Día B — rescate

Prioridad:

1. bisagra;
2. femoral;
3. espalda/deltoides.

Ejemplo funcional:

- RDL Smith — 2 series;
- curl femoral sentado — 2 series;
- remo apoyado o deltoides posterior — 1–2 series.

### Día C — rescate

Prioridad:

1. unilateral glúteo/pierna;
2. abducción;
3. prioridad principal de torso.

Ejemplo funcional:

- Bulgarian Smith — 2 series;
- abducción — 1–2 series;
- press/remo/tirón prioritario — 1–2 series.

Los ejercicios concretos se derivan de `03` y de variantes ya validadas en `06`.

---

## 6. Gimnasio concurrido

Si una máquina está ocupada:

1. utilizar una alternativa **ya validada** del mismo slot;
2. si no existe, cambiar temporalmente el orden;
3. si sigue sin estar disponible, realizar una función prioritaria alternativa;
4. registrar la sustitución;
5. no sumar después la máquina original.

Ejemplo:

- patrón profundo ocupado → otra Hack/Power/V-Squat **solo si ya fue validada**;
- si aún no fue validada → no improvisar una prueba pesada por prisa.

Una sustitución abre historial propio si cambia la identidad de máquina.

---

## 7. Plantilla de gimnasio 2D — alternativa futura

**Estado:** `ALTERNATIVA_FUTURA`, no activa.

Uso potencial:

- semanas con menor disponibilidad;
- adherencia claramente mejor con dos sesiones;
- necesidad de concentrar entrenamiento sin perder continuidad.

Principio:

- redistribuir el volumen útil;
- no comprimir todas las series de 3D si degrada la calidad;
- conservar prioridad glútea y físico integral;
- aceptar que algunas funciones secundarias roten.

### Arquitectura orientativa

**Día 1**
- extensión acortada;
- patrón profundo;
- femoral;
- press;
- tirón;
- deltoides;
- complemento.

**Día 2**
- unilateral;
- bisagra;
- abducción;
- cuádriceps/femoral complementario;
- press/tirón;
- brazos;
- pantorrilla/tronco.

La transformación exacta debe calcularse desde el `03` vigente, no copiando una plantilla histórica.

---

## 8. Plantilla 3D

**Estado:** corresponde a la arquitectura actual, pero la prescripción concreta vive en `03`.

Ventajas actuales:

- buena distribución de fatiga;
- suficiente exposición glútea;
- permite entrenar piernas intensamente sin concentrarlo todo;
- integra torso;
- compatible con asistencia prioritaria al gimnasio.

No duplicar aquí ejercicios/series del `03`.

---

## 9. Plantilla de gimnasio 4D — alternativa futura

**Estado:** `ALTERNATIVA_FUTURA`, no activa.

Se considerará cuando:

- Daniel disponga de más días y prefiera sesiones más cortas;
- la calidad de las últimas series de 3D caiga por duración;
- la recuperación entre exposiciones sea buena;
- una cuarta sesión mejore adherencia o distribución.

Regla:

> **4D distribuye primero; no añade volumen automáticamente.**

Arquitectura posible:

- A: glúteo acortado + pecho;
- B: bisagra/femoral + espalda;
- C: patrón profundo/unilateral + hombro;
- D: glúteo accesorio + torso/brazos/complementos.

Debe preservar recuperación entre patrones duros de pierna.

---

# PARTE II — CASA COMO RESCATE

## 10. Inventario doméstico útil

Material conocido históricamente:

- mancuernas/discos;
- TRX;
- apoyo para hip thrust;
- bandas cerradas/elásticas;
- fitball;
- autocarga.

El inventario doméstico puede revalidarse si cambia.

---

## 11. Rescate doméstico mínimo

**Uso:** cuando no acudir al gimnasio implique perder completamente la sesión.

Objetivo: mantener estímulo con poca burocracia, no recrear todas las máquinas.

### Rescate A — glúteo dominante

- hip thrust con mancuerna — 2–3 × 8–20;
- Bulgarian con TRX/mancuernas — 2 × 8–16 por lado;
- abducción con banda — 1–2 × 15–30.

### Rescate B — posterior

- RDL con mancuernas — 2–3 × 8–15;
- puente/hip thrust unilateral o extensión estable — 2 × 10–25;
- remo TRX o mancuerna — 2 × 8–20.

### Rescate C — torso + glúteo auxiliar

- press con mancuernas/flexión progresada — 2–3 series;
- remo TRX/mancuerna — 2–3 series;
- elevación lateral — 2 series;
- abducción/patada banda — 1–2 series.

Las series de rescate **sustituyen** parte del Día correspondiente.

---

## 12. Rescate ultracorto en casa

Cuando la alternativa real sea no entrenar:

**10–20 min, 2–3 funciones.**

Ejemplos:

- hip thrust + Bulgarian;
- RDL + abducción;
- press + remo + lateral;
- tríceps + abdomen + banda como complemento cuando esos slots sean los omitidos.

No intentar alcanzar el volumen semanal completo en una sesión ultracorta.

---

## 13. Casa no equivale a gimnasio

No asumir equivalencia 1:1 entre:

- hip thrust con mancuerna y máquina;
- RDL con mancuernas y Smith;
- banda y máquina de abducción;
- TRX y remo apoyado en máquina;
- flexiones y press convergente.

El rescate conserva una función suficientemente parecida, pero:

- abre historial propio;
- puede usar rangos de repeticiones diferentes;
- puede necesitar mayor proximidad al fallo por menor carga disponible;
- no transfiere kilos ni progresión de la máquina.

---

# PARTE III — MICROSESIONES Y COMPLEMENTOS

## 14. Microseries domésticas

No son necesarias por defecto.

Pueden utilizarse si resuelven una restricción concreta y no interfieren con gimnasio:

- abducción con banda;
- gemelo;
- abdomen;
- tríceps;
- elevación lateral ligera;
- movilidad/activación no fatigante.

### Clasificación

- movimiento fácil/activación → no cuenta como serie productiva;
- trabajo cercano al RIR objetivo → cuenta y debe descontarse;
- potencia → carga separada.

No usar microseries como excusa para inflar volumen glúteo fuera del programa.

---

## 15. Actividad general y cardio

La actividad cotidiana o cardio no necesita convertirse en “sesión de casa”.

El aumento de actividad general se gestiona desde `08`, considerando:

- aproximadamente 6.400 pasos/día como referencia basal actual;
- recuperación;
- composición corporal;
- salud;
- ausencia de interferencia con entrenamiento de piernas.

---

# PARTE IV — ESPECIALIZACIÓN

## 16. Principio de especialización

Una especialización no se añade al programa activo.

Se crea mediante:

1. seleccionar una prioridad;
2. aumentar o mejorar su estímulo si está justificado;
3. reducir/mantener otras regiones cuando sea necesario;
4. conservar presupuesto de recuperación;
5. definir duración y métricas de salida.

---

## 17. Bloques de especialización disponibles conceptualmente

### 17.1 Glúteo reforzado

Posible si el glúteo deja de progresar mientras otras regiones sí lo hacen.

Opciones:

- redistribuir más calidad hacia extensión acortada/profunda/unilateral;
- añadir una serie específica si `05` lo justifica;
- reducir volumen redundante de otras regiones;
- mejorar máquina/encaje antes de añadir volumen.

### 17.2 Pierna integral con glúteo dominante

Compatible con la preferencia estética actual:

- glúteo sigue siendo firma;
- femorales altos;
- cuádriceps/aductores claramente desarrollados;
- no maximizar muslo por inercia.

Solo se activa si el seguimiento visual muestra que la pierna necesita más protagonismo respecto al torso/glúteo.

### 17.3 Marco superior

Prioridad temporal en:

- deltoides lateral/posterior;
- dorsal;
- espalda alta.

Útil si el físico necesita mayor marco sin retirar la prioridad glútea.

### 17.4 Pecho/brazos

Solo si las revisiones muestran retraso relativo.

---

## 18. Duración de un bloque

Orientación general:

- 6–10 semanas cuando exista motivo para especializar;
- no cambiar bloque por aburrimiento;
- revisar aproximadamente a mitad y al final;
- una descarga solo si la fatiga lo justifica.

Los detalles de volumen y progresión los gobierna `05`.

---

# PARTE V — CAMBIOS DE DISPONIBILIDAD

## 19. Semana con menos días

Si solo hay dos días disponibles:

- preservar el orden de prioridad;
- transformar temporalmente a 2D si es necesario;
- no “recuperar” después todas las series perdidas;
- volver a 3D sin compensación cuando se normalice la semana.

Una semana anómala no exige reescribir `03`.

---

## 20. Semana con más días

Más días disponibles pueden utilizarse para:

- distribuir sesiones;
- separar funciones;
- reducir duración;
- introducir actividad/cardio de bajo coste;
- realizar una sesión de torso/complementos si formalmente sustituye/redistribuye trabajo.

No usar un día libre como razón automática para añadir series.

---

## 21. Viajes, cierre o acceso temporal limitado

Orden:

1. conservar lo máximo posible de la función;
2. priorizar glúteo y regiones con peor mantenimiento previsto;
3. utilizar material disponible;
4. aceptar descenso temporal de especificidad;
5. no buscar cargas equivalentes;
6. volver al gimnasio con margen si la interrupción fue suficiente para perder familiaridad.

---

# PARTE VI — ADHERENCIA

## 22. Baja motivación puntual

Cuando exista poca motivación pero capacidad física suficiente:

- ofrecer primero **rescate de gimnasio**, porque el gimnasio es el entorno preferente;
- reducir la sesión a lo esencial;
- no presentar el rescate como fracaso;
- evitar convertir la conversación en negociación larga.

Si aun así ir al gimnasio no es viable, ofrecer rescate doméstico.

---

## 23. Uso repetido de rescates

Si durante aproximadamente tres semanas los rescates sustituyen más de un tercio de las sesiones:

1. revisar horarios y duración real;
2. revisar si 3D sigue siendo la plantilla adecuada;
3. considerar 2D o 4D;
4. no aumentar volumen hasta recuperar consistencia.

La causa puede ser logística, no fisiológica.

---

# PARTE VII — REGLAS DE PRESENTACIÓN

## 24. Cuando Daniel pide “el próximo entrenamiento”

No mostrar esta biblioteca.

El sistema debe:

1. leer `03`;
2. leer JSON;
3. considerar excepciones de `02`;
4. identificar la sesión siguiente;
5. recuperar registros comparables;
6. entregar únicamente **Note v1**.

Las alternativas de `07` solo aparecen si realmente son necesarias.

---

## 25. Cuando Daniel pide adaptar a casa

Si lo pide explícitamente:

- adaptar por función;
- priorizar su material disponible;
- indicar que las cargas/historiales no son comparables;
- mantener el formato Note v1 cuando sea una sesión a ejecutar;
- no intentar imitar cada máquina de forma literal.

---

## 26. Qué no debe hacer el sistema

- presentar casa y gimnasio como opciones equivalentes por defecto;
- proponer entrenar en casa solo porque existe material;
- mantener una rutina doméstica paralela al programa de gimnasio;
- añadir microseries porque Daniel pase tiempo sentado;
- sumar rescates al volumen normal;
- mezclar filas históricas de 2D/3D/4D;
- activar bloques de especialización sin actualizar `03`;
- usar un día adicional como permiso para más volumen;
- penalizar una sesión reducida cuando evita perder por completo el entrenamiento;
- convertir una sustitución puntual en programa permanente.

---

## 27. Decisión vigente de entorno

**Estado al corte 13/08/2026:**

> **GIMNASIO_PRIORITARIO**

Interpretación:

- gimnasio: primera opción para hipertrofia y programa principal;
- casa: contingencia/complemento;
- híbrido: no es actualmente una preferencia de programación;
- futuras máquinas disponibles deben integrarse primero mediante `06`.

Esta decisión puede cambiar si Daniel modifica preferencia, disponibilidad o acceso.

---

## 28. Transferencias

- Programa activo → `03`.
- Dosis/progresión/fatiga → `05`.
- Máquinas y sustituciones por función → `06`.
- Actividad/cardio/salud → `08`.
- Seguimiento de adherencia → `19`.
- Sesiones ejecutadas → JSON.

---

## 29. Registro de cambios v2

### v2.0 — 2026-08-13

- convierte la antigua biblioteca extensa en un sistema de contingencias y variantes;
- establece **gimnasio como entorno principal y preferente**;
- relega casa a rescate, mantenimiento y complementos específicos;
- evita programas domésticos paralelos;
- conserva 2D/3D/4D como transformaciones, no programas simultáneos;
- formaliza rescates A/B/C de gimnasio;
- conserva rescate doméstico por función;
- limita microseries a usos justificables;
- mantiene especialización como redistribución del presupuesto recuperable;
- integra gimnasio concurrido con el inventario/validación de `06`;
- protege Note v1 para la entrega de sesiones;
- minimiza decisiones manuales y burocracia para Daniel.

